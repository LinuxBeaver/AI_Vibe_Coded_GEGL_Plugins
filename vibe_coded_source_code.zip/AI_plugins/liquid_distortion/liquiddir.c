/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås (pippin) for major GEGL contributions
 * 2025 Beaver modifying mostly Grok's work.
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <math.h>
#include <gegl.h>
#include <gegl-plugin.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_liquid_distortion_type221)
  enum_value (GEGL_LIQUID_TYPE_PERLIN_WHIRLPOOL, "perlin_whirlpool", N_("Perlin Whirlpool"))
  enum_value (GEGL_LIQUID_TYPE_PERLIN_SWIRL,    "perlin_swirl",    N_("Perlin Swirl"))
  enum_value (GEGL_LIQUID_TYPE_PERLIN_WAVES,    "perlin_waves",    N_("Perlin Waves"))
  enum_value (GEGL_LIQUID_TYPE_PERLIN_VORTEX,   "perlin_vortex",   N_("Perlin Vortex"))
  enum_value (GEGL_LIQUID_TYPE_TURBULENT_FLOW,  "turbulent_flow",  N_("Turbulent Flow"))
  enum_value (GEGL_LIQUID_TYPE_OCEAN_SWELL,     "ocean_swell",     N_("Ocean Swell"))
  enum_value (GEGL_LIQUID_TYPE_TIDAL_SURGE,     "tidal_surge",     N_("Tidal Surge"))
  enum_value (GEGL_LIQUID_TYPE_WATERY_SHIMMER,  "watery_shimmer",  N_("Watery Shimmer"))
  enum_value (GEGL_LIQUID_TYPE_FLOWING_CURRENTS,"flowing_currents",N_("Flowing Currents"))
enum_end (GeglLiquidDistortionType221)

property_enum (distortion_type, _("Distortion Type"),
               GeglLiquidDistortionType221, gegl_liquid_distortion_type221,
               GEGL_LIQUID_TYPE_PERLIN_WHIRLPOOL)
    description (_("Type of liquid distortion to apply"))

property_double (scale, _("Scale"), 180.0)
    description (_("Scale of the distortion pattern (higher values create smaller, finer distortions)"))
    value_range (85.0, 600.0)
    ui_range (85.0, 600.0)

property_double (roughness, _("Roughness"), 3.5)
    description (_("Roughness of the distortion (higher values create more intense effects)"))
    value_range (0.0, 12.0)
    ui_range (0.0, 8.0)

property_int (octaves, _("Octaves"), 1)
    description (_("Number of octaves for fractal summation (adds finer details to the distortion)"))
    value_range (1, 3)
    ui_range (1, 3)

property_double (strength, _("Strength"), 50.0)
    description (_("Strength of the displacement effect (higher values create larger distortions)"))
    value_range (0.0, 100.0)
    ui_range (0.0, 100.0)

property_seed (seed, _("Seed"), rand)
    description (_("Random seed for the distortion pattern"))

#else

#define GEGL_OP_FILTER
#define GEGL_OP_NAME     liquiddir
#define GEGL_OP_C_SOURCE liquiddir.c

#include "gegl-op.h"

// Simple hash function for randomization
static gfloat
hash (gfloat x, gfloat y, gint seed)
{
  gint hash = (gint)(x * 73856093 + y * 19349663 + seed * 83492791) & 0x7fffffff;
  return (hash % 10000) / 10000.0;
}

// Perlin noise implementation
static gfloat
perlin_noise (gfloat x, gfloat y, gint seed)
{
  gint xi = (gint) x;
  gint yi = (gint) y;
  gfloat xf = x - xi;
  gfloat yf = y - yi;

  gfloat g00 = hash (xi, yi, seed) * 2.0 * G_PI;
  gfloat g10 = hash (xi + 1, yi, seed) * 2.0 * G_PI;
  gfloat g01 = hash (xi, yi + 1, seed) * 2.0 * G_PI;
  gfloat g11 = hash (xi + 1, yi + 1, seed) * 2.0 * G_PI;

  gfloat d00 = cos (g00) * xf + sin (g00) * yf;
  gfloat d10 = cos (g10) * (xf - 1.0) + sin (g10) * yf;
  gfloat d01 = cos (g01) * xf + sin (g01) * (yf - 1.0);
  gfloat d11 = cos (g11) * (xf - 1.0) + sin (g11) * (yf - 1.0);

  gfloat u = xf * xf * (3.0 - 2.0 * xf);
  gfloat v = yf * yf * (3.0 - 2.0 * yf);

  gfloat nx0 = d00 + u * (d10 - d00);
  gfloat nx1 = d01 + u * (d11 - d01);
  return nx0 + v * (nx1 - nx0);
}

static void
prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "input", babl_format ("RGBA float"));
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));

  // Force input buffer update
  GeglNode *input_node = gegl_operation_get_source_node (operation, "input");
  if (input_node)
  {
    gegl_node_process (input_node);
  }

  // Invalidate output cache
  gegl_operation_invalidate (operation, NULL, TRUE);
}

static gboolean
process (GeglOperation       *operation,
         GeglBuffer         *input,
         GeglBuffer         *output,
         const GeglRectangle *result,
         gint                level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  const Babl *format = babl_format ("RGBA float");

  // Clear the output buffer
  gegl_buffer_clear (output, result);

  // Allocate temporary output buffer
  gfloat *out_buf = g_new (gfloat, result->width * result->height * 4);
  gfloat *out_pixel = out_buf;

  // Get full canvas dimensions
  GeglRectangle *canvas = gegl_operation_source_get_bounding_box (operation, "input");
  gfloat canvas_width = canvas ? canvas->width : result->width;
  gfloat canvas_height = canvas ? canvas->height : result->height;

  for (glong i = 0; i < result->width * result->height; i++)
  {
    // Compute global coordinates
    gint x = (i % result->width) + result->x;
    gint y = (i / result->width) + result->y;
    gfloat nx = x / o->scale;
    gfloat ny = y / o->scale;
    gfloat dx = 0.0;
    gfloat dy = 0.0;
    gfloat amplitude = 1.0;
    gfloat frequency = 1.0;
    gfloat total_amplitude = 0.0;

    switch (o->distortion_type)
    {
      case GEGL_LIQUID_TYPE_PERLIN_WHIRLPOOL:
      {
        gfloat angle = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          angle += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        angle /= total_amplitude;
        gfloat dist = sqrt (nx * nx + ny * ny);
        angle = angle * o->roughness * G_PI + dist * 2.0;
        gfloat whirl_x = nx + cos (angle) * dist * 0.5;
        gfloat whirl_y = ny + sin (angle) * dist * 0.5;

        amplitude = 1.0;
        frequency = 1.0;
        total_amplitude = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          dx += amplitude * perlin_noise (whirl_x * frequency, whirl_y * frequency, o->seed + 1 + j);
          dy += amplitude * perlin_noise (whirl_x * frequency + 1000.0, whirl_y * frequency + 1000.0, o->seed + 2 + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        dx /= total_amplitude;
        dy /= total_amplitude;
      }
      break;

      case GEGL_LIQUID_TYPE_PERLIN_SWIRL:
      {
        gfloat angle = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          angle += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        angle /= total_amplitude;
        angle *= o->roughness * G_PI;
        gfloat swirl_x = nx + cos (angle) * 0.5;
        gfloat swirl_y = ny + sin (angle) * 0.5;

        amplitude = 1.0;
        frequency = 1.0;
        total_amplitude = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          dx += amplitude * perlin_noise (swirl_x * frequency, swirl_y * frequency, o->seed + 1 + j);
          dy += amplitude * perlin_noise (swirl_x * frequency + 1000.0, swirl_y * frequency + 1000.0, o->seed + 2 + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        dx /= total_amplitude;
        dy /= total_amplitude;
      }
      break;

      case GEGL_LIQUID_TYPE_PERLIN_WAVES:
      {
        gfloat noise = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          noise += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        noise /= total_amplitude;
        dx = sin (nx * 5.0 + noise * o->roughness) * 0.5;
        dy = cos (ny * 5.0 + noise * o->roughness) * 0.5;
      }
      break;

      case GEGL_LIQUID_TYPE_PERLIN_VORTEX:
      {
        gfloat angle = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          angle += amplitude * perlin_noise (nx * frequency * 2.0, ny * frequency * 2.0, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        angle /= total_amplitude;
        angle *= o->roughness * G_PI * 2.0;
        gfloat vortex_x = nx + cos (angle) * 0.8;
        gfloat vortex_y = ny + sin (angle) * 0.8;

        amplitude = 1.0;
        frequency = 1.0;
        total_amplitude = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          dx += amplitude * perlin_noise (vortex_x * frequency * 1.5, vortex_y * frequency * 1.5, o->seed + 1 + j);
          dy += amplitude * perlin_noise (vortex_x * frequency * 1.5 + 1000.0, vortex_y * frequency * 1.5 + 1000.0, o->seed + 2 + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        dx /= total_amplitude;
        dy /= total_amplitude;
      }
      break;

      case GEGL_LIQUID_TYPE_TURBULENT_FLOW:
      {
        gfloat flow_x = 0.0;
        gfloat flow_y = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          flow_x += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          flow_y += amplitude * perlin_noise (nx * frequency + 1000.0, ny * frequency + 1000.0, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        flow_x /= total_amplitude;
        flow_y /= total_amplitude;
        dx = flow_x * o->roughness * 0.5;
        dy = flow_y * o->roughness * 0.5;
      }
      break;

      case GEGL_LIQUID_TYPE_OCEAN_SWELL:
      {
        gfloat turbulence = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        turbulence /= total_amplitude;
        dx = sin (nx * 3.0 + ny * 2.0 + turbulence) * 0.5;
        dy = cos (nx * 3.0 + ny * 2.0 + turbulence) * 0.5;
      }
      break;

      case GEGL_LIQUID_TYPE_TIDAL_SURGE:
      {
        gfloat turbulence = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        turbulence /= total_amplitude;
        dx = sin (nx * 4.0 + turbulence) * 0.5;
        dy = cos (nx * 4.0 + turbulence) * 0.5;
      }
      break;

      case GEGL_LIQUID_TYPE_WATERY_SHIMMER:
      {
        gfloat turbulence = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        turbulence /= total_amplitude;
        dx = sin (nx * 10.0 + ny * 10.0 + turbulence) * 0.5;
        dy = cos (nx * 10.0 + ny * 10.0 + turbulence) * 0.5;
      }
      break;

      case GEGL_LIQUID_TYPE_FLOWING_CURRENTS:
      {
        gfloat turbulence = 0.0;
        for (gint j = 0; j < o->octaves; j++)
        {
          turbulence += amplitude * perlin_noise (nx * frequency * 2.0, ny * frequency * 0.5, o->seed + j);
          total_amplitude += amplitude;
          amplitude *= o->roughness;
          frequency *= 2.0;
        }
        turbulence /= total_amplitude;
        dx = sin (nx * 5.0 + turbulence) * 0.5;
        dy = cos (nx * 5.0 + turbulence) * 0.5;
      }
      break;

      default:
        dx = 0.0;
        dy = 0.0;
    }

    // Apply strength to displacement
    dx *= o->strength;
    dy *= o->strength;

    // Sample the input image at the displaced coordinates
    gfloat sample[4];
    gegl_buffer_sample (input, x + dx, y + dy, NULL, sample, format,
                        GEGL_SAMPLER_LINEAR, GEGL_ABYSS_CLAMP);

    // Copy sampled pixel to output
    out_pixel[0] = sample[0];
    out_pixel[1] = sample[1];
    out_pixel[2] = sample[2];
    out_pixel[3] = sample[3];
    out_pixel += 4;
  }

  // Write output to buffer
  gegl_buffer_set (output, result, 0, format, out_buf, GEGL_AUTO_ROWSTRIDE);
  g_free (out_buf);

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationFilterClass *filter_class = GEGL_OPERATION_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:liquid-distortion",
    "title",       _("Liquid Distortion"),
    "reference-hash", "perlinwhirlpooldistort2025",
    "description", _("Distort the image with liquid"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL/Distortion",
    "gimp:menu-label", _("Liquid Distort..."),
    NULL);
}

#endif
