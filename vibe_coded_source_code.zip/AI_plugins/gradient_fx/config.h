#ifndef CONFIG_H
#define CONFIG_H
#define GETTEXT_PACKAGE "gegl"
#endif
