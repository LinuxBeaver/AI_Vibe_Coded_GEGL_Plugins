#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'gradientfx.dll') $TOP/WindowsBinaries

cd .. 

cd outline_deluxe && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'outlinedeluxe.dll') $TOP/WindowsBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.dll') $TOP/WindowsBinaries

cd .. 

cd layer_shadow && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'layershadow.dll') $TOP/WindowsBinaries

