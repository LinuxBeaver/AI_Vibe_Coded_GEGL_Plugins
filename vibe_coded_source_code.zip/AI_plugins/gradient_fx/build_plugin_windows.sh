#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'gradientfx.dll') $TOP/WindowsBinaries

cd .. 

cd outline_deluxe && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'outlinedeluxe.dll') $TOP/WindowsBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.dll') $TOP/WindowsBinaries

cd .. 

cd layer_shadow && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'layershadow.dll') $TOP/WindowsBinaries

cd .. 

cd custom_bevel && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'cbevel.dll') $TOP/WindowsBinaries

cd ..

cd port_load && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'loadport.dll') $TOP/WindowsBinaries


cd .. 

cd metallic && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'metallic.dll') $TOP/WindowsBinaries

