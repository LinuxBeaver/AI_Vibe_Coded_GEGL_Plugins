#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'gradientfx.dll') $TOP/WindowsBinaries

cd .. 

cd outline_deluxe && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'outlinedeluxe.dll') $TOP/WindowsBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.dll') $TOP/WindowsBinaries

cd .. 

cd layer_shadow && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'layershadow.dll') $TOP/WindowsBinaries

cd .. 

cd metallic && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'metal.dll') $TOP/WindowsBinaries

cd .. 

cd chrome_text && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'geglchrome.dll') $TOP/WindowsBinaries

cd ..

cd threshold_alpha2 && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'thresholdalpha2.dll') $TOP/WindowsBinaries


cd ..

cd edge_smooth && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'smoothedge.dll') $TOP/WindowsBinaries


