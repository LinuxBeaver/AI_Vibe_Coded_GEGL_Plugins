#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'raybackground.dll') $TOP/WindowsBinaries

cd .. 

cd ray_distortion && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'raydis.dll') $TOP/WindowsBinaries

cd .. 


