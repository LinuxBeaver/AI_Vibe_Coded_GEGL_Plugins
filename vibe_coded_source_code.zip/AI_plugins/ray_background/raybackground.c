/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås (pippin) for major GEGL contributions
 * 2025, beaver, Ray Background (Made by Beaver using an AI plugin)

id=1 src aux=[ color value=purple ]
 
crop aux=[ ref=1 ]
vignette color=green

ai/lb:ray-distortion

]

end of syntax
 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_shape_rays23)
  enum_value (GEGL_VIGNETTE_SHAPE_CIRCLE,     "circle",     N_("Circle"))
  enum_value (GEGL_VIGNETTE_SHAPE_SQUARE,     "square",     N_("Square"))
  enum_value (GEGL_VIGNETTE_SHAPE_DIAMOND,    "diamond",    N_("Diamond"))
enum_end (geglshaperays23)

property_enum (shape, _("Internal shape"),
    geglshaperays23, gegl_shape_rays23,
    GEGL_VIGNETTE_SHAPE_DIAMOND)


property_color (color1, _("Color 1"), "#ffcbff")
    description (_("Color 1 of the ray background"))

property_color (color2, _("Color 2"), "#ff8efb")
    description (_("Color 2 of the ray background"))

property_double (radius, _("Radius"), 1.2)
    description (_("Control the size of the internal shape"))
    value_range (0.0, G_MAXDOUBLE)
    ui_range    (0.0, 3.0)
    ui_meta     ("unit", "relative-distance")

property_double (softness, _("Softness"), 0.8)
    value_range (0.0, 1.0)
    description (_("Control the softness of the internal shape"))


property_double (proportion, _("Proportion"), 1.0)
    description(_("Control the proportions of the internal shape"))
    value_range (0.0, 1.0)

property_double (squeeze, _("Squeeze"), 0.0)
    description (_("Aspect ratio of the internal shape"))
    value_range (-1.0, 1.0)

property_double (x, _("Center X"), 0.5)
    ui_range    (0, 1.0)
    description (_("Move the ray background horizontal"))
    ui_meta     ("unit", "relative-coordinate")
    ui_meta     ("axis", "x")

property_double (y, _("Center Y"), 0.5)
    ui_range    (0, 1.0)
    description (_("Move the ray background vertical"))
    ui_meta     ("unit", "relative-coordinate")
    ui_meta     ("axis", "y")

property_int (ray_angular_division, _("Star Points"), 30)
    description (_("Number of points in the uneven star shape for the ray"))
    value_range (6, 50)

property_double (ray_wavelength, _("Ray Length"), 60.0)
    description (_("Length of the rays in pixels"))
    value_range (1.0, 200.0)

property_double (ray_amplitude, _("Ray Intensity"), 10.0)
    description (_("Strength of the rays in pixels"))
    value_range (0.0, 100.0)
  ui_range (0.0, 50.0)

property_double (ray_phase, _("Ray Phase"), 0.0)
    description (_("Phase shift of the effect on the rays in degrees"))
    value_range (0.0, 360.0)
    ui_meta ("unit", "degree")


/*Properties go here*/

#else

#define GEGL_OP_META
#define GEGL_OP_NAME     raybackground
#define GEGL_OP_C_SOURCE raybackground.c

#include "gegl-op.h"

/*starred nodes go inside typedef struct */

typedef struct
{
 GeglNode *input;
 GeglNode *ray;
 GeglNode *crop;
 GeglNode *color;
 GeglNode *replace;
 GeglNode *vignette;
 GeglNode *output;
}State;

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;
  GeglProperties *o = GEGL_PROPERTIES (operation);


  State *state = o->user_data = g_malloc0 (sizeof (State));

/*new child node list is here, this is where starred nodes get defined

 state->newchildname = gegl_node_new_child (gegl, "operation", "lb:name", NULL);*/
  state->input    = gegl_node_get_input_proxy (gegl, "input");
  state->output   = gegl_node_get_output_proxy (gegl, "output");

 state->color = gegl_node_new_child (gegl, "operation", "gegl:color", NULL);
 state->ray = gegl_node_new_child (gegl, "operation", "ai/lb:ray-distortion", NULL);
 state->vignette = gegl_node_new_child (gegl, "operation", "gegl:vignette",  NULL);
 state->replace = gegl_node_new_child (gegl, "operation", "gegl:src", NULL);
 state->crop = gegl_node_new_child (gegl, "operation", "gegl:crop", NULL);

/*meta redirect property to new child orders go here

 gegl_operation_meta_redirect (operation, "propertyname", state->newchildname,  "originalpropertyname");
*/
 gegl_operation_meta_redirect (operation, "shape", state->vignette,  "shape");
 gegl_operation_meta_redirect (operation, "color1", state->color,  "value");
 gegl_operation_meta_redirect (operation, "color2", state->vignette,  "color");
 gegl_operation_meta_redirect (operation, "radius", state->vignette,  "radius");
 gegl_operation_meta_redirect (operation, "proportion", state->vignette,  "proportion");
 gegl_operation_meta_redirect (operation, "squeeze", state->vignette,  "squeeze");
 gegl_operation_meta_redirect (operation, "softness", state->vignette,  "softness");
 gegl_operation_meta_redirect (operation, "x", state->vignette,  "x");
 gegl_operation_meta_redirect (operation, "y", state->vignette,  "y");
 gegl_operation_meta_redirect (operation, "x", state->ray,  "center-x");
 gegl_operation_meta_redirect (operation, "y", state->ray,  "center-y");
 gegl_operation_meta_redirect (operation, "ray_phase", state->ray,  "phase");
 gegl_operation_meta_redirect (operation, "ray_amplitude", state->ray,  "amplitude");
 gegl_operation_meta_redirect (operation, "ray_wavelength", state->ray,  "wavelength");
 gegl_operation_meta_redirect (operation, "ray_angular_division", state->ray,  "angular_division");


}

static void
update_graph (GeglOperation *operation)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data;
  if (!state) return;

  gegl_node_link_many (state->input, state->replace, state->crop, state->vignette, state->ray, state->output,  NULL);
  gegl_node_connect (state->replace, "aux", state->color, "output"); 
  gegl_node_connect (state->crop, "aux", state->input, "output"); 
/*optional connect from and too is here
  gegl_node_connect (state->blendmode, "aux", state->lastnodeinlist, "output"); */

}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;
GeglOperationMetaClass *operation_meta_class = GEGL_OPERATION_META_CLASS (klass);
  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_meta_class->update = update_graph;

  gegl_operation_class_set_keys (operation_class,
    "name",        "lb:ray-background",
    "title",       _("Star Ray Background"),
    "reference-hash", "fiaafj3ujjr",
    "description", _("Ray Background"),
/*<Image>/Colors <Image>/Filters are top level menus in GIMP*/
    "gimp:menu-path", "<Image>/Filters/Render/Fun",
    "gimp:menu-label", _("Star Ray Background..."),
    NULL);
}

#endif
