#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'raybackground.so') $TOP/LinuxBinaries

cd .. 

cd ray_distortion && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'raydis.so') $TOP/LinuxBinaries

cd .. 


