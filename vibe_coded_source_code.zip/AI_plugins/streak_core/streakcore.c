/* streakcore.c – PAINT STREAKS CORE – WITH BACKGROUND CHECKBOX */
#include "config.h"
#include <glib/gi18n-lib.h>
#include <math.h>
#include <gegl.h>
#include <gegl-plugin.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_streak_count)
  enum_value (GEGL_STREAK_1, "one",   N_("1 Streak"))
  enum_value (GEGL_STREAK_2, "two",   N_("2 Streaks"))
  enum_value (GEGL_STREAK_3, "three", N_("3 Streaks"))
  enum_value (GEGL_STREAK_4, "four",  N_("4 Streaks"))
  enum_value (GEGL_STREAK_5, "five",  N_("5 Streaks"))
  enum_value (GEGL_STREAK_6, "six",   N_("6 Streaks"))
  enum_value (GEGL_STREAK_7, "seven", N_("7 Streaks"))
  enum_value (GEGL_STREAK_8, "eight", N_("8 Streaks"))
enum_end (GeglStreakCount)

property_enum (streaks, _("Number of Streaks"),
               GeglStreakCount, gegl_streak_count,
               GEGL_STREAK_8)
    description (_("How many paint streaks"))

property_double (angle, _("Global Angle"), 0.0)
    description (_("Base angle of streaks – matches gegl:ripple"))
    value_range (-180.0, 180.0)
    ui_meta ("unit", "degree")

property_double (spread, _("Streak Spread"), 0.85)
    description (_("How spread out the streaks are"))
    value_range (0.1, 2.0)

property_double (thickness, _("Streak Thickness"), 147.0)
    description (_("Width of each streak"))
    value_range (20.0, 800.0)
    ui_range (50.0, 400.0)

property_double (x, _("X"), 0.5)
    description (_("Horizontal position of streak center"))
    value_range (-1.0, 2.0)
    ui_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("axis", "x")

property_double (y, _("Y"), 0.5)
    description (_("Vertical position of streak center"))
    value_range (-1.0, 2.0)
    ui_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("axis", "y")

property_boolean (background, _("Background present"), TRUE)
    description (_("If checked, fills background with black; if unchecked, transparent"))

property_color (color1, _("Color 1"), "#ff00ff")
property_color (color2, _("Color 2"), "#00ffff")
    ui_meta ("visible", "streaks {two,three,four,five,six,seven,eight}")
property_color (color3, _("Color 3"), "#ffff00")
    ui_meta ("visible", "streaks {three,four,five,six,seven,eight}")
property_color (color4, _("Color 4"), "#00ff00")
    ui_meta ("visible", "streaks {four,five,six,seven,eight}")
property_color (color5, _("Color 5"), "#ff00ff")
    ui_meta ("visible", "streaks {five,six,seven,eight}")
property_color (color6, _("Color 6"), "#0088ff")
    ui_meta ("visible", "streaks {six,seven,eight}")
property_color (color7, _("Color 7"), "#ffaa00")
    ui_meta ("visible", "streaks {seven,eight}")
property_color (color8, _("Color 8"), "#ff0066")
    ui_meta ("visible", "streaks {eight}")

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     paintstreakscore
#define GEGL_OP_C_SOURCE streakcore.c

#include "gegl-op.h"

static void
prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "input",  babl_format ("RGBA float"));
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));
}

static gboolean
process (GeglOperation *operation,
         void *in_buf,
         void *out_buf,
         glong n_pixels,
         const GeglRectangle *roi,
         gint level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  gfloat *out = out_buf;

  gfloat colors[8][4];
  gegl_color_get_pixel (o->color1, babl_format ("RGBA float"), colors[0]);
  gegl_color_get_pixel (o->color2, babl_format ("RGBA float"), colors[1]);
  gegl_color_get_pixel (o->color3, babl_format ("RGBA float"), colors[2]);
  gegl_color_get_pixel (o->color4, babl_format ("RGBA float"), colors[3]);
  gegl_color_get_pixel (o->color5, babl_format ("RGBA float"), colors[4]);
  gegl_color_get_pixel (o->color6, babl_format ("RGBA float"), colors[5]);
  gegl_color_get_pixel (o->color7, babl_format ("RGBA float"), colors[6]);
  gegl_color_get_pixel (o->color8, babl_format ("RGBA float"), colors[7]);

  int n = 8;
  switch (o->streaks) {
    case GEGL_STREAK_1: n = 1; break;
    case GEGL_STREAK_2: n = 2; break;
    case GEGL_STREAK_3: n = 3; break;
    case GEGL_STREAK_4: n = 4; break;
    case GEGL_STREAK_5: n = 5; break;
    case GEGL_STREAK_6: n = 6; break;
    case GEGL_STREAK_7: n = 7; break;
    case GEGL_STREAK_8: n = 8; break;
  }

  gfloat base_angle = -o->angle * G_PI / 180.0f;

  GeglRectangle *canvas = gegl_operation_source_get_bounding_box (operation, "input");
  gfloat w = canvas ? canvas->width  : roi->width;
  gfloat h = canvas ? canvas->height : roi->height;

  gfloat cx = o->x * w;
  gfloat cy = o->y * h;

  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    gfloat px = x - cx;
    gfloat py = y - cy;

    gfloat best_alpha = 0.0f;
    gfloat final[3] = {0};

    for (int s = 0; s < n; s++)
    {
      gfloat offset = (s - (n - 1) * 0.5f) / (n * 1.2f) * o->spread;

      gfloat ca = cosf(base_angle);
      gfloat sa = sinf(base_angle);

      gfloat rx =  px * ca + py * sa;
      gfloat ry = -px * sa + py * ca;

      ry -= offset * w;

      gfloat dist = fabsf(ry);
      gfloat half = o->thickness * 0.5f;

      if (dist < half && rx > -w && rx < w)
      {
        gfloat t = dist / half;
        gfloat alpha = 1.0f - t;
        alpha = alpha * alpha * alpha * alpha;

        if (alpha > best_alpha)
        {
          best_alpha = alpha;
          final[0] = colors[s][0];
          final[1] = colors[s][1];
          final[2] = colors[s][2];
        }
      }
    }

    if (best_alpha > 0.001f)
    {
      out[0] = final[0];
      out[1] = final[1];
      out[2] = final[2];
      out[3] = 1.0f;
    }
    else
    {
      if (o->background)
      {
        out[0] = out[1] = out[2] = 0.0f;  // Black
        out[3] = 1.0f;
      }
      else
      {
        out[0] = out[1] = out[2] = 0.0f;
        out[3] = 0.0f;  // Transparent
      }
    }
    out += 4;
  }

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass           *operation_class      = GEGL_OPERATION_CLASS (klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:streaks-core",
    "title",       _("Paint Streaks core"),
    "reference-hash", "strekcoreneon2025_bg_toggle",
    "description", _("Base paint streaks – ripple-synced, clickable X/Y, background toggle"),
    "categories",  "hidden",
    NULL);
}

#endif
