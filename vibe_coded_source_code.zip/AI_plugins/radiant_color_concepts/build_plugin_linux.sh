#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'velvetoverlayconcepts.so') $TOP/LinuxBinaries

cd .. 

cd grain_echo && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'velvetoverlay.so') $TOP/LinuxBinaries


