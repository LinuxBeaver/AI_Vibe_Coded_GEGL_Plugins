#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'velvetoverlayconcepts.dll') $TOP/WindowsBinaries

cd .. 

cd velvet_overlay && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'velvetoverlay.dll') $TOP/WindowsBinaries


