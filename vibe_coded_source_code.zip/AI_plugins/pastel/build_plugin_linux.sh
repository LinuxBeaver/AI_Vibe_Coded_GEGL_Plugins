#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'pastel.so') $TOP/LinuxBinaries

cd .. 

cd pastel_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'pastelcore.so') $TOP/LinuxBinaries

cd .. 


