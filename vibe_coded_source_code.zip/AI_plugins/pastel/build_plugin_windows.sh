#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'pastel.dll') $TOP/WindowsBinaries

cd .. 

cd pastel_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'pastelcore.dll') $TOP/WindowsBinaries

cd .. 


