/* This file is an image processing operation for GEGL
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * 
 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES

property_double (stroke_size, _("Stroke Size"), 1.0)
    description (_("Thickness of sketch outlines"))
    value_range (0.5, 3.0)
    ui_range (0.8, 2.0)

property_double (color_softness, _("Color Softness"), 1.0)
    description (_("Softness of pastel colors (higher values are more muted)"))
    value_range (0.5, 2.0)
    ui_range (0.8, 2.0)

property_double (texture_strength, _("Texture Strength"), 1.0)
    description (_("Intensity of chalk-like texture"))
    value_range (0.0, 2.0)
    ui_range (0.1, 2.0)

property_double (edge_sensitivity, _("Edge Sensitivity"), 1.0)
    description (_("Prominence of sketch outlines (lower for subtler effect)"))
    value_range (0.5, 3.0)
    ui_range (0.8, 3.0)

property_double (saturation, _("Saturation"), 1.0)
    description(_("Strength of saturation effect"))
    value_range (1.0, 2.0)
    ui_range (1.0, 2.0)

property_int (smooth, _("Smooth canvas"), 3)
    description(_("Smooth roughness"))
    value_range (1, 5)
    ui_range (1, 5)

property_double (highlight_reduction, _("Highlight reduciton"), 0)
    description(_("Smooth roughness"))
    value_range (-70.0, 0.0)
    ui_range (-70.0, 0.0)

property_double (lightness, _("Lightness"), 0.0)
    description(_("Smooth roughness"))
    value_range (0.0, 10.0)
    ui_range (0.0, 7.0)

/*
property_double (highinput, _("High Input before pastel"), 1.0)
    description(_("Levels high input slider applied pre-pastel sketch"))
    value_range (1.0, 1.2)
    ui_range (1.0, 1.2)
*/
#else

#define GEGL_OP_META
#define GEGL_OP_NAME     grok_pastel
#define GEGL_OP_C_SOURCE pastel.c

#include "gegl-op.h"

static void
attach (GeglOperation *operation)
{
  GeglNode *gegl   = operation->node;
  GeglNode *output = gegl_node_get_output_proxy (gegl, "output");

  GeglNode *sh  = gegl_node_new_child (gegl,
                                          "operation", "gegl:shadows-highlights",
                                          NULL);

  GeglNode *light  = gegl_node_new_child (gegl,
                                          "operation", "gegl:hue-chroma",
                                          NULL);

  GeglNode *saturation  = gegl_node_new_child (gegl,
                                          "operation", "gegl:saturation",
                                          "scale", 1.0,
                                          NULL);



  GeglNode *repair  = gegl_node_new_child (gegl,
                                          "operation", "gegl:median-blur",
                                          "radius", 0,
                                          "abyss-policy", 0,
                                          NULL);
/*
  GeglNode *repair2  = gegl_node_new_child (gegl,
                                          "operation", "gegl:median-blur",
                                          "radius", 0,
                                          "abyss-policy", 0,
                                          NULL);


  GeglNode *highinput  = gegl_node_new_child (gegl,
                                          "operation", "gegl:multiply",
                                          "value", 1.0,
                                          NULL);




*/

  GeglNode *smooth  = gegl_node_new_child (gegl,
                                          "operation", "gegl:noise-reduction",
                                          "iterations", 3,
                                          NULL);

/*prevents gegl crop in aux from crashing GIMP. Highly unique bug to ai/lb:pastel-core*/
/*
#define REPAIRING \
" id=1 dst aux=[ ref=1 cubism ]  id=2 crop aux=[ ref=2 ] "\


 GeglNode*repair2   = gegl_node_new_child (gegl,
                                  "operation", "gegl:gegl", "string", REPAIRING,  NULL);
*/

  GeglNode *pastel  = gegl_node_new_child (gegl,
                                          "operation", "ai/lb:pastel-core",
                                          NULL);

  GeglNode *input  = gegl_node_get_input_proxy (gegl, "input");

  gegl_node_link_many (input, pastel, saturation, sh, smooth, repair, light,  output, NULL);

  gegl_operation_meta_redirect (operation, "stroke_size",    pastel, "stroke_size");
  gegl_operation_meta_redirect (operation, "color_softness", pastel, "color_softness");
  gegl_operation_meta_redirect (operation, "texture_strength",       pastel, "texture_strength");
  gegl_operation_meta_redirect (operation, "edge_sensitivity",  pastel, "edge_sensitivity");

  gegl_operation_meta_redirect (operation, "saturation",    saturation, "scale");
  gegl_operation_meta_redirect (operation, "smooth", smooth, "iterations");
  gegl_operation_meta_redirect (operation, "lightness", light, "lightness");
  gegl_operation_meta_redirect (operation, "highlight_reduction", sh, "highlights");
  /*gegl_operation_meta_redirect (operation, "highinput", highinput, "value"); */

}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;

  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_class->threaded = FALSE;

  gegl_operation_class_set_keys (operation_class,
    "name",           "ai/lb:pastel",
    "title",          _("Pastel Sketch"),
    "reference-hash", "grokspastelcolors",
    "description",
    _("Pastel Colors effect"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Redesign an image into a soft pastel sketch with textured strokes..."),
    NULL);
}

#endif
