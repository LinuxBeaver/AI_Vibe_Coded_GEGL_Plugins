/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 * 2006 Pippin for writing GEGL
 * 2025 Grok with Beavers direction
 */

#define GETTEXT_PACKAGE "gegl"

#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

enum_start (border_style)
  enum_value (BORDER_STYLE_SOLID,      "solid",      N_("Solid"))
  enum_value (BORDER_STYLE_RIPPLED,    "rippled",    N_("Rippled"))
  enum_value (BORDER_STYLE_SINE_WAVE,  "sine_wave",  N_("Sine Wave"))
  enum_value (BORDER_STYLE_RADIAL_WAVE, "radial_wave", N_("Radial Wave"))
  enum_value (BORDER_STYLE_ZIGZAG,     "zigzag",     N_("Zigzag"))
  enum_value (BORDER_STYLE_SCALLOPED,  "scalloped",  N_("Scalloped"))
  enum_value (BORDER_STYLE_DOTTED,     "dotted",     N_("Dotted"))
  enum_value (BORDER_STYLE_CLOUD,      "cloud",      N_("Cloud"))
  enum_value (BORDER_STYLE_SAWTOOTH,   "sawtooth",   N_("Sawtooth"))
  enum_value (BORDER_STYLE_DIAMOND,    "diamond",    N_("Diamond"))
  enum_value (BORDER_STYLE_HEARTBEAT,  "heartbeat",  N_("Heartbeat"))
  enum_value (BORDER_STYLE_WAVY_DOTS,  "wavy_dots",  N_("Wavy Dots"))
  enum_value (BORDER_STYLE_STITCHED,   "stitched",   N_("Stitched"))
  enum_value (BORDER_STYLE_CHECKERBOARD, "checkerboard", N_("Checkerboard"))
  enum_value (BORDER_STYLE_SPIRAL,     "spiral",     N_("Spiral"))
  enum_value (BORDER_STYLE_STARBURST,  "starburst",  N_("Starburst"))
  enum_value (BORDER_STYLE_FRACTAL,    "fractal",    N_("Fractal"))
  enum_value (BORDER_STYLE_FLORAL,     "floral",     N_("Floral"))
  enum_value (BORDER_STYLE_BARBED_WIRE, "barbed_wire", N_("Barbed Wire"))
  enum_value (BORDER_STYLE_MOSAIC,     "mosaic",     N_("Mosaic"))
  enum_value (BORDER_STYLE_CIRCUIT,    "circuit",    N_("Circuit"))
  enum_value (BORDER_STYLE_WAVE_CREST, "wave_crest", N_("Wave Crest"))
  enum_value (BORDER_STYLE_HONEYCOMB,  "honeycomb",  N_("Honeycomb"))
  enum_value (BORDER_STYLE_RETRO_WAVE, "retro_wave", N_("Retro Wave"))
  enum_value (BORDER_STYLE_BRAIDED,    "braided",    N_("Braided"))
  enum_value (BORDER_STYLE_PIXELATED,  "pixelated",  N_("Pixelated"))
enum_end (BorderStyle)

property_enum (border_style, _("Border Style"),
               BorderStyle, border_style, BORDER_STYLE_SOLID)
    description (_("Style of the border outline"))

property_color (border_color, _("Border Color"), "#ffffff")
    description (_("Color of the border outline"))

property_int (border_width, _("Border Width"), 15)
    description (_("Width of the border in pixels"))
    value_range (1, 200)
    ui_range (1, 200)

property_double (wave_frequency, _("Wave Frequency"), 20.0)
    description (_("Frequency of the wave pattern (higher = more waves, shorter length)"))
    value_range (1.0, 50.0)
    ui_range (1.0, 50.0)
    ui_meta ("visible", "border_style {sine_wave, zigzag, scalloped, sawtooth, diamond, heartbeat, wavy_dots, floral, barbed_wire, wave_crest, retro_wave}")

property_double (pattern_intensity, _("Pattern Intensity"), 1.0)
    description (_("Adjusts the size, spacing, or strength of the pattern (varies by style)"))
    value_range (0.1, 2.0)
    ui_range (0.1, 2.0)
    ui_meta ("visible", "border_style {cloud, wavy_dots, stitched, checkerboard, spiral, starburst, fractal, mosaic, circuit, honeycomb, braided, pixelated}")

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     borderframe
#define GEGL_OP_C_SOURCE borderframe.c

#include "gegl-op.h"

static void
prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "input", babl_format ("RGBA float"));
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));
}

static gboolean
process (GeglOperation       *operation,
         void               *in_buf,
         void               *out_buf,
         glong               n_pixels,
         const GeglRectangle *roi,
         gint                level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  gfloat *in_pixel = (gfloat *) in_buf;
  gfloat *out_pixel = (gfloat *) out_buf;

  // Validate inputs
  if (!in_buf || !out_buf || !roi || n_pixels <= 0)
    return FALSE;

  gfloat border[4];
  gegl_color_get_pixel (o->border_color, babl_format ("RGBA float"), border);

  // Get canvas dimensions
  GeglRectangle *canvas = gegl_operation_source_get_bounding_box (operation, "input");
  if (!canvas || canvas->width <= 0 || canvas->height <= 0)
    return FALSE;

  gint canvas_width = canvas->width;
  gint canvas_height = canvas->height;

  // Border width
  gfloat bw = (gfloat) o->border_width;

  // Center for radial/spiral styles
  gfloat center_x = canvas_width / 2.0;
  gfloat center_y = canvas_height / 2.0;

  for (glong i = 0; i < n_pixels; i++)
  {
    // Compute global coordinates
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    // Validate coordinates
    if (x < 0 || x >= canvas_width || y < 0 || y >= canvas_height)
    {
      out_pixel[0] = in_pixel[0];
      out_pixel[1] = in_pixel[1];
      out_pixel[2] = in_pixel[2];
      out_pixel[3] = in_pixel[3];
      in_pixel += 4;
      out_pixel += 4;
      continue;
    }

    // Calculate distances to canvas edges
    gfloat dist_left = (gfloat) x;
    gfloat dist_right = (gfloat) (canvas_width - 1 - x);
    gfloat dist_top = (gfloat) y;
    gfloat dist_bottom = (gfloat) (canvas_height - 1 - y);
    gfloat min_dist = fmin (fmin (dist_left, dist_right), fmin (dist_top, dist_bottom));

    // Determine the closest edge
    typedef enum { EDGE_LEFT, EDGE_RIGHT, EDGE_TOP, EDGE_BOTTOM } Edge;
    Edge closest_edge;
    if (min_dist == dist_left)
      closest_edge = EDGE_LEFT;
    else if (min_dist == dist_right)
      closest_edge = EDGE_RIGHT;
    else if (min_dist == dist_top)
      closest_edge = EDGE_TOP;
    else
      closest_edge = EDGE_BOTTOM;

    // Position along the edge for wave patterns
    gfloat position;
    switch (closest_edge)
    {
      case EDGE_LEFT:
      case EDGE_RIGHT:
        position = (gfloat) y / canvas_height; // Normalize position along vertical edges
        break;
      case EDGE_TOP:
      case EDGE_BOTTOM:
      default:
        position = (gfloat) x / canvas_width; // Normalize position along horizontal edges
        break;
    }

    // Check if pixel is within the border region and apply style
    gboolean is_border = FALSE;
    gfloat alpha = 1.0;

    switch (o->border_style)
    {
      case BORDER_STYLE_SOLID:
        is_border = (min_dist < bw);
        break;

      case BORDER_STYLE_RIPPLED:
        {
          gfloat ripple = 0.5 * sin (10.0 * (x + y) / canvas_width) + 0.5 * sin (15.0 * (x - y) / canvas_height);
          gfloat threshold = bw * (0.7 + 0.3 * ripple);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_SINE_WAVE:
        {
          gfloat frequency = o->wave_frequency;
          gfloat wave = sin (frequency * position * 2.0 * G_PI);
          gfloat threshold = bw * (0.5 + 0.5 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_RADIAL_WAVE:
        {
          gfloat dx = x - center_x;
          gfloat dy = y - center_y;
          gfloat distance = sqrt (dx * dx + dy * dy);
          gfloat wave = sin (0.05 * distance);
          gfloat threshold = bw * (0.5 + 0.5 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_ZIGZAG:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat wave = fabs (fmod (position / period, 2.0) - 1.0);
          gfloat threshold = bw * (0.5 + 0.5 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_SCALLOPED:
        {
          gfloat frequency = o->wave_frequency;
          gfloat wave = 0.5 * (1.0 + cos (frequency * position * 2.0 * G_PI));
          gfloat threshold = bw * (0.7 + 0.3 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_DOTTED:
        {
          gfloat period = 10.0;
          gfloat t = fmod ((x + y), period);
          is_border = (min_dist < bw) && (t < period / 2.0);
        }
        break;

      case BORDER_STYLE_CLOUD:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat noise = sin (10.0 * position * 2.0 * G_PI) + sin (15.0 * position * 2.0 * G_PI);
          noise = 0.5 + 0.25 * noise;
          gfloat threshold = bw * (0.5 + 0.5 * noise * intensity);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_SAWTOOTH:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat wave = fmod (position / period, 1.0);
          gfloat threshold = bw * wave;
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_DIAMOND:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat wave = 1.0 - fabs (fmod (position / period, 2.0) - 1.0);
          gfloat threshold = bw * wave;
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_HEARTBEAT:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat t = fmod (position / period, 1.0);
          gfloat wave = (t < 0.1) ? (10.0 * t) : ((t < 0.2) ? (1.0 - 5.0 * (t - 0.1)) : 0.0);
          gfloat threshold = bw * wave;
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_WAVY_DOTS:
        {
          gfloat frequency = o->wave_frequency;
          gfloat wave = 0.5 * (1.0 + sin (frequency * position * 2.0 * G_PI));
          gfloat intensity = o->pattern_intensity;
          gfloat period = 10.0 / intensity;
          gfloat t = fmod ((x + y), period);
          gfloat threshold = bw * wave;
          is_border = (min_dist < threshold) && (t < period / 2.0);
        }
        break;

      case BORDER_STYLE_STITCHED:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat period = 10.0 / intensity;
          gfloat t = fmod ((x + y), period);
          gfloat dash_length = period * 0.6;
          is_border = (min_dist < bw) && (t < dash_length);
        }
        break;

      case BORDER_STYLE_CHECKERBOARD:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat size = 10.0 / intensity;
          gint check_x = (gint) (x / size);
          gint check_y = (gint) (y / size);
          is_border = (min_dist < bw) && ((check_x + check_y) % 2 == 0);
        }
        break;

      case BORDER_STYLE_SPIRAL:
        {
          gfloat dx = x - center_x;
          gfloat dy = y - center_y;
          gfloat angle = atan2 (dy, dx);
          gfloat distance = sqrt (dx * dx + dy * dy);
          gfloat intensity = o->pattern_intensity;
          gfloat spiral = sin (distance * 0.1 + angle * 5.0 * intensity);
          gfloat threshold = bw * (0.5 + 0.5 * spiral);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_STARBURST:
        {
          gfloat dx = x - center_x;
          gfloat dy = y - center_y;
          gfloat angle = atan2 (dy, dx);
          gfloat intensity = o->pattern_intensity;
          gfloat star = sin (angle * 10.0 * intensity);
          gfloat threshold = bw * (0.5 + 0.5 * star);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_FRACTAL:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat fractal = 0.0;
          gfloat scale = 1.0;
          for (gint i = 0; i < (gint) (3.0 * intensity); i++)
          {
            fractal += sin (position * scale * 2.0 * G_PI) / scale;
            scale *= 2.0;
          }
          fractal = 0.5 + 0.25 * fractal;
          gfloat threshold = bw * fractal;
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_FLORAL:
        {
          gfloat frequency = o->wave_frequency;
          gfloat petal = sin (frequency * position * 2.0 * G_PI) * cos (frequency * position * G_PI);
          gfloat threshold = bw * (0.5 + 0.5 * petal);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_BARBED_WIRE:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat t = fmod (position / period, 1.0);
          gfloat wave = (t < 0.3) ? (3.0 * t) : ((t < 0.5) ? (0.9 - 1.5 * (t - 0.3)) : 0.0);
          gfloat threshold = bw * (0.3 + 0.7 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_MOSAIC:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat size = 5.0 / intensity;
          gint tile_x = (gint) (x / size);
          gint tile_y = (gint) (y / size);
          gfloat noise = sin (tile_x * 123.456 + tile_y * 789.012);
          gfloat threshold = bw * (0.5 + 0.5 * noise);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_CIRCUIT:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat period = 20.0 / intensity;
          gfloat t = fmod ((x + y), period);
          gfloat wave = sin (position * 10.0 * 2.0 * G_PI);
          gfloat threshold = bw * (0.5 + 0.3 * wave);
          is_border = (min_dist < threshold) && (t < period / 2.0);
        }
        break;

      case BORDER_STYLE_WAVE_CREST:
        {
          gfloat frequency = o->wave_frequency;
          gfloat period = 1.0 / frequency;
          gfloat t = fmod (position / period, 1.0);
          gfloat wave = (t < 0.5) ? (2.0 * t) : (1.0 - 2.0 * (t - 0.5));
          wave = wave * wave; // Sharpen the crest
          gfloat threshold = bw * (0.3 + 0.7 * wave);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_HONEYCOMB:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat size = 10.0 / intensity;
          gfloat hex_x = (x / size) + (fmod (y / size, 2.0) * 0.5);
          gfloat hex_y = (y / size) * (sqrt (3.0) / 2.0);
          gfloat dx = fmod (hex_x, 1.0) - 0.5;
          gfloat dy = fmod (hex_y, 1.0) - 0.5;
          gfloat dist = sqrt (dx * dx + dy * dy);
          is_border = (min_dist < bw) && (dist < 0.3);
        }
        break;

      case BORDER_STYLE_RETRO_WAVE:
        {
          gfloat frequency = o->wave_frequency;
          gfloat wave = sin (frequency * position * 2.0 * G_PI);
          gfloat glow = 0.5 + 0.5 * sin (frequency * position * 4.0 * G_PI);
          gfloat threshold = bw * (0.5 + 0.3 * wave + 0.2 * glow);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_BRAIDED:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat frequency = 10.0 * intensity;
          gfloat wave1 = sin (frequency * position * 2.0 * G_PI);
          gfloat wave2 = sin (frequency * position * 2.0 * G_PI + G_PI / 2.0);
          gfloat threshold = bw * (0.5 + 0.25 * wave1 + 0.25 * wave2);
          is_border = (min_dist < threshold);
        }
        break;

      case BORDER_STYLE_PIXELATED:
        {
          gfloat intensity = o->pattern_intensity;
          gfloat size = 5.0 / intensity;
          gint pixel_x = (gint) (x / size);
          gint pixel_y = (gint) (y / size);
          gfloat noise = (sin (pixel_x * 456.789 + pixel_y * 123.456) > 0.0) ? 1.0 : 0.0;
          is_border = (min_dist < bw) && (noise > 0.5);
        }
        break;

      default:
        is_border = (min_dist < bw); // Fallback to solid
        break;
    }

    if (is_border)
    {
      out_pixel[0] = border[0];
      out_pixel[1] = border[1];
      out_pixel[2] = border[2];
      out_pixel[3] = border[3] * alpha;
    }
    else
    {
      out_pixel[0] = in_pixel[0];
      out_pixel[1] = in_pixel[1];
      out_pixel[2] = in_pixel[2];
      out_pixel[3] = in_pixel[3];
    }

    in_pixel += 4;
    out_pixel += 4;
  }

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name", "ai/lb:frame",
    "title", _("Frame"),
    "reference-hash", "fancyborder1",
    "description", _("Adds a customizable styled frame around the image. Recommended to apply Beaver's plugins on top of its generic color fill"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Frame..."),
    NULL);
}

#endif
