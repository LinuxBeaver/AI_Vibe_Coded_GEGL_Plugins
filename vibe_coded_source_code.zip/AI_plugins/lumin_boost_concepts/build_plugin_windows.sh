#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'luminboostconcepts.dll') $TOP/WindowsBinaries

cd .. 

cd lumin_boost && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'luminboost.dll') $TOP/WindowsBinaries


