#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'distortedaura.dll') $TOP/WindowsBinaries

cd .. 

cd turbulent_distortion && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'turdir.dll') $TOP/WindowsBinaries

cd .. 


