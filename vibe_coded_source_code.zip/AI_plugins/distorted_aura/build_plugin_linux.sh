#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'distortedaura.so') $TOP/LinuxBinaries

cd .. 

cd turbulent_distortion && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'turbdir.so') $TOP/LinuxBinaries

cd .. 


