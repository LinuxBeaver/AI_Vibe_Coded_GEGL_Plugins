/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås (pippin) for major GEGL contributions
 * 2025, beaver, GEGL Streaks (Grok made the important ai/lb:streaks-core plugin

ai/lb:streaks-core angle=-34
id=1 over aux=[ ref=1 cubism tile-size=5 ]
gegl:noise-spread 
gaussian-blur std-dev-x=2 std-dev-y=2
ripple abyss-policy=clamp angle=-34
noise-reduction iterations=3

]

end of syntax
 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES


enum_start (ffgegl_streak_count)
  enum_value (GEGL_STREAK_1, "one",   N_("1 Streak"))
  enum_value (GEGL_STREAK_2, "two",   N_("2 Streaks"))
  enum_value (GEGL_STREAK_3, "three", N_("3 Streaks"))
  enum_value (GEGL_STREAK_4, "four",  N_("4 Streaks"))
  enum_value (GEGL_STREAK_5, "five",  N_("5 Streaks"))
  enum_value (GEGL_STREAK_6, "six",   N_("6 Streaks"))
  enum_value (GEGL_STREAK_7, "seven", N_("7 Streaks"))
  enum_value (GEGL_STREAK_8, "eight", N_("8 Streaks"))
enum_end (ffGeglStreakCount)

property_enum (streaks, _("Number of Streaks"),
               ffGeglStreakCount, ffgegl_streak_count,
               GEGL_STREAK_8)
    description (_("How many paint streaks"))



property_double (spread, _("Streak Spread"), 1.1)
    description (_("How spread out the streaks are"))
    value_range (0.1, 2.0)

property_double (thickness, _("Streak Thickness"), 65.0)
    description (_("Width of each streak"))
    value_range (20.0, 800.0)
    ui_range (50.0, 400.0)

property_double (x, _("X"), 0.5)
    description (_("Horizontal position of streak center"))
    value_range (-1.0, 2.0)
    ui_range    (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("axis", "x")

property_double (y, _("Y"), 0.5)
    description (_("Vertical position of streak center"))
    value_range (-1.0, 2.0)
    ui_range    (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("axis", "y")

property_color (color1, _("Color 1"), "#ff00ff")
property_color (color2, _("Color 2"), "#00ffff")
    ui_meta ("visible", "streaks {two,three,four,five,six,seven,eight}")
property_color (color3, _("Color 3"), "#ffff00")
    ui_meta ("visible", "streaks {three,four,five,six,seven,eight}")
property_color (color4, _("Color 4"), "#00ff00")
    ui_meta ("visible", "streaks {four,five,six,seven,eight}")
property_color (color5, _("Color 5"), "#ff00ff")
    ui_meta ("visible", "streaks {five,six,seven,eight}")
property_color (color6, _("Color 6"), "#0088ff")
    ui_meta ("visible", "streaks {six,seven,eight}")
property_color (color7, _("Color 7"), "#ffaa00")
    ui_meta ("visible", "streaks {seven,eight}")
property_color (color8, _("Color 8"), "#ff0066")
    ui_meta ("visible", "streaks {eight}")


/*Properties go here*/

property_boolean (background, _("Background present"), TRUE)
    description (_("If checked, fills background with black; if unchecked, transparent"))


property_double (angle, _("Global Angle"), 34.0)
    description (_("Base angle of streaks and their optional ripple"))
    ui_range (-180.0, 180.0)
    value_range (-180.0, 180.0)
    ui_meta ("unit", "degree")




property_seed (seed, _("Random seed"), rand)


property_int  (iterations, _("Smooth strength"), 4)
  description (_("Smoothing the streaks"))
  value_range (0, 14)
  ui_range    (0, 14)


property_int  (disseminate, _("Disseminate"), 4)
  description (_("Dissemination of streaks"))
  value_range (0, 80)
  ui_range    (0, 60)

property_double  (blur, _("Blur"), 1.5)
  description (_("Gaussian blur on the streaks"))
  value_range (0.0, 4.0)
  ui_range    (0.0, 4.0)

property_double (ripple_amplitude, _("Ripple Amplitude"), 25.0)
    value_range (0.0, 100.0)
    ui_gamma    (2.0)



enum_start (a03232hgegl_ripple_wave_type)
  enum_value (GEGL_RIPPLE_WAVE_TYPE_SINE,     "sine",     N_("Sine"))
  enum_value (GEGL_RIPPLE_WAVE_TYPE_TRIANGLE, "triangle", N_("Triangle"))
enum_end (a03232hGeglRippleWaveType)

property_enum (ripple_wave_type, _("Ripple Wave type"),
    a03232hGeglRippleWaveType, a03232hgegl_ripple_wave_type, GEGL_RIPPLE_WAVE_TYPE_SINE)


property_double (tile_size, _("Tile size"), 5.0)
    description (_("Average diameter of each tile (in pixels)"))
    value_range (0.0, 5.0)
    ui_meta     ("unit", "pixel-distance")

property_double (tile_saturation, _("Tile saturation"), 2.5)
    description (_("Expand tiles by this amount"))
    value_range (0.0, 3.0)



#else

#define GEGL_OP_META
#define GEGL_OP_NAME     streak
#define GEGL_OP_C_SOURCE streak.c

#include "gegl-op.h"

/*starred nodes go inside typedef struct */

typedef struct
{
 GeglNode *input;
 GeglNode *ripple;
 GeglNode *gaussian;
 GeglNode *spread;
 GeglNode *normal;
 GeglNode *cubism;
 GeglNode *smooth;
 GeglNode *idref;
 GeglNode *blur;
 GeglNode *streaks;
 GeglNode *output;
}State;

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;
  GeglProperties *o = GEGL_PROPERTIES (operation);


  State *state = o->user_data = g_malloc0 (sizeof (State));

/*new child node list is here, this is where starred nodes get defined

 state->newchildname = gegl_node_new_child (gegl, "operation", "lb:name", NULL);*/
  state->input    = gegl_node_get_input_proxy (gegl, "input");
 state->streaks = gegl_node_new_child (gegl, "operation", "ai/lb:streaks-core", "angle", 34.0,  NULL);
 state->ripple = gegl_node_new_child (gegl, "operation", "gegl:ripple", "abyss-policy", 1, "angle", 34.0, NULL);
 state->blur = gegl_node_new_child (gegl, "operation", "gegl:gaussian-blur", NULL);
 state->spread = gegl_node_new_child (gegl, "operation", "gegl:noise-spread", NULL);
 state->normal = gegl_node_new_child (gegl, "operation", "gegl:over", NULL);
 state->cubism = gegl_node_new_child (gegl, "operation", "gegl:cubism", NULL);
 state->smooth = gegl_node_new_child (gegl, "operation", "gegl:noise-reduction", NULL);
 state->idref = gegl_node_new_child (gegl, "operation", "gegl:nop", NULL);
  state->output   = gegl_node_get_output_proxy (gegl, "output");

/*so both update together*/
 gegl_operation_meta_redirect (operation, "angle", state->ripple,  "angle");
 gegl_operation_meta_redirect (operation, "angle", state->streaks,  "angle");
/*meta redirect property to new child orders go here
 *

 gegl_operation_meta_redirect (operation, "propertyname", state->newchildname,  "originalpropertyname");
*/
 gegl_operation_meta_redirect (operation, "x", state->streaks,  "x");
 gegl_operation_meta_redirect (operation, "y", state->streaks,  "y");
 gegl_operation_meta_redirect (operation, "streaks", state->streaks,  "streaks");
 gegl_operation_meta_redirect (operation, "thickness", state->streaks,  "thickness");
 gegl_operation_meta_redirect (operation, "spread", state->streaks,  "spread");
 gegl_operation_meta_redirect (operation, "color1", state->streaks,  "color1");
 gegl_operation_meta_redirect (operation, "color2", state->streaks,  "color2");
 gegl_operation_meta_redirect (operation, "color3", state->streaks,  "color3");
 gegl_operation_meta_redirect (operation, "color4", state->streaks,  "color4");
 gegl_operation_meta_redirect (operation, "color5", state->streaks,  "color5");
 gegl_operation_meta_redirect (operation, "color6", state->streaks,  "color6");
 gegl_operation_meta_redirect (operation, "color7", state->streaks,  "color7");
 gegl_operation_meta_redirect (operation, "color8", state->streaks,  "color8");
 gegl_operation_meta_redirect (operation, "background", state->streaks,  "background");

 gegl_operation_meta_redirect (operation, "disseminate", state->spread,  "amount-x");
 gegl_operation_meta_redirect (operation, "disseminate", state->spread,  "amount-y");
 gegl_operation_meta_redirect (operation, "seed", state->spread,  "seed");
 gegl_operation_meta_redirect (operation, "seed", state->cubism,  "seed");
 gegl_operation_meta_redirect (operation, "ripple-amplitude", state->ripple,  "amplitude");
 gegl_operation_meta_redirect (operation, "ripple-wave-type", state->ripple,  "wave-type");
 gegl_operation_meta_redirect (operation, "blur", state->blur,  "std-dev-x"); 
 gegl_operation_meta_redirect (operation, "blur", state->blur,  "std-dev-y");
 gegl_operation_meta_redirect (operation, "iterations", state->smooth,  "iterations");
 gegl_operation_meta_redirect (operation, "tile-size", state->cubism,  "tile-size");
 gegl_operation_meta_redirect (operation, "tile-saturation", state->cubism,  "tile-saturation");


}

static void
update_graph (GeglOperation *operation)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data;
  if (!state) return;

  gegl_node_link_many (state->input,  state->streaks,   state->spread,   state->idref, state->normal, state->smooth, state->blur, state->ripple,  state->output,  NULL);
  gegl_node_connect (state->normal, "aux", state->cubism, "output");
  gegl_node_link_many (state->idref, state->cubism,  NULL);

}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;
GeglOperationMetaClass *operation_meta_class = GEGL_OPERATION_META_CLASS (klass);
  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_meta_class->update = update_graph;

  gegl_operation_class_set_keys (operation_class,
    "name",        "lb:streaks",
    "title",       _("Streaks"),
    "reference-hash", "benjamintuckerisbased",
    "description", _("Colored line streaks that can look like paint strokes"),
/*<Image>/Colors <Image>/Filters are top level menus in GIMP*/
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Streaks (lines and paint strokes)..."),
    NULL);
}

#endif
