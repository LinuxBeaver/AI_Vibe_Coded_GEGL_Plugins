#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'glassedshapes.so') $TOP/LinuxBinaries

cd .. 

cd glass_over_text && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'glassovertext.so') $TOP/LinuxBinaries
 
cd .. 

cd edge_smooth && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'smoothedge.so') $TOP/LinuxBinaries
 

cd .. 

cd shape_design_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesigncore.so') $TOP/LinuxBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.so') $TOP/LinuxBinaries

cd .. 

cd shape_design && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesign.so') $TOP/LinuxBinaries
