/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright 2006 Øyvind Kolås <pippin@gimp.org> FOR MAKING GEGL
 * 2025 Grok with Beaver's help
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

property_double (center_x, _("Center X"), 0.5)
    description (_("Horizontal center of the vortex (relative to image width, 0.0 to 1.0)"))
    value_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("direction", "x")

property_double (center_y, _("Center Y"), 0.5)
    description (_("Vertical center of the vortex (relative to image height, 0.0 to 1.0)"))
    value_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("direction", "y")

property_double (strength, _("Strength"), 3.0)
    description (_("Intensity of the vortex swirl"))
    value_range (0.0, 10.0)

property_double (radius, _("Radius"), 400.0)
    description (_("Maximum radius of the vortex effect in pixels"))
    value_range (10.0, 1000.0)

property_double (angle, _("Angle"), 0.0)
    description (_("Starting angle of the spiral in degrees"))
    value_range (0.0, 360.0)
    ui_meta ("unit", "degree")

property_double (tightness, _("Tightness"), 1.0)
    description (_("How tightly the spiral winds (higher values create more rotations)"))
    value_range (0.0, 5.0)

property_double (pinch, _("Pinch"), 0.0)
    description (_("Pinch amount: positive to pull pixels toward the center, negative to push them away"))
    value_range (-1.0, 1.0)

#else

#define GEGL_OP_FILTER
#define GEGL_OP_NAME     vortexdistortion
#define GEGL_OP_C_SOURCE vordir.c

#include "gegl-op.h"

static void prepare (GeglOperation *operation)
{
  const Babl *format = babl_format ("RGBA float");
  gegl_operation_set_format (operation, "input", format);
  gegl_operation_set_format (operation, "output", format);

  /* Force the input node to compute its output to ensure upstream GEGL Graph filters are applied */
  GeglNode *input_node = gegl_operation_get_source_node (operation, "input");
  if (input_node)
  {
    gegl_node_process (input_node);
  }

  /* Invalidate the output cache to force a fresh computation */
  gegl_operation_invalidate (operation, NULL, TRUE);
}

static GeglRectangle get_bounding_box (GeglOperation *operation)
{
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  if (!in_rect)
    return gegl_rectangle_infinite_plane ();
  return *in_rect;
}

static GeglRectangle get_required_for_output (GeglOperation *operation,
                                              const gchar *input_pad,
                                              const GeglRectangle *roi)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  GeglRectangle result = *roi;

  /* Expand the region of interest to account for the maximum displacement */
  gdouble max_displacement = (o->strength * o->radius * 0.1) + (fabs(o->pinch) * o->radius * 0.5);
  result.x -= max_displacement;
  result.y -= max_displacement;
  result.width += 2 * max_displacement;
  result.height += 2 * max_displacement;

  /* Intersect with the full input buffer to ensure we can sample outside the selection */
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  if (in_rect)
    gegl_rectangle_intersect (&result, &result, in_rect);

  return result;
}

static gboolean
process (GeglOperation       *operation,
         GeglBuffer          *input,
         GeglBuffer          *output,
         const GeglRectangle *result,
         gint                 level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  const Babl *format = babl_format ("RGBA float");
  gfloat *output_pixel = g_new (gfloat, 4);
  gdouble angle_rad = o->angle * G_PI / 180.0;

  /* Get the full input buffer dimensions for sampling */
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  gdouble center_x = o->center_x * in_rect->width + in_rect->x;
  gdouble center_y = o->center_y * in_rect->height + in_rect->y;

  /* Clear the output buffer to ensure no stale data */
  gegl_buffer_clear (output, result);

  /* Create iterator for the output buffer */
  GeglBufferIterator *iter = gegl_buffer_iterator_new (output, result, 0, format,
                                                       GEGL_BUFFER_WRITE, GEGL_ABYSS_NONE, 1);

  /* Process each output region */
  while (gegl_buffer_iterator_next (iter))
  {
    gfloat *out_data = (gfloat *)iter->items[0].data;
    GeglRectangle roi = iter->items[0].roi;

    for (gint y = roi.y; y < roi.y + roi.height; y++)
    {
      for (gint x = roi.x; x < roi.x + roi.width; x++)
      {
        /* Calculate position relative to the center */
        gdouble dx = x - center_x;
        gdouble dy = y - center_y;
        gdouble r = sqrt(dx * dx + dy * dy);

        /* Compute the vortex displacement with pinch */
        gdouble src_x = x;
        gdouble src_y = y;
        if (r < o->radius && r > 0.0) /* Avoid division by zero at the center */
        {
          gdouble theta = atan2(dy, dx);
          gdouble t = 1.0 - r / o->radius; /* Normalize distance (0 at radius, 1 at center) */

          /* Apply pinch effect: adjust the radius */
          gdouble pinch_factor = o->pinch * t * t; /* Quadratic falloff for smoother pinch */
          gdouble new_r = r * (1.0 + pinch_factor); /* Positive pinch pulls in, negative pushes out */
          if (new_r < 0.0) new_r = 0.0; /* Prevent negative radius */

          /* Apply vortex swirl */
          gdouble swirl = o->strength * o->tightness * t;
          gdouble new_theta = theta + swirl + angle_rad;

          /* Compute new coordinates */
          src_x = center_x + new_r * cos(new_theta);
          src_y = center_y + new_r * sin(new_theta);
        }

        /* Sample input at the displaced coordinates */
        gegl_buffer_sample (input, src_x, src_y, NULL, output_pixel, format,
                            GEGL_SAMPLER_LINEAR, GEGL_ABYSS_CLAMP);

        /* Write to the output buffer */
        gint index = ((y - roi.y) * roi.width + (x - roi.x)) * 4;
        out_data[index + 0] = output_pixel[0];
        out_data[index + 1] = output_pixel[1];
        out_data[index + 2] = output_pixel[2];
        out_data[index + 3] = output_pixel[3];
      }
    }
  }

  g_free (output_pixel);
  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationFilterClass *filter_class = GEGL_OPERATION_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  operation_class->get_bounding_box = get_bounding_box;
  operation_class->get_required_for_output = get_required_for_output;
  filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:vortexdistortion",
    "title",       _("Vortex Distortion"),
    "reference-hash", "vortexdistortion2025",
    "description", _("Creates a swirling vortex distortion effect around a central point with a pinch effect"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL/Distortion",
    "gimp:menu-label", _("Vortex Distortion..."),
    NULL);
}

#endif
