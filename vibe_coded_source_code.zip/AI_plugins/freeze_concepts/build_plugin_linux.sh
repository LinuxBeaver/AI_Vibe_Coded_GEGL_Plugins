#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'freezeconcepts.so') $TOP/LinuxBinaries

cd .. 

cd freeze && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'freezeblend.so') $TOP/LinuxBinaries


