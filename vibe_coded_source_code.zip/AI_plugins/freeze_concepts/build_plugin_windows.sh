#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'freezeconcepts.dll') $TOP/WindowsBinaries

cd .. 

cd freeze && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'freezeblend.dll') $TOP/WindowsBinaries


