/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås (pippin) for major GEGL contributions
 * 2025 Beaver and Grok

id=1 ai/lb:freeze aux=[ ref=1 content here ]

 */


#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES



property_enum (filterchoosen, _("Filter Selection"),
    filterchoicefreezememe, filterchoicefreeze_meme,    
chamfer)
    description (_("Choose a filter to blend"))



enum_start (filterchoicefreeze_meme)
  enum_value (chamfer,      "chamfer",
              N_("Chamfer Sharp Bevel"))
  enum_value (bump,      "bump",
              N_("Bump Bevel"))
  enum_value (color,      "color",
              N_("Color Overlay"))
enum_end (filterchoicefreezememe)

property_color (color, _("Color"), "#0454ff")
    description (_("The color to paint over the input"))
ui_meta ("visible", "filterchoosen {color}" )


property_double (bump, _("Bump Radius"), 6.0)
    description (_("Bump Bevel's radius"))
    value_range (1.0, 8.0)
    ui_meta ("unit", "degree")
  ui_steps      (0.01, 0.50)
ui_meta ("visible", "filterchoosen {bump}" )

property_double (elevation, _("Elevation"), 25.0)
    description (_("Elevation angle of the Bevel."))
    value_range (0.0, 180.0)
    ui_meta ("unit", "degree")
  ui_steps      (0.01, 0.50)
ui_meta ("visible", "filterchoosen {chamfer, bump}" )

property_int (depth, _("Depth"), 40)
    description (_("Emboss depth - Brings out depth and detail of the bump bevel."))
    value_range (1, 100)
    ui_range (1, 80)
ui_meta ("visible", "filterchoosen {chamfer, bump}" )

property_double (azimuth, _("Light Angle"), 68.0)
    description (_("Direction of a light source illuminating and shading the bevel."))
    value_range (0, 360)
  ui_steps      (0.01, 0.50)
    ui_meta ("unit", "degree")
    ui_meta ("direction", "ccw")
ui_meta ("visible", "filterchoosen {chamfer, bump}" )

property_boolean (srgb, _("SRGB"), TRUE)
  description    (_("Enable the blend mode's SRGB"))


property_double (opacity, _("Hyper Opacity"), 1.0)
  value_range   (0.0, 2.0)
  ui_range      (0.0, 2.0)
  ui_steps      (1, 5)
  ui_gamma      (1.5)




#else

#define GEGL_OP_META
#define GEGL_OP_NAME     freezeconcepts
#define GEGL_OP_C_SOURCE freeze_concepts.c


#include "gegl-op.h"

typedef struct
{
GeglNode *input;
GeglNode *output;
GeglNode *hyperopacity;
GeglNode *freeze;
GeglNode *bumpbevel;
GeglNode *chamferbevel;
GeglNode *coloroverlay;
GeglNode *repair;


} State;

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;
  GeglProperties *o = GEGL_PROPERTIES (operation);

  State *state = o->user_data = g_malloc0 (sizeof (State));

state->input    = gegl_node_get_input_proxy (gegl, "input");
state->output   = gegl_node_get_output_proxy (gegl, "output");


  state->freeze   = gegl_node_new_child (gegl,
                                  "operation", "ai/lb:freeze",    NULL);


  state->chamferbevel   = gegl_node_new_child (gegl,
                                  "operation", "gegl:bevel", "blendmode", 0, "type", 0,  NULL);

  state->bumpbevel   = gegl_node_new_child (gegl,
                                  "operation", "gegl:bevel", "blendmode", 0, "type", 1,  NULL);


  state->coloroverlay   = gegl_node_new_child (gegl,
                                  "operation", "gegl:color-overlay",   NULL);


  state->hyperopacity   = gegl_node_new_child (gegl,
                                  "operation", "gegl:opacity", "value", 1.0,  NULL);

   state->coloroverlay      = gegl_node_new_child (gegl, "operation", "gegl:color-overlay",    NULL);

   state->repair      = gegl_node_new_child (gegl, "operation", "gegl:median-blur", "radius", 0, "abyss-policy", 0,    NULL);


}

static void
update_graph (GeglOperation *operation)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data;
  if (!state) return;
 GeglNode* theory;



  switch (o->filterchoosen) {
    case chamfer: theory = state->chamferbevel; break;
    case bump: theory = state->bumpbevel; break;
    case color: theory = state->coloroverlay; break;
default: theory = state->chamferbevel;
}

   gegl_node_link_many ( state->input, state->freeze,  state->repair,  state->output,   NULL);
   gegl_node_link_many (state->input, theory, state->hyperopacity, NULL);
   gegl_node_connect (state->freeze, "aux", state->hyperopacity, "output");


  gegl_operation_meta_redirect (operation, "srgb", state->freeze, "srgb"); 
  gegl_operation_meta_redirect (operation, "opacity", state->hyperopacity, "value"); 

  gegl_operation_meta_redirect (operation, "color", state->coloroverlay, "value"); 
  gegl_operation_meta_redirect (operation, "bump", state->bumpbevel, "radius"); 
  gegl_operation_meta_redirect (operation, "elevation", state->bumpbevel, "elevation"); 
  gegl_operation_meta_redirect (operation, "azimuth", state->bumpbevel, "azimuth"); 
  gegl_operation_meta_redirect (operation, "depth", state->bumpbevel, "depth"); 
  gegl_operation_meta_redirect (operation, "elevation", state->chamferbevel, "elevation"); 
  gegl_operation_meta_redirect (operation, "azimuth", state->chamferbevel, "azimuth"); 
  gegl_operation_meta_redirect (operation, "depth", state->chamferbevel, "depth"); 

}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;
GeglOperationMetaClass *operation_meta_class = GEGL_OPERATION_META_CLASS (klass);
  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_meta_class->update = update_graph;

  gegl_operation_class_set_keys (operation_class,
    "name",           "ai/lb:freeze-blendings",
    "title",          _("Freeze Blended filters"),
    "reference-hash", "yungbaedisco",
    "description",    _("Use common filters with the Freeze blend mode"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL/Blend Modes",
    "gimp:menu-label", _("Freeze blended filters..."),               
                NULL);
}

#endif
