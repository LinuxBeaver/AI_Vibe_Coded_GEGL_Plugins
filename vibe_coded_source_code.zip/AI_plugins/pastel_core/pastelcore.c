/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 * Pippin for Making GEGL
 * Pastel Core was made by Grok with Beaver's vibe coding
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <math.h>
#include <string.h>
#include <gegl.h>
#include <gegl-plugin.h>

#ifdef GEGL_PROPERTIES

property_double (stroke_size, _("Stroke Size"), 1.0)
    description (_("Thickness of sketch outlines"))
    value_range (0.5, 3.0)
    ui_range (0.8, 2.0)

property_double (color_softness, _("Color Softness"), 1.0)
    description (_("Softness of pastel colors (higher values are more muted)"))
    value_range (0.5, 2.0)
    ui_range (0.8, 1.5)

property_double (texture_strength, _("Chalk Texture"), 1.0)
    description (_("Intensity of chalk-like texture, mimicking smudged strokes"))
    value_range (0.0, 2.0)
    ui_range (0.1, 2.0)

property_double (edge_sensitivity, _("Edge Sensitivity"), 1.0)
    description (_("Prominence of sketch outlines (lower for subtler effect)"))
    value_range (0.5, 3.0)
    ui_range (0.8, 2.5)

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     pastel_sketch_core
#define GEGL_OP_C_SOURCE pastelcore.c

#include "gegl-op.h"

// Multi-scale noise function for chalk texture
static float
hash_noise (float x, float y, float scale)
{
  float fx = x * 0.1031 * scale;
  float fy = y * 0.1030 * scale;
  float dot = fx * fx + fy * fy;
  float frac = sin (dot) * 43758.5453123;
  return fmod (frac, 1.0);
}

static float
chalk_noise (float x, float y)
{
  // Combine multiple noise scales for patchy chalk effect
  float n1 = hash_noise (x, y, 0.1); // Fine noise
  float n2 = hash_noise (x, y, 0.05); // Medium noise
  float n3 = hash_noise (x, y, 0.02); // Coarse noise
  return (n1 * 0.4 + n2 * 0.35 + n3 * 0.25); // Weighted sum
}

static void
prepare (GeglOperation *operation)
{
  const Babl *space = gegl_operation_get_source_space(operation, "input");
  gegl_operation_set_format(operation, "input", babl_format_with_space("RGBA float", space));
  gegl_operation_set_format(operation, "output", babl_format_with_space("RGBA float", space));
  g_debug ("Preparing pastel-sketch operation");
}

static gboolean
process (GeglOperation       *operation,
         void               *in_buf,
         void               *out_buf,
         glong               n_pixels,
         const GeglRectangle *roi,
         gint                level)
{
  GeglProperties *o = GEGL_PROPERTIES(operation);
  gfloat *in_pixel = (gfloat *) in_buf;
  gfloat *out_pixel = (gfloat *) out_buf;

  // Initialize out_buf with in_buf to ensure valid pixels
  memcpy(out_buf, in_buf, n_pixels * 4 * sizeof(gfloat));
  g_debug ("Initialized out_buf with in_buf, %ld pixels", n_pixels);

  // Allocate temporary buffers
  gfloat *edge_buf = g_new0 (gfloat, n_pixels);
  if (!edge_buf)
  {
    g_warning ("Failed to allocate edge_buf");
    return FALSE;
  }

  gfloat *smooth_buf = g_new0 (gfloat, n_pixels * 4);
  if (!smooth_buf)
  {
    g_warning ("Failed to allocate smooth_buf");
    g_free (edge_buf);
    return FALSE;
  }

  // Get canvas dimensions
  GeglRectangle *canvas = gegl_operation_source_get_bounding_box(operation, "input");
  gint width = canvas ? canvas->width : roi->width;
  gint height = canvas ? canvas->height : roi->height;

  // Log processing details
  g_debug ("Processing pastel-sketch: %ld pixels, ROI (%d,%d,%d,%d), stroke_size=%.2f, color_softness=%.2f, texture_strength=%.2f, edge_sensitivity=%.2f",
           n_pixels, roi->x, roi->y, roi->width, roi->height, o->stroke_size, o->color_softness, o->texture_strength, o->edge_sensitivity);

  // Step 1: Edge detection with light luminance smoothing
  g_debug ("Starting edge detection");
  glong edge_count = 0;
  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    edge_buf[i] = 0.0;
    if (x >= 1 && x < width - 1 && y >= 1 && y < height - 1 &&
        x >= roi->x && x < roi->x + roi->width &&
        y >= roi->y && y < roi->y + roi->height)
    {
      gfloat lum_center = 0.0, lum_left = 0.0, lum_right = 0.0, lum_top = 0.0, lum_bottom = 0.0;
      gfloat lum_sum;
      gint lum_count;

      // Center pixel
      lum_sum = 0.0; lum_count = 0;
      for (gint dy = -1; dy <= 1; dy++)
      {
        for (gint dx = -1; dx <= 1; dx++)
        {
          gint nx = x + dx;
          gint ny = y + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
              nx >= roi->x && nx < roi->x + roi->width &&
              ny >= roi->y && ny < roi->y + roi->height)
          {
            glong nidx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
            if (nidx >= 0 && nidx < n_pixels * 4)
            {
              lum_sum += 0.299 * in_pixel[nidx] + 0.587 * in_pixel[nidx + 1] + 0.114 * in_pixel[nidx + 2];
              lum_count++;
            }
            else if (i < 10)
              g_debug ("Edge detection: Invalid nidx=%ld at x=%d, y=%d, nx=%d, ny=%d", nidx, x, y, nx, ny);
          }
        }
      }
      lum_center = lum_count > 0 ? lum_sum / lum_count : 0.0;

      // Left neighbor
      lum_sum = 0.0; lum_count = 0;
      for (gint dy = -1; dy <= 1; dy++)
      {
        for (gint dx = -1; dx <= 1; dx++)
        {
          gint nx = x - 1 + dx;
          gint ny = y + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
              nx >= roi->x && nx < roi->x + roi->width &&
              ny >= roi->y && ny < roi->y + roi->height)
          {
            glong nidx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
            if (nidx >= 0 && nidx < n_pixels * 4)
            {
              lum_sum += 0.299 * in_pixel[nidx] + 0.587 * in_pixel[nidx + 1] + 0.114 * in_pixel[nidx + 2];
              lum_count++;
            }
            else if (i < 10)
              g_debug ("Edge detection (left): Invalid nidx=%ld at x=%d, y=%d, nx=%d, ny=%d", nidx, x, y, nx, ny);
          }
        }
      }
      lum_left = lum_count > 0 ? lum_sum / lum_count : 0.0;

      // Right neighbor
      lum_sum = 0.0; lum_count = 0;
      for (gint dy = -1; dy <= 1; dy++)
      {
        for (gint dx = -1; dx <= 1; dx++)
        {
          gint nx = x + 1 + dx;
          gint ny = y + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
              nx >= roi->x && nx < roi->x + roi->width &&
              ny >= roi->y && ny < roi->y + roi->height)
          {
            glong nidx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
            if (nidx >= 0 && nidx < n_pixels * 4)
            {
              lum_sum += 0.299 * in_pixel[nidx] + 0.587 * in_pixel[nidx + 1] + 0.114 * in_pixel[nidx + 2];
              lum_count++;
            }
            else if (i < 10)
              g_debug ("Edge detection (right): Invalid nidx=%ld at x=%d, y=%d, nx=%d, ny=%d", nidx, x, y, nx, ny);
          }
        }
      }
      lum_right = lum_count > 0 ? lum_sum / lum_count : 0.0;

      // Top neighbor
      lum_sum = 0.0; lum_count = 0;
      for (gint dy = -1; dy <= 1; dy++)
      {
        for (gint dx = -1; dx <= 1; dx++)
        {
          gint nx = x + dx;
          gint ny = y - 1 + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
              nx >= roi->x && nx < roi->x + roi->width &&
              ny >= roi->y && ny < roi->y + roi->height)
          {
            glong nidx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
            if (nidx >= 0 && nidx < n_pixels * 4)
            {
              lum_sum += 0.299 * in_pixel[nidx] + 0.587 * in_pixel[nidx + 1] + 0.114 * in_pixel[nidx + 2];
              lum_count++;
            }
            else if (i < 10)
              g_debug ("Edge detection (top): Invalid nidx=%ld at x=%d, y=%d, nx=%d, ny=%d", nidx, x, y, nx, ny);
          }
        }
      }
      lum_top = lum_count > 0 ? lum_sum / lum_count : 0.0;

      // Bottom neighbor
      lum_sum = 0.0; lum_count = 0;
      for (gint dy = -1; dy <= 1; dy++)
      {
        for (gint dx = -1; dx <= 1; dx++)
        {
          gint nx = x + dx;
          gint ny = y + 1 + dy;
          if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
              nx >= roi->x && nx < roi->x + roi->width &&
              ny >= roi->y && ny < roi->y + roi->height)
          {
            glong nidx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
            if (nidx >= 0 && nidx < n_pixels * 4)
            {
              lum_sum += 0.299 * in_pixel[nidx] + 0.587 * in_pixel[nidx + 1] + 0.114 * in_pixel[nidx + 2];
              lum_count++;
            }
            else if (i < 10)
              g_debug ("Edge detection (bottom): Invalid nidx=%ld at x=%d, y=%d, nx=%d, ny=%d", nidx, x, y, nx, ny);
          }
        }
      }
      lum_bottom = lum_count > 0 ? lum_sum / lum_count : 0.0;

      gfloat gx = lum_right - lum_left;
      gfloat gy = lum_bottom - lum_top;
      gfloat grad = sqrt (gx * gx + gy * gy) * o->edge_sensitivity * 0.8;
      if (grad > 0.05 && grad > (0.1 / o->stroke_size))
      {
        edge_buf[i] = 1.0;
        edge_count++;
        if (edge_count < 50)
          g_debug ("Edge at pixel %ld: x=%d, y=%d, grad=%.3f", i, x, y, grad);
      }
    }
    if (i < 10 && edge_buf[i] > 0.0)
      g_debug ("Edge_buf[%ld] = %.1f at x=%d, y=%d", i, edge_buf[i], x, y);
  }
  g_debug ("Edge detection complete, %ld edges detected", edge_count);

  // Step 2: Color softening
  g_debug ("Starting color softening");
  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    gfloat r = 0.0, g = 0.0, b = 0.0, a = 0.0;
    gfloat weight_sum = 0.0;

    for (gint dy = -1; dy <= 1; dy++)
    {
      for (gint dx = -1; dx <= 1; dx++)
      {
        gint nx = x + dx;
        gint ny = y + dy;
        if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
            nx >= roi->x && nx < roi->x + roi->width &&
            ny >= roi->y && ny < roi->y + roi->height)
        {
          glong idx = ((ny - roi->y) * roi->width + (nx - roi->x)) * 4;
          if (idx >= 0 && idx < n_pixels * 4)
          {
            gfloat weight = exp (-(dx * dx + dy * dy) / (2.0 * o->color_softness * o->color_softness));
            r += in_pixel[idx] * weight;
            g += in_pixel[idx + 1] * weight;
            b += in_pixel[idx + 2] * weight;
            a += in_pixel[idx + 3] * weight;
            weight_sum += weight;
          }
          else if (i < 10)
            g_debug ("Softening: Invalid idx=%ld at x=%d, y=%d, nx=%d, ny=%d", idx, x, y, nx, ny);
        }
      }
    }

    if (weight_sum > 0.0)
    {
      smooth_buf[i * 4] = r / weight_sum;
      smooth_buf[i * 4 + 1] = g / weight_sum;
      smooth_buf[i * 4 + 2] = b / weight_sum;
      smooth_buf[i * 4 + 3] = a / weight_sum;
      if (i < 10)
        g_debug ("Softening at pixel %ld: r=%.3f, g=%.3f, b=%.3f", i, r / weight_sum, g / weight_sum, b / weight_sum);
    }
    else
    {
      glong idx = ((y - roi->y) * roi->width + (x - roi->x)) * 4;
      if (idx >= 0 && idx < n_pixels * 4)
      {
        smooth_buf[i * 4] = in_pixel[idx];
        smooth_buf[i * 4 + 1] = in_pixel[idx + 1];
        smooth_buf[i * 4 + 2] = in_pixel[idx + 2];
        smooth_buf[i * 4 + 3] = in_pixel[idx + 3];
        if (i < 10)
          g_debug ("Softening fallback at pixel %ld: r=%.3f, g=%.3f, b=%.3f", i, in_pixel[idx], in_pixel[idx + 1], in_pixel[idx + 2]);
      }
      else
      {
        smooth_buf[i * 4] = 0.0;
        smooth_buf[i * 4 + 1] = 0.0;
        smooth_buf[i * 4 + 2] = 0.0;
        smooth_buf[i * 4 + 3] = 0.0;
        if (i < 10)
          g_debug ("Softening fallback out of bounds at pixel %ld: x=%d, y=%d, setting to black", i, x, y);
      }
    }
  }
  g_debug ("Color softening complete");

  // Step 3: Color adjustment and chalk texture
  g_debug ("Starting color adjustment and chalk texture");
  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    gfloat r = smooth_buf[i * 4];
    gfloat g = smooth_buf[i * 4 + 1];
    gfloat b = smooth_buf[i * 4 + 2];
    gfloat a = smooth_buf[i * 4 + 3];

    // RGB to HSL
    gfloat max = fmax (fmax (r, g), b);
    gfloat min = fmin (fmin (r, g), b);
    gfloat h, s, l;

    l = (max + min) / 2.0;
    if (max == min)
    {
      h = s = 0.0;
    }
    else
    {
      gfloat d = max - min;
      s = l > 0.5 ? d / (2.0 - max - min) : d / (max + min);
      if (max == r)
        h = (g - b) / d + (g < b ? 6.0 : 0.0);
      else if (max == g)
        h = (b - r) / d + 2.0;
      else
        h = (r - g) / d + 4.0;
      h /= 6.0;
    }

    // Adjust HSL
    l = fmin (l * 1.2, 0.9);
    s = fmax (s * (1.0 - o->color_softness * 0.4), 0.3);

    // Apply chalk texture
    gfloat noise = chalk_noise (x, y);
    // Normalize noise to 0.0–1.0
    noise = fmin (fmax (noise, 0.0), 1.0);
    // Smudge effect: average noise with neighbors
    gfloat smudged_noise = noise;
    gfloat noise_sum = noise;
    gfloat noise_count = 1.0;
    for (gint dy = -1; dy <= 1; dy++)
    {
      for (gint dx = -1; dx <= 1; dx++)
      {
        if (dx == 0 && dy == 0) continue;
        gint nx = x + dx;
        gint ny = y + dy;
        if (nx >= 0 && nx < width && ny >= 0 && ny < height &&
            nx >= roi->x && nx < roi->x + roi->width &&
            ny >= roi->y && ny < roi->y + roi->height)
        {
          gfloat neighbor_noise = chalk_noise (nx, ny);
          gfloat weight = exp (-(dx * dx + dy * dy) / (2.0 * o->texture_strength * 2.0));
          noise_sum += neighbor_noise * weight;
          noise_count += weight;
        }
      }
    }
    smudged_noise = noise_sum / noise_count;
    // Edge-aware texture: amplify near edges
    gfloat edge_factor = edge_buf[i] > 0.0 ? 1.5 : 1.0;
    gfloat texture = smudged_noise * o->texture_strength * edge_factor;
    // Apply to lightness
    l = fmax (l - texture * 0.4, 0.0);
    // Subtle hue/saturation variation for pigment
    h += (smudged_noise - 0.5) * o->texture_strength * 0.05;
    if (h < 0.0) h += 1.0;
    if (h > 1.0) h -= 1.0;
    s = fmin (fmax (s + (smudged_noise - 0.5) * o->texture_strength * 0.1, 0.0), 1.0);

    // HSL to RGB
    if (s == 0.0)
    {
      r = g = b = l;
    }
    else
    {
      gfloat q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
      gfloat p = 2.0 * l - q;
      gfloat t[3] = { h + 1.0 / 3.0, h, h - 1.0 / 3.0 };
      for (int j = 0; j < 3; j++)
      {
        if (t[j] < 0.0) t[j] += 1.0;
        if (t[j] > 1.0) t[j] -= 1.0;
        gfloat c;
        if (t[j] < 1.0 / 6.0)
          c = p + (q - p) * 6.0 * t[j];
        else if (t[j] < 0.5)
          c = q;
        else if (t[j] < 2.0 / 3.0)
          c = p + (q - p) * (2.0 / 3.0 - t[j]) * 6.0;
        else
          c = p;
        if (j == 0) r = c;
        else if (j == 1) g = c;
        else b = c;
      }
    }

    // Apply edges
    if (edge_buf[i] > 0.0)
    {
      r = fmax (r * 0.5, 0.2);
      g = fmax (g * 0.5, 0.2);
      b = fmax (b * 0.5, 0.2);
    }

    // Clamp values to prevent saturation issues
    out_pixel[i * 4] = fmin (fmax (r, 0.0), 1.0);
    out_pixel[i * 4 + 1] = fmin (fmax (g, 0.0), 1.0);
    out_pixel[i * 4 + 2] = fmin (fmax (b, 0.0), 1.0);
    out_pixel[i * 4 + 3] = fmin (fmax (a, 0.0), 1.0);

    if (i < 10)
      g_debug ("Output at pixel %ld: r=%.3f, g=%.3f, b=%.3f, a=%.3f, edge=%d, texture=%.3f",
               i, out_pixel[i * 4], out_pixel[i * 4 + 1], out_pixel[i * 4 + 2], out_pixel[i * 4 + 3], edge_buf[i] > 0.0 ? 1 : 0, texture);
  }
  g_debug ("Color adjustment and chalk texture complete");

  // Clean up
  g_free (edge_buf);
  g_free (smooth_buf);
  g_debug ("Pastel-sketch processing complete");

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;
  operation_class->no_cache = TRUE; // Disable caching

  gegl_operation_class_set_keys (operation_class,
    "name", "ai/lb:pastel-core",
    "title", _("Pastel Sketch Core"),
    "reference-hash", "pastelsketch2025",
    "description", _("Transforms an image into a soft pastel sketch with textured strokes"),
    "categories", "hidden",
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Pastel Sketch..."),
    NULL);
}

#endif
