#!/bin/bash

gio trash */build

gio trash */SourceCode

gio trash */*.zip

gio trash */*.dll

gio trash */*.so

gio trash */WindowsBinaries

gio trash */LinuxBinaries
