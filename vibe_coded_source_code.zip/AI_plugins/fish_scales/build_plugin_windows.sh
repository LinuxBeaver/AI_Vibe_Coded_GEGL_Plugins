#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'fishscales.dll') $TOP/WindowsBinaries

cd .. 

cd fish_scales_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'fishscalescore.dll') $TOP/WindowsBinaries

cd .. 

