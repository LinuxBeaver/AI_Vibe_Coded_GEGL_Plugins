#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesign.dll') $TOP/WindowsBinaries

cd .. 

cd shape_design_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesigncore.dll') $TOP/WindowsBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.dll') $TOP/WindowsBinaries


