#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesign.so') $TOP/LinuxBinaries

cd .. 

cd shape_design_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'shapedesigncore.so') $TOP/LinuxBinaries

cd .. 

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.so') $TOP/LinuxBinaries

cd .. 

cd port_load && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'loadport.so') $TOP/LinuxBinaries

cd .. 

