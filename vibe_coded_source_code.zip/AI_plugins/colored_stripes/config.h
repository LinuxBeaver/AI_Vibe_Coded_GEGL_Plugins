#ifndef CONFIG_H
#define CONFIG_H

#define GETTEXT_PACKAGE "gegl"
#define ENABLE_NLS 1

#endif
