#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'outlinedeluxe.dll') $TOP/WindowsBinaries

cd ..

cd custom_bevel && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'cbevel.dll') $TOP/WindowsBinaries

cd ..

cd ssg && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'ssg.dll') $TOP/WindowsBinaries

cd .. 

cd port_load && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'loadport.dll') $TOP/WindowsBinaries
 
cd ..

cd metallic && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'metal.dll') $TOP/WindowsBinaries

cd ..

cd chrome_text && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'geglchrome.dll') $TOP/WindowsBinaries

cd ..

cd threshold_alpha2 && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'thresholdalpha2.dll') $TOP/WindowsBinaries

cd ..

cd edge_smooth && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'smoothedge.dll') $TOP/WindowsBinaries




