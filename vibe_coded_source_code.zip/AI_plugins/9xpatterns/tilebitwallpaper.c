/*
 * Pippin (2006) for making GEGL
 * Beaver for vibe coding
 * Grok 3 for making the GEGL plugin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>
#ifdef GEGL_PROPERTIES
enum_start(pattern_type_w95)
  enum_value(W95_WAFFLE_REVENGE, "waffle_revenge", "Waffle’s Revenge")
  enum_value(W95_BRICKS, "bricks", "Bricks")
  enum_value(W95_BUTTONS, "buttons", "Buttons")
  enum_value(W95_CARGO_NET, "cargo_net", "Cargo Net")
  enum_value(W95_CIRCUITS, "circuits", "Circuits")
  enum_value(W95_COBBLESTONES, "cobblestones", "Cobblestones")
  enum_value(W95_COLOSSEUM, "colosseum", "Colosseum")
  enum_value(W95_DAISIES, "daisies", "Daisies")
  enum_value(W95_DIZZY, "dizzy", "Dizzy")
  enum_value(W95_FIELD_EFFECT, "field_effect", "Field Effect")
  enum_value(W95_KEY, "key", "Key")
  enum_value(W95_LIVE_WIRE, "live_wire", "Live Wire")
  enum_value(W95_PLAID, "plaid", "Plaid")
  enum_value(W95_ROUNDER, "rounder", "Rounder")
  enum_value(W95_SCALES, "scales", "Scales")
  enum_value(W95_STONE, "stone", "Stone")
  enum_value(W95_THATCHES, "thatches", "Thatches")
  enum_value(W95_TILE, "tile", "Tile")
  enum_value(W95_TRIANGLES, "triangles", "Triangles")
enum_end(pattern_type_w95)

property_enum(pattern, _("Pattern"),
              pattern_type_w95, pattern_type_w95,
              W95_WAFFLE_REVENGE)
    description(_("Select a classic Windows 95 8x8 desktop pattern"))

property_color(foreground_color, _("Foreground Color"), "#000000")
    description(_("Color of the pattern pixels (usually black in classic patterns)"))

property_color(background_color, _("Background Color"), "#008080")
    description(_("Color of the background (default teal like Windows 95 desktop)"))

property_double(rotation, _("Rotation"), 0.0)
    description(_("Rotate the entire pattern in degrees"))
    value_range(0.0, 360.0)
    ui_range(0.0, 360.0)

property_double(upscale, _("Upscale"), 4.0)
    description(_("Scale factor for the 8x8 pattern (1.0 = original size, higher values enlarge the tiles)"))
    value_range(1.0, 64.0)
    ui_range(1.0, 32.0)
#else
#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME tilebitwallpaper
#define GEGL_OP_C_SOURCE tilebitwallpaper.c
#include "gegl-op.h"

static void prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));
}

static GeglRectangle get_bounding_box (GeglOperation *operation)
{
  return gegl_rectangle_infinite_plane ();
}

static gboolean
process (GeglOperation *operation,
         GeglOperationContext *context,
         const gchar *output_prop,
         const GeglRectangle *result,
         gint level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  GeglBuffer *output = gegl_operation_context_get_target (context, output_prop);
  gdouble fg_color[4], bg_color[4];
  GeglRectangle rect = *result;
  gint x, y;

  gegl_color_get_rgba (o->foreground_color, &fg_color[0], &fg_color[1], &fg_color[2], &fg_color[3]);
  gegl_color_get_rgba (o->background_color, &bg_color[0], &bg_color[1], &bg_color[2], &bg_color[3]);

  gdouble rotation_rad = o->rotation * G_PI / 180.0;
  gdouble cos_rot = cos(rotation_rad);
  gdouble sin_rot = sin(rotation_rad);

  // Base 8x8 pattern size, multiplied by upscale factor
  gdouble base_size = 8.0;
  gdouble tile_size = base_size * o->upscale;

  // Precompute the 8-bit pattern rows for the selected pattern (MSB left)
  guint8 pattern_rows[8];
  switch (o->pattern)
  {
    case W95_WAFFLE_REVENGE:  // 77 154 8 85 239 154 77 154
      pattern_rows[0] = 77; pattern_rows[1] = 154; pattern_rows[2] = 8; pattern_rows[3] = 85;
      pattern_rows[4] = 239; pattern_rows[5] = 154; pattern_rows[6] = 77; pattern_rows[7] = 154; break;
    case W95_BRICKS:  // 187 95 174 93 186 117 234 245
      pattern_rows[0] = 187; pattern_rows[1] = 95; pattern_rows[2] = 174; pattern_rows[3] = 93;
      pattern_rows[4] = 186; pattern_rows[5] = 117; pattern_rows[6] = 234; pattern_rows[7] = 245; break;
    case W95_BUTTONS:  // 170 125 198 71 198 127 190 85
      pattern_rows[0] = 170; pattern_rows[1] = 125; pattern_rows[2] = 198; pattern_rows[3] = 71;
      pattern_rows[4] = 198; pattern_rows[5] = 127; pattern_rows[6] = 190; pattern_rows[7] = 85; break;
    case W95_CARGO_NET:  // 120 49 19 135 225 200 140 30
      pattern_rows[0] = 120; pattern_rows[1] = 49; pattern_rows[2] = 19; pattern_rows[3] = 135;
      pattern_rows[4] = 225; pattern_rows[5] = 200; pattern_rows[6] = 140; pattern_rows[7] = 30; break;
    case W95_CIRCUITS:  // 82 41 132 66 148 41 66 132
      pattern_rows[0] = 82; pattern_rows[1] = 41; pattern_rows[2] = 132; pattern_rows[3] = 66;
      pattern_rows[4] = 148; pattern_rows[5] = 41; pattern_rows[6] = 66; pattern_rows[7] = 132; break;
    case W95_COBBLESTONES:  // 40 68 146 171 214 108 56 16
      pattern_rows[0] = 40; pattern_rows[1] = 68; pattern_rows[2] = 146; pattern_rows[3] = 171;
      pattern_rows[4] = 214; pattern_rows[5] = 108; pattern_rows[6] = 56; pattern_rows[7] = 16; break;
    case W95_COLOSSEUM:  // 130 1 1 1 171 85 170 85
      pattern_rows[0] = 130; pattern_rows[1] = 1; pattern_rows[2] = 1; pattern_rows[3] = 1;
      pattern_rows[4] = 171; pattern_rows[5] = 85; pattern_rows[6] = 170; pattern_rows[7] = 85; break;
    case W95_DAISIES:  // 30 140 216 253 191 27 49 120
      pattern_rows[0] = 30; pattern_rows[1] = 140; pattern_rows[2] = 216; pattern_rows[3] = 253;
      pattern_rows[4] = 191; pattern_rows[5] = 27; pattern_rows[6] = 49; pattern_rows[7] = 120; break;
    case W95_DIZZY:  // 62 7 225 7 62 112 195 112
      pattern_rows[0] = 62; pattern_rows[1] = 7; pattern_rows[2] = 225; pattern_rows[3] = 7;
      pattern_rows[4] = 62; pattern_rows[5] = 112; pattern_rows[6] = 195; pattern_rows[7] = 112; break;
    case W95_FIELD_EFFECT:  // 86 89 166 154 101 149 106 169
      pattern_rows[0] = 86; pattern_rows[1] = 89; pattern_rows[2] = 166; pattern_rows[3] = 154;
      pattern_rows[4] = 101; pattern_rows[5] = 149; pattern_rows[6] = 106; pattern_rows[7] = 169; break;
    case W95_KEY:  // 254 2 250 138 186 162 190 128
      pattern_rows[0] = 254; pattern_rows[1] = 2; pattern_rows[2] = 250; pattern_rows[3] = 138;
      pattern_rows[4] = 186; pattern_rows[5] = 162; pattern_rows[6] = 190; pattern_rows[7] = 128; break;
    case W95_LIVE_WIRE:  // 239 239 14 254 254 254 224 239
      pattern_rows[0] = 239; pattern_rows[1] = 239; pattern_rows[2] = 14; pattern_rows[3] = 254;
      pattern_rows[4] = 254; pattern_rows[5] = 254; pattern_rows[6] = 224; pattern_rows[7] = 239; break;
    case W95_PLAID:  // 240 240 240 240 170 85 170 85
      pattern_rows[0] = 240; pattern_rows[1] = 240; pattern_rows[2] = 240; pattern_rows[3] = 240;
      pattern_rows[4] = 170; pattern_rows[5] = 85; pattern_rows[6] = 170; pattern_rows[7] = 85; break;
    case W95_ROUNDER:  // 215 147 40 215 40 147 213 215
      pattern_rows[0] = 215; pattern_rows[1] = 147; pattern_rows[2] = 40; pattern_rows[3] = 215;
      pattern_rows[4] = 40; pattern_rows[5] = 147; pattern_rows[6] = 213; pattern_rows[7] = 215; break;
    case W95_SCALES:  // 225 42 37 146 85 152 62 247
      pattern_rows[0] = 225; pattern_rows[1] = 42; pattern_rows[2] = 37; pattern_rows[3] = 146;
      pattern_rows[4] = 85; pattern_rows[5] = 152; pattern_rows[6] = 62; pattern_rows[7] = 247; break;
    case W95_STONE:  // 174 77 239 255 8 77 174 77
      pattern_rows[0] = 174; pattern_rows[1] = 77; pattern_rows[2] = 239; pattern_rows[3] = 255;
      pattern_rows[4] = 8; pattern_rows[5] = 77; pattern_rows[6] = 174; pattern_rows[7] = 77; break;
    case W95_THATCHES:  // 248 116 34 71 143 23 34 113
      pattern_rows[0] = 248; pattern_rows[1] = 116; pattern_rows[2] = 34; pattern_rows[3] = 71;
      pattern_rows[4] = 143; pattern_rows[5] = 23; pattern_rows[6] = 34; pattern_rows[7] = 113; break;
    case W95_TILE:  // 69 130 1 0 1 130 69 170
      pattern_rows[0] = 69; pattern_rows[1] = 130; pattern_rows[2] = 1; pattern_rows[3] = 0;
      pattern_rows[4] = 1; pattern_rows[5] = 130; pattern_rows[6] = 69; pattern_rows[7] = 170; break;
    case W95_TRIANGLES:  // 135 7 6 4 0 247 231 199
      pattern_rows[0] = 135; pattern_rows[1] = 7; pattern_rows[2] = 6; pattern_rows[3] = 4;
      pattern_rows[4] = 0; pattern_rows[5] = 247; pattern_rows[6] = 231; pattern_rows[7] = 199; break;
  }

  for (y = rect.y; y < rect.y + rect.height; y++)
  {
    for (x = rect.x; x < rect.x + rect.width; x++)
    {
      gdouble px = (gdouble)x;
      gdouble py = (gdouble)y;

      // Apply rotation around origin
      gdouble px_rot = px * cos_rot - py * sin_rot;
      gdouble py_rot = px * sin_rot + py * cos_rot;

      // Map to tiled space
      gdouble tx = fmod(px_rot, tile_size);
      gdouble ty = fmod(py_rot, tile_size);
      if (tx < 0) tx += tile_size;
      if (ty < 0) ty += tile_size;

      // Map to 8x8 logical coordinates (integer pixel within the upscaled tile)
      gint pat_x = (gint)floor(tx / o->upscale) % 8;
      gint pat_y = (gint)floor(ty / o->upscale) % 8;

      // Get the bit: MSB (bit 7) is leftmost pixel
      guint8 row = pattern_rows[pat_y];
      gboolean is_foreground = (row & (1 << (7 - pat_x))) != 0;

      gfloat out[4];
      if (is_foreground)
      {
        out[0] = fg_color[0];
        out[1] = fg_color[1];
        out[2] = fg_color[2];
        out[3] = 1.0;
      }
      else
      {
        out[0] = bg_color[0];
        out[1] = bg_color[1];
        out[2] = bg_color[2];
        out[3] = 1.0;
      }

      gegl_buffer_set (output, GEGL_RECTANGLE (x, y, 1, 1), 0, babl_format ("RGBA float"), out, GEGL_AUTO_ROWSTRIDE);
    }
  }
  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  operation_class->prepare = prepare;
  operation_class->get_bounding_box = get_bounding_box;
  operation_class->process = process;
  gegl_operation_class_set_keys(operation_class,
    "name", "ai/lb:bit-tile-wallpapers",
    "title", _("Bit tile wallpapers"),
    "reference-hash", "windowsninetyfivepat",
    "description", _("Bit tile wallpapers inspired by the ones from classic old computers"),
    NULL);
}
#endif
