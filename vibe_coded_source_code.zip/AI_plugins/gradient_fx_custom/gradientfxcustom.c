/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 * Pippin (for writing GEGL's node chain area in 2006)
 * Grok (for the gradient)
 * Beaver (for chaining the nodes manually with inner glow and outline)
 * gegl:inner-glow or lb:ssg
 * id=1 multiply aux=[ ref=1 ai/lb:gradient ]  
 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES

enum_start(grok2_mode39148)
  enum_value(OUTLINE_TIME, "outline", N_("Outline Glow"))
  enum_value(OUTLINE_BEVEL_TIME, "outline_bevel", N_("Outline Bevel"))
  enum_value(INNERGLOW_TIME, "inner_glow", N_("Inner Glow"))
  enum_value(SHADOW_TIME, "shadow", N_("Shadow"))
enum_end(Grok2Mode39148)



enum_start(grok2_gradient_shape22358)
  enum_value(GROK2_SHAPE_LINEAR, "linear", N_("Linear"))
  enum_value(GROK2_SHAPE_BILINEAR, "bilinear", N_("Bilinear"))
  enum_value(GROK2_SHAPE_RADIAL, "radial", N_("Radial"))
  enum_value(GROK2_SHAPE_SPIRAL, "spiral", N_("Spiral"))
  enum_value(GROK2_SHAPE_SPIRAL_CCW, "spiral_ccw", N_("Spiral Counter-Clockwise"))
  enum_value(GROK2_SHAPE_SQUARE, "square", N_("Square"))
enum_end(Grok2GradientShape22358)

property_enum(mode, _("Effect Mode"), Grok2Mode39148, grok2_mode39148, INNERGLOW_TIME)
    description(_("Select the effect to apply: Outline, Bevel, or Inner Glow"))

property_double(radius, _("Radius"), 7.0)
    description(_("Blur radius for the effect"))
    value_range(0.0, 100.0)
    ui_range(0.0, 20.0)



property_int(grow_radius, _("Grow Radius"), 3)
    description(_("Amount to grow the outline or bevel"))
    value_range(0, 50)
    ui_range(0, 25)
    ui_meta("visible", "mode{outline,bevel}")


property_double(opacity, _("Opacity"), 1.5)
    description(_("Opacity of the effect"))
    value_range(0.0, 2.0)
    ui_range(0.0, 2.0)


property_double(x, _("X of effect"), 0.0)
    description(_("Horizontal movement of the effect"))
    value_range(-50.0, 50.0)


property_double(y, _("Y of effect"), 0.0)
    description(_("Vertical movement of the effect"))
    value_range(-50.0, 50.0)
    ui_range(-50, 50.0)
    ui_meta("unit", "percent")


property_enum(gradient_shape, _("Gradient Shape"), Grok2GradientShape22358, grok2_gradient_shape22358, GROK2_SHAPE_LINEAR)
    description(_("Shape of the gradient pattern"))

property_double(angle, _("Gradient Angle"), 0.0)
    description(_("Angle of the gradient in degrees"))
    value_range(0.0, 360.0)
    ui_meta("unit", "degree")
    ui_meta("direction", "ccw")
    ui_meta("visible", "!gradient_shape{radial,square}")

property_double(frequency, _("Frequency"), 1.0)
    description(_("Number of gradient cycles across the image"))
    value_range(0.1, 10.0)
    ui_range(0.1, 5.0)
    ui_meta("visible", "!gradient_shape{spiral,spiral_ccw}")

property_int(frequency_2, _("Spiral Frequency"), 1)
    description(_("Number of spiral gradient cycles across the image"))
    value_range(1, 10)
    ui_range(1, 10)
    ui_meta("visible", "gradient_shape{spiral,spiral_ccw}")

property_double(saturation, _("Saturation"), 1.0)
    description(_("Color intensity (0.0 = grayscale, 1.0 = full color)"))
    value_range(0.0, 1.0)
    ui_range(0.5, 1.0)

property_double(brightness, _("Brightness"), 1.0)
    description(_("Color brightness (0.0 = dark, 1.0 = bright)"))
    value_range(0.0, 1.0)
    ui_range(0.5, 1.0)

property_double(offset_x, _("X Offset"), 0.0)
    description(_("Horizontal offset of the gradient center (as a percentage of image width)"))
    value_range(-100.0, 100.0)
    ui_range(-100.0, 100.0)
    ui_meta("unit", "percent")

property_double(offset_y, _("Y Offset"), 0.0)
    description(_("Vertical offset of the gradient center (as a percentage of image height)"))
    value_range(-100.0, 100.0)
    ui_range(-100.0, 100.0)
    ui_meta("unit", "percent")


enum_start (gegl_grokgradient_num_colors71948)
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_2_7194, "two",   N_("2 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_3_7194, "three", N_("3 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_4_7194, "four",  N_("4 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_5_7194, "five",  N_("5 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_6_7194, "six",   N_("6 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_7_7194, "seven", N_("7 Colors"))
  enum_value (GEGL_GROKGRADIENT_NUM_COLORS_8_7194, "eight", N_("8 Colors"))
enum_end (GeglGrokgradientNumColors71948)

property_enum (num_colors, _("Number of Colors"),
               GeglGrokgradientNumColors71948, gegl_grokgradient_num_colors71948,
               GEGL_GROKGRADIENT_NUM_COLORS_2_7194)
    description (_("Number of colors in the gradient (2 to 8)"))

property_color (color1, _("Color 1"), "#ff6f61") // Coral
    description (_("First color of the gradient"))

property_color (color2, _("Color 2"), "#00ff48") // Green
    description (_("Second color of the gradient"))
    ui_meta ("visible", "num_colors {two,three,four,five,six,seven,eight}")

property_color (color3, _("Color 3"), "#fff176") // Lemon Yellow
    description (_("Third color of the gradient"))
    ui_meta ("visible", "num_colors {three,four,five,six,seven,eight}")

property_color (color4, _("Color 4"), "#ce93d8") // Lavender
    description (_("Fourth color of the gradient"))
    ui_meta ("visible", "num_colors {four,five,six,seven,eight}")

property_color (color5, _("Color 5"), "#4caf50") // Emerald Green
    description (_("Fifth color of the gradient"))
    ui_meta ("visible", "num_colors {five,six,seven,eight}")

property_color (color6, _("Color 6"), "#3f51b5") // Sapphire Blue
    description (_("Sixth color of the gradient"))
    ui_meta ("visible", "num_colors {six,seven,eight}")

property_color (color7, _("Color 7"), "#ec407a") // Magenta
    description (_("Seventh color of the gradient"))
    ui_meta ("visible", "num_colors {seven,eight}")

property_color (color8, _("Color 8"), "#37474f") // Charcoal
    description (_("Eighth color of the gradient"))
    ui_meta ("visible", "num_colors {eight}")



#else

#define GEGL_OP_META
#define GEGL_OP_NAME     mycustomgradientoutline
#define GEGL_OP_C_SOURCE gradientfxcustom.c



#include "gegl-op.h"

typedef struct
{
 GeglNode *input;
 GeglNode *multiply;
 GeglNode *outline;
 GeglNode *outlinebevel;
 GeglNode *innerglow;
 GeglNode *gradient;
 GeglNode *shadow;
 GeglNode *behind;
 GeglNode *idref2;
 GeglNode *idref;
 GeglNode *repair;
 GeglNode *output;
}State;

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;


  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data = g_malloc0 (sizeof (State));



  GeglColor *white1 = gegl_color_new ("#ffffff");
  /*GeglColor *white2 = gegl_color_new ("#ffffff");*/
  GeglColor *white3 = gegl_color_new ("#ffffff");
  GeglColor *white4 = gegl_color_new ("#ffffff");

state->input    = gegl_node_get_input_proxy (gegl, "input");

state->multiply = gegl_node_new_child (gegl, "operation", "gegl:nop", NULL);
state->multiply = gegl_node_new_child (gegl, "operation", "gegl:multiply", NULL);
state->shadow = gegl_node_new_child (gegl, "operation", "lb:shadow", "color", white4, NULL);
state->behind = gegl_node_new_child (gegl, "operation", "gegl:dst-over", NULL);
state->idref = gegl_node_new_child (gegl, "operation", "gegl:nop", NULL);
state->repair = gegl_node_new_child (gegl, "operation", "gegl:median-blur", "radius", 0, "abyss-policy", 0, NULL);
state->idref2 = gegl_node_new_child (gegl, "operation", "gegl:nop", NULL);
state->gradient = gegl_node_new_child (gegl, "operation", "ai/lb:custom-gradient", "alpha-lock", TRUE, NULL);
state->innerglow = gegl_node_new_child (gegl, "operation", "gegl:inner-glow", "value", white1, NULL);
state->outlinebevel = gegl_node_new_child (gegl, "operation", "lb:outlinebevel", "mode", 3,  NULL);
state->outline = gegl_node_new_child (gegl, "operation", "lb:outlinebevel", "mode", 0, "color", white3, NULL);

state->output   = gegl_node_get_output_proxy (gegl, "output");


 gegl_operation_meta_redirect (operation, "radius", state->outline,  "blurstroke");
 gegl_operation_meta_redirect (operation, "radius", state->outlinebevel,  "blurstroke");
 gegl_operation_meta_redirect (operation, "radius", state->innerglow,  "radius");
 gegl_operation_meta_redirect (operation, "grow_radius", state->outline,  "stroke");
 gegl_operation_meta_redirect (operation, "grow_radius", state->outlinebevel,  "stroke");
 gegl_operation_meta_redirect (operation, "grow_radius", state->innerglow,  "grow_radius");
 gegl_operation_meta_redirect (operation, "opacity", state->outline,  "opacity");
 gegl_operation_meta_redirect (operation, "opacity", state->outlinebevel,  "opacity");
 gegl_operation_meta_redirect (operation, "opacity", state->innerglow,  "opacity");
 gegl_operation_meta_redirect (operation, "x", state->outline,  "x");
 gegl_operation_meta_redirect (operation, "x", state->outlinebevel,  "x");
 gegl_operation_meta_redirect (operation, "x", state->innerglow,  "x");
 gegl_operation_meta_redirect (operation, "y", state->outline,  "y");
 gegl_operation_meta_redirect (operation, "y", state->outlinebevel,  "y");
 gegl_operation_meta_redirect (operation, "y", state->innerglow,  "y");

 gegl_operation_meta_redirect (operation, "y", state->shadow,  "y");
 gegl_operation_meta_redirect (operation, "x", state->shadow,  "x");
 gegl_operation_meta_redirect (operation, "opacity", state->shadow,  "opacity");
 gegl_operation_meta_redirect (operation, "grow_radius", state->shadow,  "growradius");
 gegl_operation_meta_redirect (operation, "radius", state->shadow,  "radius");

 gegl_operation_meta_redirect (operation, "gradient_type", state->gradient,  "gradient_type");
 gegl_operation_meta_redirect (operation, "gradient_shape", state->gradient,  "gradient_shape");
 gegl_operation_meta_redirect (operation, "angle", state->gradient,  "angle");
 gegl_operation_meta_redirect (operation, "frequency", state->gradient,  "frequency");
 gegl_operation_meta_redirect (operation, "frequency_2", state->gradient,  "frequency_2");
 gegl_operation_meta_redirect (operation, "saturation", state->gradient,  "saturation");
 gegl_operation_meta_redirect (operation, "brightness", state->gradient,  "brightness");
 gegl_operation_meta_redirect (operation, "offset_x", state->gradient,  "offset_x");
 gegl_operation_meta_redirect (operation, "offset_y", state->gradient,  "offset_y");
 gegl_operation_meta_redirect (operation, "num_colors", state->gradient,  "num_colors");
 gegl_operation_meta_redirect (operation, "color1", state->gradient,  "color1");
 gegl_operation_meta_redirect (operation, "color2", state->gradient,  "color2");
 gegl_operation_meta_redirect (operation, "color3", state->gradient,  "color3");
 gegl_operation_meta_redirect (operation, "color4", state->gradient,  "color4");
 gegl_operation_meta_redirect (operation, "color5", state->gradient,  "color5");
 gegl_operation_meta_redirect (operation, "color6", state->gradient,  "color6");
 gegl_operation_meta_redirect (operation, "color7", state->gradient,  "color7");
 gegl_operation_meta_redirect (operation, "color8", state->gradient,  "color8");

}
static void
update_graph (GeglOperation *operation)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data;
  if (!state) return;





switch (o->mode) {
        break;
    case OUTLINE_TIME:
  gegl_node_link_many (state->input, state->outline, state->gradient,    state->output,  NULL);
        break;
    case OUTLINE_BEVEL_TIME:
  gegl_node_link_many (state->input, state->gradient, state->outlinebevel,   state->output,  NULL);
        break;
    case INNERGLOW_TIME:
  gegl_node_link_many (state->input, state->innerglow,  state->gradient,  state->output,  NULL);
        break;
    case SHADOW_TIME:
  gegl_node_link_many (state->input, state->behind,   state->output,  NULL);
  gegl_node_link_many (state->input, state->shadow, state->repair, state->gradient,    NULL);
  gegl_node_connect (state->behind, "aux", state->gradient, "output"); 
     }
    }
   

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;
GeglOperationMetaClass *operation_meta_class = GEGL_OPERATION_META_CLASS (klass);
  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_meta_class->update = update_graph;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:custom-gradient-fx",
    "title",       _("Custom Gradient for fx"),
    "reference-hash", "solonelysolonely",
    "description", _("Make a user defined gradient overlay that can apply over popular fx"),
/*<Image>/Colors <Image>/Filters are top level menus in GIMP*/
    "gimp:menu-path", "<Image>/Filters/AI GEGL/Gradients",
    "gimp:menu-label", _("Custom Gradient for fx..."),
    NULL);
}

#endif
