#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'grainechoconcepts.dll') $TOP/WindowsBinaries

cd .. 

cd grain_echo && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'grainecho.dll') $TOP/WindowsBinaries


