#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'grainechoconcepts.so') $TOP/LinuxBinaries

cd .. 

cd grain_echo && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'grainecho.so') $TOP/LinuxBinaries


