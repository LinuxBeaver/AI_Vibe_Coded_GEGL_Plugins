
#ifndef CONFIG_H
#define CONFIG_H

#define GEGL_MICRO_VERSION 34

#endif // CONFIG_H
