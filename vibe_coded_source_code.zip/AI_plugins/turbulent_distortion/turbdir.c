/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås (pippin) for major GEGL contributions FOR MAKING GEGL
 * 2025 Grok with Beaver's help
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

property_double (center_x, _("Center X"), 0.5)
    description (_("Horizontal center of the turbulent distortion (relative to image width, 0.0 to 1.0)"))
    value_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("direction", "x")

property_double (center_y, _("Center Y"), 0.5)
    description (_("Vertical center of the turbulent distortion (relative to image height, 0.0 to 1.0)"))
    value_range (0.0, 1.0)
    ui_meta ("unit", "relative-coordinate")
    ui_meta ("direction", "y")

property_double (intensity, _("Amount"), 20.0)
    description (_("Strength of the turbulent distortion in pixels"))
    value_range (0.0, 100.0)

property_double (scale, _("Scale"), 85.0)
    description (_("Scale of the turbulence pattern (smaller values create larger waves)"))
    value_range (10.0, 200.0)

property_seed (seed, _("Randomize"), rand)
    description (_("Randomize the turbulence pattern"))

property_double (phase, _("Phase"), 0.0)
    description (_("Phase shift of the turbulence pattern in degrees"))
    value_range (0.0, 360.0)
    ui_meta ("unit", "degree")

#else

#define GEGL_OP_FILTER
#define GEGL_OP_NAME     turbulentdistortion
#define GEGL_OP_C_SOURCE turbdir.c

#include "gegl-op.h"

static void prepare (GeglOperation *operation)
{
  const Babl *format = babl_format ("RGBA float");
  gegl_operation_set_format (operation, "input", format);
  gegl_operation_set_format (operation, "output", format);

  /* Force the input node to compute its output to ensure upstream GEGL Graph filters are applied */
  GeglNode *input_node = gegl_operation_get_source_node (operation, "input");
  if (input_node)
  {
    gegl_node_process (input_node);
  }

  /* Invalidate the output cache to force a fresh computation */
  gegl_operation_invalidate (operation, NULL, TRUE);
}

static GeglRectangle get_bounding_box (GeglOperation *operation)
{
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  if (!in_rect)
    return gegl_rectangle_infinite_plane ();
  return *in_rect;
}

static GeglRectangle get_required_for_output (GeglOperation *operation,
                                              const gchar *input_pad,
                                              const GeglRectangle *roi)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  GeglRectangle result = *roi;

  /* Expand the region of interest to account for the maximum displacement */
  gdouble max_displacement = o->intensity;
  result.x -= max_displacement;
  result.y -= max_displacement;
  result.width += 2 * max_displacement;
  result.height += 2 * max_displacement;

  /* Intersect with the full input buffer, not just the selection, to ensure we can sample outside the selection */
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  if (in_rect)
    gegl_rectangle_intersect (&result, &result, in_rect);

  return result;
}

/* Function to mirror coordinates within image bounds */
static gdouble mirror_coordinate (gdouble coord, gdouble min, gdouble max)
{
  gdouble range = max - min;
  if (range <= 0) return min; /* Avoid division by zero */

  /* Normalize coordinate to range [min, max) */
  gdouble normalized = coord - min;
  gdouble mod = fmod (normalized, 2 * range);

  /* Mirror by reflecting across the boundaries */
  if (mod < 0) mod += 2 * range; /* Handle negative values */
  if (mod < range)
    return min + mod; /* Forward direction */
  else
    return min + (2 * range - mod); /* Reflected direction */
}

/* Simple linear congruential generator (LCG) for pseudo-random values */
static guint32 lcg_next (guint32 *state)
{
  *state = (*state * 1103515245 + 12345) & 0x7fffffff;
  return *state;
}

/* Generate a pseudo-random value in [0, 1] for a given grid point */
static gdouble random_value (gint x, gint y, guint32 seed)
{
  guint32 state = (guint32)(seed + x * 137 + y * 57);
  return (gdouble)lcg_next (&state) / (gdouble)0x7fffffff;
}

/* Linear interpolation */
static gdouble lerp (gdouble a, gdouble b, gdouble t)
{
  return a + t * (b - a);
}

/* Smoothstep interpolation for smoother transitions */
static gdouble smoothstep (gdouble t)
{
  return t * t * (3.0 - 2.0 * t);
}

/* Approximate Perlin-like noise by layering interpolated sine waves */
static gdouble perlin_like_noise (gdouble x, gdouble y, gdouble scale, guint32 seed, gdouble phase_rad)
{
  /* Scale coordinates */
  x = x / scale + phase_rad;
  y = y / scale + phase_rad;

  /* Determine grid cell coordinates */
  gint x0 = (gint)floor (x);
  gint y0 = (gint)floor (y);
  gint x1 = x0 + 1;
  gint y1 = y0 + 1;

  /* Compute fractional positions within the cell */
  gdouble fx = x - x0;
  gdouble fy = y - y0;

  /* Smooth the fractional positions */
  fx = smoothstep (fx);
  fy = smoothstep (fy);

  /* Get random values at the grid corners */
  gdouble n00 = sin (random_value (x0, y0, seed) * 2.0 * G_PI + phase_rad);
  gdouble n01 = sin (random_value (x0, y1, seed) * 2.0 * G_PI + phase_rad);
  gdouble n10 = sin (random_value (x1, y0, seed) * 2.0 * G_PI + phase_rad);
  gdouble n11 = sin (random_value (x1, y1, seed) * 2.0 * G_PI + phase_rad);

  /* Interpolate along x */
  gdouble nx0 = lerp (n00, n10, fx);
  gdouble nx1 = lerp (n01, n11, fx);

  /* Interpolate along y */
  gdouble value = lerp (nx0, nx1, fy);

  return value;
}

/* Compute turbulent displacement by layering Perlin-like noise */
static void compute_turbulent_displacement (gdouble x, gdouble y, gdouble scale, guint32 seed, gdouble phase_rad, gdouble *tx, gdouble *ty)
{
  gdouble value_x = 0.0;
  gdouble value_y = 0.0;
  gdouble current_scale = scale;
  gdouble amplitude = 1.0;

  /* Layer multiple octaves for turbulence */
  for (gint i = 0; i < 4; i++)
  {
    value_x += perlin_like_noise (x, y, current_scale, seed + i, phase_rad) * amplitude;
    value_y += perlin_like_noise (y, x, current_scale, seed + i + 1, phase_rad) * amplitude;
    current_scale *= 0.5; /* Reduce scale for higher frequency */
    amplitude *= 0.5;     /* Reduce amplitude for finer details */
  }

  *tx = value_x * 10.0; /* Scale displacement */
  *ty = value_y * 10.0;
}

static gboolean
process (GeglOperation       *operation,
         GeglBuffer          *input,
         GeglBuffer          *output,
         const GeglRectangle *result,
         gint                 level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  const Babl *format = babl_format ("RGBA float");
  gfloat *output_pixel = g_new (gfloat, 4);
  guint32 seed = (guint32)o->seed;
  gdouble phase_rad = o->phase * G_PI / 180.0;

  /* Get the full input buffer dimensions for sampling */
  GeglRectangle *in_rect = gegl_operation_source_get_bounding_box (operation, "input");
  gdouble center_x = o->center_x * in_rect->width + in_rect->x;
  gdouble center_y = o->center_y * in_rect->height + in_rect->y;
  gdouble min_x = in_rect->x;
  gdouble max_x = in_rect->x + in_rect->width;
  gdouble min_y = in_rect->y;
  gdouble max_y = in_rect->y + in_rect->height;

  /* Clear the output buffer to ensure no stale data */
  gegl_buffer_clear (output, result);

  /* Create iterator for the output buffer */
  GeglBufferIterator *iter = gegl_buffer_iterator_new (output, result, 0, format,
                                                       GEGL_BUFFER_WRITE, GEGL_ABYSS_NONE, 1);

  /* Process each output region */
  while (gegl_buffer_iterator_next (iter))
  {
    gfloat *out_data = (gfloat *)iter->items[0].data;

    for (gint y = iter->items[0].roi.y; y < iter->items[0].roi.y + iter->items[0].roi.height; y++)
    {
      for (gint x = iter->items[0].roi.x; x < iter->items[0].roi.x + iter->items[0].roi.width; x++)
      {
        /* Calculate relative coordinates from the center */
        gdouble dx = x - center_x;
        gdouble dy = y - center_y;

        /* Compute turbulent displacement */
        gdouble tx, ty;
        compute_turbulent_displacement (dx, dy, o->scale, seed, phase_rad, &tx, &ty);

        /* Apply displacement scaled by intensity */
        gdouble src_x = x + tx * o->intensity / 10.0;
        gdouble src_y = y + ty * o->intensity / 10.0;

        /* Mirror coordinates to stay within the full input buffer bounds */
        src_x = mirror_coordinate (src_x, min_x, max_x);
        src_y = mirror_coordinate (src_y, min_y, max_y);

        /* Sample input at the displaced coordinates */
        gegl_buffer_sample (input, src_x, src_y, NULL, output_pixel, format,
                            GEGL_SAMPLER_LINEAR, GEGL_ABYSS_CLAMP);

        /* Write to the output buffer (GEGL applies the selection mask automatically) */
        gint index = ((y - iter->items[0].roi.y) * iter->items[0].roi.width + (x - iter->items[0].roi.x)) * 4;
        out_data[index + 0] = output_pixel[0];
        out_data[index + 1] = output_pixel[1];
        out_data[index + 2] = output_pixel[2];
        out_data[index + 3] = output_pixel[3];
      }
    }
  }

  g_free (output_pixel);
  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationFilterClass *filter_class = GEGL_OPERATION_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  operation_class->get_bounding_box = get_bounding_box;
  operation_class->get_required_for_output = get_required_for_output;
  filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:turbulent-distortion",
    "title",       _("Turbulent Distortion"),
    "reference-hash", "turbulentdistortion2025",
    "description", _("Creates a turbulent distortion effect with a liquid-like pattern"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL/Distortion",
    "gimp:menu-label", _("Turbulent Distortion..."),
    NULL);
}

#endif
