/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright 2006 Øyvind Kolås <pippin@gimp.org>
 * 2025 Beaver modifying mostly Grok's work. Deep Seek helped a little too
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <math.h>
#include <gegl.h>
#include <gegl-plugin.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_noise_type2521)
  enum_value (GEGL_NOISE_TYPE_WOOD,        "wood",        N_("Wood"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_BILLOW,"perlin_billow",N_("Perlin Billow"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_SWIRL,"perlin_swirl",N_("Perlin Swirl"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_WAVES,"perlin_waves",N_("Perlin Waves"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_GRID, "perlin_grid", N_("Perlin Grid"))
  enum_value (GEGL_NOISE_TYPE_WOOD_KNOTS,  "wood_knots",  N_("Wood Knots"))
  enum_value (GEGL_NOISE_TYPE_WOOD_VENEER,"wood_veneer", N_("Wood Veneer"))
  enum_value (GEGL_NOISE_TYPE_WOOD_TWIST,  "wood_twist",  N_("Wood Twist"))
  enum_value (GEGL_NOISE_TYPE_LAVA_FLOW, "lava_flow", N_("Lava Flow"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_VORTEX, "perlin_vortex", N_("Perlin Vortex"))
  enum_value (GEGL_NOISE_TYPE_PERLIN_WHIRLPOOL, "perlin_whirlpool", N_("Perlin Whirlpool"))
  enum_value (GEGL_NOISE_TYPE_VOLCANIC_RIFTS, "volcanic_rifts", N_("Volcanic Rifts"))
  enum_value (GEGL_NOISE_TYPE_TURBULENT_FLOW, "turbulent_flow", N_("Turbulent Flow"))
  enum_value (GEGL_NOISE_TYPE_OCEAN_SWELL, "ocean_swell", N_("Ocean Swell"))
  enum_value (GEGL_NOISE_TYPE_RIPPLE_WAVES, "ripple_waves", N_("Ripple Waves"))
  enum_value (GEGL_NOISE_TYPE_TIDAL_SURGE, "tidal_surge", N_("Tidal Surge"))
  enum_value (GEGL_NOISE_TYPE_WATERY_SHIMMER, "watery_shimmer", N_("Watery Shimmer"))
  enum_value (GEGL_NOISE_TYPE_FLOWING_CURRENTS, "flowing_currents", N_("Flowing Currents"))
enum_end (GeglNoiseType2521)

property_enum (noise_type, _("Noise Type"),
               GeglNoiseType2521, gegl_noise_type2521,
               GEGL_NOISE_TYPE_WOOD)
    description (_("Type of noise pattern to generate"))

property_double (scale, _("Scale"), 180.0)
    description (_("Scale of the noise pattern (higher values create smaller, finer noise)"))
    value_range (85.0, 600.0)
    ui_range (85.0, 600.0)

property_double (roughness, _("Roughness and Distortion"), 3.5)
    description (_("Roughness of the noise (higher values create more distorted patterns)"))
    value_range (0.0, 12.0)
    ui_range (0.0, 8.0)
    ui_meta ("visible", "noise_type {wood,perlin_billow,perlin_swirl,perlin_waves,perlin_grid,wood_knots,wood_veneer,wood_twist,lava_flow,perlin_vortex,perlin_whirlpool,volcanic_rifts,turbulent_flow,ocean_swell,ripple_waves,tidal_surge,watery_shimmer,flowing_currents}")

property_int (octaves, _("Octaves"), 1)
    description (_("Number of octaves for fractal summation (adds finer details)"))
    value_range (1, 3)
    ui_range (1, 3)
    ui_meta ("visible", "noise_type {wood,perlin_billow,perlin_swirl,perlin_waves,perlin_grid,wood_knots,wood_veneer,wood_twist,lava_flow,perlin_vortex,perlin_whirlpool,volcanic_rifts,turbulent_flow,ocean_swell,ripple_waves,tidal_surge,watery_shimmer,flowing_currents}")

property_double (ring_frequency, _("Ring Frequency"), 10.0)
    description (_("Frequency of the wood rings (higher values create more frequent rings)"))
    value_range (5.0, 20.0)
    ui_range (5.0, 20.0)
    ui_meta ("visible", "noise_type {wood,wood_knots,wood_veneer,wood_twist}")

property_seed (seed, _("Seed"), rand)
    description (_("Random seed for the noise pattern"))

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     liquidnoise
#define GEGL_OP_C_SOURCE liquidnoise.c

#include "gegl-op.h"

// Simple hash function for randomization
static gfloat
hash (gfloat x, gfloat y, gint seed)
{
  gint hash = (gint)(x * 73856093 + y * 19349663 + seed * 83492791) & 0x7fffffff;
  return (hash % 10000) / 10000.0;
}

// Value noise implementation (still needed for some remaining patterns)
static gfloat
value_noise (gfloat x, gfloat y, gint seed)
{
  gint xi = (gint) x;
  gint yi = (gint) y;
  gfloat xf = x - xi;
  gfloat yf = y - yi;

  gfloat v00 = hash (xi, yi, seed);
  gfloat v10 = hash (xi + 1, yi, seed);
  gfloat v01 = hash (xi, yi + 1, seed);
  gfloat v11 = hash (xi + 1, yi + 1, seed);

  gfloat u = xf * xf * (3.0 - 2.0 * xf);
  gfloat v = yf * yf * (3.0 - 2.0 * yf);

  gfloat nx0 = v00 + u * (v10 - v00);
  gfloat nx1 = v01 + u * (v11 - v01);

  return nx0 + v * (nx1 - nx0);
}

// Perlin noise implementation (used for Wood and remaining Perlin patterns)
static gfloat
perlin_noise (gfloat x, gfloat y, gint seed)
{
  gint xi = (gint) x;
  gint yi = (gint) y;
  gfloat xf = x - xi;
  gfloat yf = y - yi;

  gfloat g00 = hash (xi, yi, seed) * 2.0 * G_PI;
  gfloat g10 = hash (xi + 1, yi, seed) * 2.0 * G_PI;
  gfloat g01 = hash (xi, yi + 1, seed) * 2.0 * G_PI;
  gfloat g11 = hash (xi + 1, yi + 1, seed) * 2.0 * G_PI;

  gfloat d00 = cos (g00) * xf + sin (g00) * yf;
  gfloat d10 = cos (g10) * (xf - 1.0) + sin (g10) * yf;
  gfloat d01 = cos (g01) * xf + sin (g01) * (yf - 1.0);
  gfloat d11 = cos (g11) * (xf - 1.0) + sin (g11) * (yf - 1.0);

  gfloat u = xf * xf * (3.0 - 2.0 * xf);
  gfloat v = yf * yf * (3.0 - 2.0 * yf);

  gfloat nx0 = d00 + u * (d10 - d00);
  gfloat nx1 = d01 + u * (d11 - d01);
  return nx0 + v * (nx1 - nx0);
}

static void
prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "input", babl_format ("RGBA float"));
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));
}

static gboolean
process (GeglOperation       *operation,
         void               *in_buf,
         void               *out_buf,
         glong               n_pixels,
         const GeglRectangle *roi,
         gint                level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  gfloat *out_pixel = (gfloat *) out_buf;

  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    gfloat nx = x / o->scale;
    gfloat ny = y / o->scale;
    gfloat noise = 0.0;

    switch (o->noise_type)
    {
      case GEGL_NOISE_TYPE_WOOD:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat r = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            r += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          r /= total_amplitude;
          r = sqrt (nx * nx + ny * ny) + r * o->roughness;
          noise = sin (r * o->ring_frequency);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_BILLOW:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            gfloat n = perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            noise += amplitude * fabs (n);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = noise * noise * o->roughness;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_SWIRL:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat angle = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            angle += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          angle /= total_amplitude;
          angle *= o->roughness * G_PI;
          gfloat swirl_x = nx + cos (angle) * 0.5;
          gfloat swirl_y = ny + sin (angle) * 0.5;

          noise = 0.0;
          amplitude = 1.0;
          frequency = 1.0;
          total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (swirl_x * frequency, swirl_y * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_WAVES:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = sin (nx * 5.0 + noise * o->roughness) * cos (ny * 5.0 + noise * o->roughness);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_GRID:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = sin (nx * 10.0 + noise * o->roughness) * sin (ny * 10.0 + noise * o->roughness);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_WOOD_KNOTS:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat knot = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            knot += amplitude * perlin_noise (nx * frequency * 2.0, ny * frequency * 2.0, o->seed + 1 + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          knot /= total_amplitude;
          knot *= o->roughness;
          gfloat r_knots = sqrt (nx * nx + ny * ny) + knot * 0.3;
          noise = sin (r_knots * o->ring_frequency);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_WOOD_VENEER:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise *= o->roughness;
          noise = sin (ny * o->ring_frequency + noise * 5.0);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_WOOD_TWIST:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat twist = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            twist += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + 2 + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          twist /= total_amplitude;
          twist *= o->roughness * G_PI;
          gfloat twist_x = nx + cos (twist) * 0.5;
          gfloat twist_y = ny + sin (twist) * 0.5;
          gfloat r_twist = sqrt (twist_x * twist_x + twist_y * twist_y);
          noise = sin (r_twist * o->ring_frequency);
          noise = (noise + 1.0) * 0.5;
        }
        break;

      case GEGL_NOISE_TYPE_LAVA_FLOW:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 0.5;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          noise = sin (ny + turbulence);
          noise = (noise + 1.0) * 0.5;
          noise = noise * noise;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_VORTEX:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat angle = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            angle += amplitude * perlin_noise (nx * frequency * 2.0, ny * frequency * 2.0, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          angle /= total_amplitude;
          angle *= o->roughness * G_PI * 2.0;
          gfloat vortex_x = nx + cos (angle) * 0.8;
          gfloat vortex_y = ny + sin (angle) * 0.8;

          noise = 0.0;
          amplitude = 1.0;
          frequency = 1.0;
          total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (vortex_x * frequency * 1.5, vortex_y * frequency * 1.5, o->seed + 1 + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_PERLIN_WHIRLPOOL:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          gfloat angle = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            angle += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          angle /= total_amplitude;
          gfloat dist = sqrt (nx * nx + ny * ny);
          angle = angle * o->roughness * G_PI + dist * 2.0;
          gfloat whirl_x = nx + cos (angle) * dist * 0.5;
          gfloat whirl_y = ny + sin (angle) * dist * 0.5;

          noise = 0.0;
          amplitude = 1.0;
          frequency = 1.0;
          total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            noise += amplitude * perlin_noise (whirl_x * frequency, whirl_y * frequency, o->seed + 1 + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_VOLCANIC_RIFTS:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 1.0;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            gfloat n = perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            noise += amplitude * (1.0 - fabs (n)); // Ridged noise for peaks
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = noise * noise; // Sharpen peaks

          gfloat rifts_amplitude = 1.0;
          gfloat rifts_frequency = 1.0;
          gfloat rifts_total_amplitude = 0.0;
          gfloat rifts_noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            rifts_noise += rifts_amplitude * perlin_noise (nx * rifts_frequency, ny * rifts_frequency, o->seed + 1 + j);
            rifts_total_amplitude += rifts_amplitude;
            rifts_amplitude *= o->roughness;
            rifts_frequency *= 2.0;
          }

          rifts_noise /= rifts_total_amplitude;
          gfloat rifts = sin (nx * 5.0 + rifts_noise * o->roughness);
          noise -= (1.0 - rifts) * (o->roughness * 0.3);
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_TURBULENT_FLOW:
        {
          gfloat amplitude = 1.0;
          gfloat frequency = 0.5;
          gfloat total_amplitude = 0.0;
          noise = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            gfloat flow_x = perlin_noise (nx * frequency, ny * frequency, o->seed + j);
            gfloat flow_y = perlin_noise (nx * frequency + 1000.0, ny * frequency + 1000.0, o->seed + j);
            gfloat displaced_x = nx + flow_x * o->roughness * 0.5;
            gfloat displaced_y = ny + flow_y * o->roughness * 0.5;
            noise += amplitude * perlin_noise (displaced_x * frequency, displaced_y * frequency, o->seed + j);
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          noise /= total_amplitude;
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_OCEAN_SWELL:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 0.5;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          noise = sin (nx * 3.0 + ny * 2.0 + turbulence); // Gentle rolling waves
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_RIPPLE_WAVES:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 0.5;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          gfloat dist = sqrt (nx * nx + ny * ny);
          noise = sin (dist * 5.0 + turbulence); // Radial ripples
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_TIDAL_SURGE:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 0.5;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          noise = sin (nx * 4.0 + turbulence); // Directional waves
          noise = (noise + 1.0) * 0.5;
          noise = noise * noise; // Sharpen the peaks
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_WATERY_SHIMMER:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 1.0;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency, ny * frequency, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          noise = sin (nx * 10.0 + ny * 10.0 + turbulence); // High-frequency shimmer
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      case GEGL_NOISE_TYPE_FLOWING_CURRENTS:
        {
          gfloat turbulence = 0.0;
          gfloat frequency = 0.5;
          gfloat amplitude = 1.0;
          gfloat total_amplitude = 0.0;

          for (gint j = 0; j < o->octaves; j++)
          {
            turbulence += amplitude * perlin_noise (nx * frequency * 2.0, ny * frequency * 0.5, o->seed + j) * o->roughness;
            total_amplitude += amplitude;
            amplitude *= o->roughness;
            frequency *= 2.0;
          }

          turbulence /= total_amplitude;
          noise = sin (nx * 5.0 + turbulence); // Stretched waves for flowing effect
          noise = (noise + 1.0) * 0.5;
          noise = CLAMP (noise, 0.0, 1.0);
        }
        break;

      default:
        noise = 0.0;
    }

    // Normalize noise to 0-1 range if needed
    noise = CLAMP (noise, 0.0, 1.0);

    // Apply noise as grayscale, replacing the pixel (even transparent ones)
    out_pixel[0] = noise;
    out_pixel[1] = noise;
    out_pixel[2] = noise;
    out_pixel[3] = 1.0; // Full opacity

    out_pixel += 4;
  }

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS (klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name", "ai/lb:liquid-noise",
    "title", _("Liquid Noise"),
    "reference-hash", "groks_noise",
    "description", _("Generates liquid noise with adjustable parameters"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Liquid Noise..."),
    NULL);
}

#endif
