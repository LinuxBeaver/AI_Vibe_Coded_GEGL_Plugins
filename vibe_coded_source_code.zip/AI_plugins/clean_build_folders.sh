#!/bin/bash

gio trash */build

gio trash */SourceCode


