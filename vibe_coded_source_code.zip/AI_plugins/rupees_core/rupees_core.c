/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/.
 * Credit to Pippin for huge GEGL contributions
 * Created by Grok (xAI) from Beaver's assistance
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_grid_type2525gem)
  enum_value (GEGL_GRID_BASIC, "basic", N_("Basic Grid"))
  enum_value (GEGL_GRID_HEXAGONAL, "hexagonal", N_("Hexagonal Grid"))
  enum_value (GEGL_GRID_OFFSET, "offset", N_("Offset Grid"))
enum_end (GeglGridType2525gem)

property_enum (grid_type, _("Grid Type"),
               GeglGridType2525gem, gegl_grid_type2525gem,
               GEGL_GRID_BASIC)
    description (_("Arrangement of rupee gems on the grid"))

property_double (size, _("Gem Size"), 50.0)
    description (_("Base size of the rupee gems"))
    value_range (20.0, 400.0)
    ui_range (20.0, 400.0)

property_double (gem_width, _("Gem Width"), 1.0)
    description (_("Width scaling factor for rupee gems"))
    value_range (0.5, 2.0)
    ui_range (0.5, 2.0)

property_double (gem_height, _("Gem Height"), 1.0)
    description (_("Height scaling factor for rupee gems"))
    value_range (0.5, 2.0)
    ui_range (0.5, 2.0)

property_double (details, _("Detail"), 0.1)
    description (_("Detail of the gems"))
    value_range (0.0, 0.15)
    ui_range (0.0, 0.1)

property_double (gradient_shift, _("Gradient Shift"), 0.0)
    description (_("Shift the rainbow gradient color cycle (0.0 to 1.0)"))
    value_range (0.0, 1.0)
    ui_range (0.0, 1.0)

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     rupees_core
#define GEGL_OP_C_SOURCE rupees_core.c

#include "gegl-op.h"

// Rainbow color lookup with controlled variation and gradient shift
static void get_rainbow_color(gfloat position, gfloat variation, gfloat shift, GRand *rand, gfloat *color)
{
  gfloat t = fmod(position + g_rand_double_range(rand, -variation / 2.0, variation / 2.0) + shift, 1.0) * 6.0;
  gint segment = (gint)t;
  gfloat fraction = t - segment;

  switch (segment) {
    case 0: color[0] = 1.0; color[1] = fraction; color[2] = 0.0; break; // Red to Yellow
    case 1: color[0] = 1.0 - fraction; color[1] = 1.0; color[2] = 0.0; break; // Yellow to Green
    case 2: color[0] = 0.0; color[1] = 1.0; color[2] = fraction; break; // Green to Cyan
    case 3: color[0] = 0.0; color[1] = 1.0 - fraction; color[2] = 1.0; break; // Cyan to Blue
    case 4: color[0] = fraction; color[1] = 0.0; color[2] = 1.0; break; // Blue to Indigo
    case 5: color[0] = 1.0; color[1] = 0.0; color[2] = 1.0 - fraction; break; // Indigo to Violet
  }
  color[3] = 1.0; // Full opacity
}

// Check if point is inside a rupee-shaped heptagon with scaled dimensions
static gboolean is_inside_rupee(gfloat x, gfloat y, gfloat radius_x, gfloat radius_y)
{
  // Normalize coordinates to unit circle with aspect ratio
  gfloat norm_x = x / radius_x;
  gfloat norm_y = y / radius_y;
  gfloat angle = atan2(norm_y, norm_x);
  if (angle < 0) angle += 2.0 * M_PI; // Normalize to 0-2PI
  gfloat dist = sqrt(norm_x * norm_x + norm_y * norm_y);
  gfloat sides = 7.0; // Heptagon for rupee shape
  gfloat base_angle = 2.0 * M_PI / sides;
  gfloat edge_angle = fmod(angle + base_angle / 2.0, base_angle) - base_angle / 2.0;
  gfloat inner_radius = 0.7; // Bevel for facet effect
  gfloat edge_dist = inner_radius / cos(edge_angle);
  return dist < edge_dist && dist < 1.0; // Within scaled boundary
}

static gboolean process (GeglOperation *operation,
                        void *in_buf,
                        void *out_buf,
                        glong n_pixels,
                        const GeglRectangle *roi,
                        gint level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  gfloat *out = out_buf;

  GeglRectangle *canvas = gegl_operation_source_get_bounding_box (operation, "input");
  gfloat canvas_width = canvas ? canvas->width : roi->width;
  gfloat canvas_height = canvas ? canvas->height : roi->height;
  gfloat grid_step = o->size * 1.8; // Fixed spacing for visible gems

  GRand *rand = g_rand_new_with_seed(time(NULL)); // Time-based seed for variation

  for (glong i = 0; i < n_pixels; i++)
  {
    gint x = (i % roi->width) + roi->x;
    gint y = (i / roi->width) + roi->y;

    out[0] = 0.0; // Transparent background
    out[1] = 0.0;
    out[2] = 0.0;
    out[3] = 0.0;

    // Calculate grid position with guaranteed placement
    gfloat grid_x = fmod(x, grid_step);
    gfloat grid_y = fmod(y, grid_step);
    gfloat radius_x = o->size * o->gem_width / 2.0;
    gfloat radius_y = o->size * o->gem_height / 2.0;

    // Adjust grid offset based on grid_type
    switch (o->grid_type)
    {
      case GEGL_GRID_BASIC:
        break;
      case GEGL_GRID_HEXAGONAL:
        grid_x = fmod(x, grid_step);
        grid_y = fmod(y + (fmod(x, grid_step * 2) > grid_step ? grid_step * 0.5 : 0), grid_step * 1.7);
        break;
      case GEGL_GRID_OFFSET:
        grid_x = fmod(x, grid_step);
        grid_y = fmod(y + (fmod(floor(x / grid_step), 2.0) > 0.0 ? grid_step * 0.5 : 0), grid_step);
        break;
    }

    // Center the gem at the grid position
    gfloat center_x = x - grid_x + radius_x;
    gfloat center_y = y - grid_y + radius_y;

    // Check if pixel is within a rupee gem
    gfloat dx = x - center_x;
    gfloat dy = y - center_y;
    if (is_inside_rupee(dx, dy, radius_x, radius_y))
    {
      gfloat color_pos = (center_x + center_y) / (canvas_width + canvas_height);
      get_rainbow_color(color_pos, o->details, o->gradient_shift, rand, out);
      out[3] = 1.0; // Opaque gem
    }

    out += 4;
  }

  g_rand_free(rand);
  return TRUE;
}

static void gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS (klass);

  point_filter_class->process = process; // Only assign process, no prepare needed

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:rupees-core",
    "title",       _("Rupees Gem Patterns core"),
    "categories",     "hidden",
    "description", _("The core file for rainbow-colored rupee gems arranged in various grid patterns"),
    NULL);
}

#endif
