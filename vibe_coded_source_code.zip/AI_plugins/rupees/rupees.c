/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Credit to Øyvind Kolås for major GEGL contributions 
 * Grok Gems manually modified by Beaver with lots of additional gegl ops
* 
*  GEGL Graph here

ai/lb:rupees-core size=150
bevel blendmode=hardlight elevation=50
bloom strength=24
id=0
overlay srgb=true aux=[ ref=0 edge gray opacity value=0.09  ]
id=1 dst-over aux=[ ref=1 gaussian-blur std-dev-x=30 std-dev-y=30
opacity value=2
]
median-blur radius=0 abyss-policy=none
saturation scale=1.5
dst-over aux=[ color value=black ]
mean-curvature-blur iterations=3

 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES

enum_start (gegl_grid_type_gems90)
  enum_value (GEGL_GRID_BASIC, "basic", N_("Basic Grid"))
  enum_value (GEGL_GRID_HEXAGONAL, "hexagonal", N_("Hexagonal Grid"))
  enum_value (GEGL_GRID_OFFSET, "offset", N_("Offset Grid"))
enum_end (GeglGridTypegems90)

property_enum (grid_type, _("Grid Type"),
               GeglGridTypegems90, gegl_grid_type_gems90,
               GEGL_GRID_HEXAGONAL)
    description (_("Arrangement of rupee gems on the grid"))


property_enum (bevel_metric, _("Gem's internal distance map"),
               GeglDistanceMetric, gegl_distance_metric, GEGL_DISTANCE_METRIC_EUCLIDEAN)
    description (_("Distance Map of the sharp chamfer bevel it has three settings that alter the structure of it"))


property_double (bevel_elevation, _("Gem's bevel elevation"), 27.0)
    description (_("Elevation angle of the Bevel"))
    value_range (0.0, 40.0)
    ui_meta ("unit", "degree")
  ui_steps      (0.01, 0.50)


property_int (bevel_depth, _("Gem's bevel depth"), 32)
    description (_("Emboss depth - Brings out depth of the bevel"))
    value_range (20, 100)
    ui_range (20, 80)

property_double (bevel_azimuth, _("Gem's light angle"), 224.0)
    description (_("Direction of a light source illuminating and shading the bevel"))
    value_range (0, 360)
  ui_steps      (0.01, 0.50)
    ui_meta ("unit", "degree")
    ui_meta ("direction", "ccw")

property_double (glow, _("Glow"), 51.0)
    description (_("Glow strength"))
    value_range (0.0, 70.0)
    ui_range    (0.0, 70.0)


property_double (size, _("Gem's Size"), 88.0)
    description (_("Base size of the rupee gems"))
    value_range (20.0, 400.0)
    ui_range (20.0, 200.0)

property_double (width, _("Gem's Width"), 1.4)
    description (_("Width scaling factor for gems"))
    value_range (0.5, 2.0)
    ui_range (0.5, 2.0)

property_double (height, _("Gem's Height"), 2.0)
    description (_("Height scaling factor for gems"))
    value_range (0.5, 2.0)
    ui_range (0.5, 2.0)

property_double (details, _("Detail"), 0.04)
    description (_("Detail of the gems"))
    value_range (0.0, 0.15)
    ui_range (0.0, 0.1)

property_int (smooth, _("Smooth"), 6)
   description (_("Smooth the final processing of the gems"))
   value_range (1, 10)

property_double (gradient_shift, _("Gradient Shift"), 0.65)
    description (_("Shift the rainbow gradient color cycle to recolor the gems"))
    value_range (0.0, 1.0)
    ui_range (0.0, 1.0)

property_double (color_boost, _("Color Boost"), 1.3)
   description (_("Boost the colors"))
   value_range (1.0, 2.0)
   ui_range    (1.0, 2.0)
   ui_gamma    (3.0)
   ui_meta     ("unit", "pixel-distance")

property_double (blur_opacity, _("Color shadow opacity"), 0.5)
   description (_("A blur from the gem's color that is stretching horizontally"))
   value_range (0.0, 2.0)
   ui_range    (0.0, 2.0)
   ui_meta     ("unit", "pixel-distance")

property_double (blur_x, _("Color shadow X"), 20.0)
   description (_("A blur from the gem's color that is stretching horizontally"))
   value_range (0.0, 300.0)
   ui_range    (0.24, 300.0)
   ui_gamma    (3.0)
   ui_meta     ("unit", "pixel-distance")


property_double (blur_y, _("Color shadow Y"), 24.0)
   description (_("A blur from the gem's color that is stretching vertically"))
   value_range (0.0, 300.0)
   ui_range    (0.24, 300.0)
   ui_gamma    (3.0)
   ui_meta     ("unit", "pixel-distance")

property_color  (background_color, _("Background Color"), "#000000")
   description (_("Background color, clicking on the color widget and sliding A from 100.0 to 0.0 will remove all background color"))
#else

#define GEGL_OP_META
#define GEGL_OP_NAME     rupees
#define GEGL_OP_C_SOURCE rupees.c

#include "gegl-op.h"

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;

  GeglColor *blackfill = gegl_color_new ("#000000");

  GeglNode *input    = gegl_node_get_input_proxy (gegl, "input");
  GeglNode *output   = gegl_node_get_output_proxy (gegl, "output");

  GeglNode *gems = gegl_node_new_child (gegl,
                                  "operation", "ai/lb:rupees-core",
                                  NULL);

  GeglNode *bloom = gegl_node_new_child (gegl,
                                  "operation", "gegl:bloom", "strength", 20.0,
                                  NULL);

  GeglNode *bevel = gegl_node_new_child (gegl,
                                  "operation", "gegl:bevel", "metric", 0, "elevation", 20.0,
                                  NULL);

  GeglNode *smooth = gegl_node_new_child (gegl,
                                  "operation", "gegl:mean-curvature-blur", "iterations", 3, 
                                  NULL);

  GeglNode *overlay = gegl_node_new_child (gegl,
                                  "operation", "gegl:overlay", "srgb", TRUE,
                                  NULL);

  GeglNode *idref1 = gegl_node_new_child (gegl,
                                  "operation", "gegl:nop", 
                                  NULL);

  GeglNode *idref2 = gegl_node_new_child (gegl,
                                  "operation", "gegl:nop", 
                                  NULL);

  GeglNode *edge = gegl_node_new_child (gegl,
                                  "operation", "gegl:edge", "algorithm", 0, "amount", 2.0,
                                  NULL);

  GeglNode *gray = gegl_node_new_child (gegl,
                                  "operation", "gegl:gray", 
                                  NULL);

  GeglNode *opacity1 = gegl_node_new_child (gegl,
                                  "operation", "gegl:opacity", "value", 0.09, 
                                  NULL);

  GeglNode *behind1 = gegl_node_new_child (gegl,
                                  "operation", "gegl:dst-over", 
                                  NULL);

  GeglNode *behind2 = gegl_node_new_child (gegl,
                                  "operation", "gegl:dst-over", 
                                  NULL);

  GeglNode *color = gegl_node_new_child (gegl,
                                  "operation", "gegl:color", "value", blackfill, 
                                  NULL);

  GeglNode *blur = gegl_node_new_child (gegl,
                                  "operation", "gegl:gaussian-blur", 
                                  NULL);

  GeglNode *opacity2 = gegl_node_new_child (gegl,
                                  "operation", "gegl:opacity", "value", 1.5, 
                                  NULL);

  GeglNode *saturationboost = gegl_node_new_child (gegl,
                                  "operation", "gegl:saturation", 
                                  NULL);

  GeglNode *repair = gegl_node_new_child (gegl,
                                  "operation", "gegl:median-blur", "radius", 0, "abyss-policy", 0, 
                                  NULL);

#define grainmergedgefun \
"  id=x  gimp:layer-mode layer-mode=grain-merge blend-space=lab aux=[ ref=x gray edge algorithm=sobel amount=16 threshold value=0.2 invert color-to-alpha color=#ffffff  gaussian-blur std-dev-x=2.5 std-dev-y=2.5   color-overlay value=#ffffff opacity value=0.09 ] "\

    GeglNode *graphtime = gegl_node_new_child (gegl,
                                  "operation", "gegl:graph", "string", grainmergedgefun,
                                  NULL);

  gegl_node_link_many (input, gems, bevel, bloom,  idref1, overlay, idref2, behind1, repair,  saturationboost, graphtime,  behind2,  smooth,  output, NULL);
  gegl_node_link_many (idref1, edge, gray, opacity1,  NULL);
  gegl_node_link_many (idref2, blur, opacity2,  NULL);


  gegl_node_connect (overlay, "aux", opacity1, "output");
  gegl_node_connect (behind1, "aux", opacity2, "output");
  gegl_node_connect (behind2, "aux", color, "output");

 gegl_operation_meta_redirect (operation, "gradient_shift", gems, "gradient_shift"); 
 gegl_operation_meta_redirect (operation, "details", gems, "details"); 
 gegl_operation_meta_redirect (operation, "height", gems, "gem_height"); 
 gegl_operation_meta_redirect (operation, "width", gems, "gem_width");
 gegl_operation_meta_redirect (operation, "size", gems, "size"); 
 gegl_operation_meta_redirect (operation, "grid_type", gems, "grid_type"); 
 gegl_operation_meta_redirect (operation, "bevel_elevation", bevel, "elevation"); 
 gegl_operation_meta_redirect (operation, "bevel_depth", bevel, "depth"); 
 gegl_operation_meta_redirect (operation, "bevel_azimuth", bevel, "azimuth"); 
 gegl_operation_meta_redirect (operation, "bevel_metric", bevel, "metric"); 
 gegl_operation_meta_redirect (operation, "blur_x", blur, "std-dev-x"); 
 gegl_operation_meta_redirect (operation, "blur_y", blur, "std-dev-y"); 
 gegl_operation_meta_redirect (operation, "blur_opacity", opacity2, "value"); 
 gegl_operation_meta_redirect (operation, "glow", bloom, "strength"); 
 gegl_operation_meta_redirect (operation, "smooth", smooth, "iterations"); 
 gegl_operation_meta_redirect (operation, "color_boost", saturationboost, "scale"); 
 gegl_operation_meta_redirect (operation, "background_color", color, "value"); 

}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;

  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;

  gegl_operation_class_set_keys (operation_class,
    "name",        "lb:rupees",
    "title",       _("Rupees"),
    "reference-hash", "drawntogethercomedycentral",
    "description", _("Render a grid of rupee gems"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Rupees..."),
    NULL);
}

#endif
