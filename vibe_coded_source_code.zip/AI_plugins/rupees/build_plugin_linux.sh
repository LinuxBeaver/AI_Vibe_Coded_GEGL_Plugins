#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'rupees.so') $TOP/LinuxBinaries

cd .. 

cd rupees_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'rupeescore.so') $TOP/LinuxBinaries

cd .. 


