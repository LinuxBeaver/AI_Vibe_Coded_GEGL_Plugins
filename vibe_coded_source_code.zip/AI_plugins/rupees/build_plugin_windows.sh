#!/bin/bash

mkdir WindowsBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'rupees.dll') $TOP/WindowsBinaries

cd .. 

cd rupees_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'rupeescore.dll') $TOP/WindowsBinaries

cd .. 


