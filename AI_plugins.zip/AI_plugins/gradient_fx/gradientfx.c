/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 * Pippin (for writing GEGL's node chain area in 2006)
 * Grok (for the gradient)
 * Beaver (for chaining the nodes manually with inner glow and outline)
 * gegl:inner-glow or lb:ssg
 * id=1 multiply aux=[ ref=1 ai/lb:gradient ]  
 */

#include "config.h"
#include <glib/gi18n-lib.h>

#ifdef GEGL_PROPERTIES

enum_start(grok2_mode3914)
  enum_value(OUTLINE_TIME, "outline", N_("Outline Glow"))
  enum_value(OUTLINE_BEVEL_TIME, "outline_bevel", N_("Outline Bevel"))
  enum_value(INNERGLOW_TIME, "inner_glow", N_("Inner Glow"))
enum_end(Grok2Mode3914)

// Forwarded properties from ai/lb:gradient
enum_start(grok2_gradient_type3914)
  enum_value(GROK2_GRADIENT_RAINBOW, "rainbow", N_("Rainbow Gradient"))
  enum_value(GROK2_GRADIENT_TROPICAL, "tropical", N_("Tropical Colors"))
  enum_value(GROK2_GRADIENT_BERRY_BLAST, "berry_blast", N_("Berry Blast"))
  enum_value(GROK2_GRADIENT_CITRUS_ZEST, "citrus_zest", N_("Citrus Zest"))
  enum_value(GROK2_GRADIENT_MANGO_TANGO, "mango_tango", N_("Mango Tango"))
  enum_value(GROK2_GRADIENT_MELON_MEDLEY, "melon_medley", N_("Melon Medley"))
  enum_value(GROK2_GRADIENT_PEACH_DREAM, "peach_dream", N_("Peach Dream"))
  enum_value(GROK2_GRADIENT_PINEAPPLE_PUNCH, "pineapple_punch", N_("Pineapple Punch"))
  enum_value(GROK2_GRADIENT_TROPICAL_BREEZE, "tropical_breeze", N_("Tropical Breeze"))
  enum_value(GROK2_GRADIENT_GOLDEN, "golden", N_("Golden"))
  enum_value(GROK2_GRADIENT_SUNRISE, "sunrise", N_("Sunrise"))
  enum_value(GROK2_GRADIENT_ABSTRACT_1, "abstract_1", N_("Abstract 1"))
  enum_value(GROK2_GRADIENT_ABSTRACT_2, "abstract_2", N_("Abstract 2"))
  enum_value(GROK2_GRADIENT_ABSTRACT_3, "abstract_3", N_("Abstract 3"))
  enum_value(GROK2_GRADIENT_BLUUE_SUNSET, "blue_sunset", N_("Blue Sunset"))
  enum_value(GROK2_GRADIENT_FIRE_GLOW, "fire_glow", N_("Fire Glow"))
  enum_value(GROK2_GRADIENT_OCEAN_WAVE, "ocean_wave", N_("Ocean Wave"))
  enum_value(GROK2_GRADIENT_FOREST_GLADE, "forest_glade", N_("Forest Glade"))
  enum_value(GROK2_GRADIENT_PASTEL_DREAM, "pastel_dream", N_("Pastel Dream"))
  enum_value(GROK2_GRADIENT_NEON_GLOW, "neon_glow", N_("Neon Glow"))
  enum_value(GROK2_GRADIENT_AUTUMN_LEAVES, "autumn_leaves", N_("Autumn Leaves"))
  enum_value(GROK2_GRADIENT_PURPLE_HAZE, "purple_haze", N_("Purple Haze"))
  enum_value(GROK2_GRADIENT_DESERT_SAND, "desert_sand", N_("Desert Sand"))
  enum_value(GROK2_GRADIENT_ICY_FROST, "icy_frost", N_("Icy Frost"))
  enum_value(GROK2_GRADIENT_CANDY_SWIRL, "candy_swirl", N_("Candy Swirl"))
  enum_value(GROK2_GRADIENT_VIOLET_DUSK, "violet_dusk", N_("Violet Dusk"))
  enum_value(GROK2_GRADIENT_GREEN_LIME, "green_lime", N_("Green Lime"))
  enum_value(GROK2_GRADIENT_RED_SUNSET, "red_sunset", N_("Red Sunset"))
  enum_value(GROK2_GRADIENT_BLUE_LAGOON, "blue_lagoon", N_("Blue Lagoon"))
  enum_value(GROK2_GRADIENT_PINK_SUNRISE, "pink_sunrise", N_("Pink Sunrise"))
  enum_value(GROK2_GRADIENT_COOL_BREEZE, "cool_breeze", N_("Cool Breeze"))
  enum_value(GROK2_GRADIENT_WARM_GLOW, "warm_glow", N_("Warm Glow"))
  enum_value(GROK2_GRADIENT_LAVENDER_MIST, "lavender_mist", N_("Lavender Mist"))
  enum_value(GROK2_GRADIENT_SKY_BLUE, "sky_blue", N_("Sky Blue"))
  enum_value(GROK2_GRADIENT_RAINBOW_CYCLE, "rainbow_cycle", N_("Rainbow Cycle"))
  enum_value(GROK2_GRADIENT_SUNSET_GLOW, "sunset_glow", N_("Sunset Glow"))
  enum_value(GROK2_GRADIENT_MINT_FRESH, "mint_fresh", N_("Mint Fresh"))
  enum_value(GROK2_GRADIENT_CORAL_REEF, "coral_reef", N_("Coral Reef"))
  enum_value(GROK2_GRADIENT_ELECTRIC_PULSE, "electric_pulse", N_("Electric Pulse"))
  enum_value(GROK2_GRADIENT_GOLD_SHIMMER, "gold_shimmer", N_("Gold Shimmer"))
  enum_value(GROK2_GRADIENT_GOLD_RADIANCE, "gold_radiance", N_("Gold Radiance"))
  enum_value(GROK2_GRADIENT_SILVER_GLEAM, "silver_gleam", N_("Silver Gleam"))
  enum_value(GROK2_GRADIENT_SILVER_LUSTER, "silver_luster", N_("Silver Luster"))
  enum_value(GROK2_GRADIENT_BRONZE_GLOW, "bronze_glow", N_("Bronze Glow"))
  enum_value(GROK2_GRADIENT_BRONZE_SHEEN, "bronze_sheen", N_("Bronze Sheen"))
  enum_value(GROK2_GRADIENT_TWILIGHT_PURPLE, "twilight_purple", N_("Twilight Purple"))
  enum_value(GROK2_GRADIENT_SUNLIT_MEADOW, "sunlit_meadow", N_("Sunlit Meadow"))
  enum_value(GROK2_GRADIENT_OCEAN_DEPTHS, "ocean_depths", N_("Ocean Depths"))
  enum_value(GROK2_GRADIENT_CHERRY_BLOSSOM, "cherry_blossom", N_("Cherry Blossom"))
  enum_value(GROK2_GRADIENT_EMERALD_DREAM, "emerald_dream", N_("Emerald Dream"))
  enum_value(GROK2_GRADIENT_SAPPHIRE_NIGHT, "sapphire_night", N_("Sapphire Night"))
  enum_value(GROK2_GRADIENT_RUBY_GLOW, "ruby_glow", N_("Ruby Glow"))
  enum_value(GROK2_GRADIENT_AMETHYST_HAZE, "amethyst_haze", N_("Amethyst Haze"))
  enum_value(GROK2_GRADIENT_TOPAZ_SUNSET, "topaz_sunset", N_("Topaz Sunset"))
  enum_value(GROK2_GRADIENT_AQUAMARINE_WAVE, "aquamarine_wave", N_("Aquamarine Wave"))
  enum_value(GROK2_GRADIENT_COTTON_CANDY, "cotton_candy", N_("Cotton Candy"))
  enum_value(GROK2_GRADIENT_SWEET_CANDIES, "sweet_candies", N_("Sweet Candies"))
  enum_value(GROK2_GRADIENT_STARRY_SKY, "starry_sky", N_("Starry Sky"))
  enum_value(GROK2_GRADIENT_MOONLIT_FOG, "moonlit_fog", N_("Moonlit Fog"))
  enum_value(GROK2_GRADIENT_SUNFLOWER_FIELD, "sunflower_field", N_("Sunflower Field"))
  enum_value(GROK2_GRADIENT_LILAC_DUSK, "lilac_dusk", N_("Lilac Dusk"))
  enum_value(GROK2_GRADIENT_TURQUOISE_TIDE, "turquoise_tide", N_("Turquoise Tide"))
  enum_value(GROK2_GRADIENT_CRIMSON_SKY, "crimson_sky", N_("Crimson Sky"))
  enum_value(GROK2_GRADIENT_PERIWINKLE_BREEZE, "periwinkle_breeze", N_("Periwinkle Breeze"))
  enum_value(GROK2_GRADIENT_GALACTIC_HORIZON, "galactic_horizon", N_("Galactic Horizon"))
  enum_value(GROK2_GRADIENT_PEPPERMINT_TWIST, "peppermint_twist", N_("Peppermint Twist"))
  enum_value(GROK2_GRADIENT_ROSE_QUARTZ, "rose_quartz", N_("Rose Quartz"))
  enum_value(GROK2_GRADIENT_MIDNIGHT_BLUE, "midnight_blue", N_("Midnight Blue"))
  enum_value(GROK2_GRADIENT_SAFFRON_SUNRISE, "saffron_sunrise", N_("Saffron Sunrise"))
  enum_value(GROK2_GRADIENT_JADE_MIST, "jade_mist", N_("Jade Mist"))
enum_end(Grok2GradientType3914)

enum_start(grok2_gradient_shape2235)
  enum_value(GROK2_SHAPE_LINEAR, "linear", N_("Linear"))
  enum_value(GROK2_SHAPE_BILINEAR, "bilinear", N_("Bilinear"))
  enum_value(GROK2_SHAPE_RADIAL, "radial", N_("Radial"))
  enum_value(GROK2_SHAPE_SPIRAL, "spiral", N_("Spiral"))
  enum_value(GROK2_SHAPE_SPIRAL_CCW, "spiral_ccw", N_("Spiral Counter-Clockwise"))
  enum_value(GROK2_SHAPE_SQUARE, "square", N_("Square"))
enum_end(Grok2GradientShape2235)

property_enum(mode, _("Effect Mode"), Grok2Mode3914, grok2_mode3914, INNERGLOW_TIME)
    description(_("Select the effect to apply: Outline, Bevel, or Inner Glow"))

property_double(radius, _("Radius"), 7.0)
    description(_("Blur radius for the effect"))
    value_range(0.0, 100.0)
    ui_range(0.0, 20.0)



property_int(grow_radius, _("Grow Radius"), 1)
    description(_("Amount to grow the outline or bevel"))
    value_range(0, 20)
    ui_range(0, 10)
    ui_meta("visible", "mode{outline,bevel}")


property_double(opacity, _("Opacity"), 1.5)
    description(_("Opacity of the effect"))
    value_range(0.0, 2.0)
    ui_range(0.0, 2.0)


property_double(x, _("X of effect"), 0.0)
    description(_("Horizontal movement of the effect"))
    value_range(-50.0, 50.0)


property_double(y, _("Y of effect"), 0.0)
    description(_("Vertical movement of the effect"))
    value_range(-50.0, 50.0)
    ui_range(-50, 50.0)
    ui_meta("unit", "percent")

// Gradient properties from ai/lb:gradient
property_enum(gradient_type, _("Gradient Type"), Grok2GradientType3914, grok2_gradient_type3914, GROK2_GRADIENT_RAINBOW)
    description(_("Type of gradient to apply"))

property_enum(gradient_shape, _("Gradient Shape"), Grok2GradientShape2235, grok2_gradient_shape2235, GROK2_SHAPE_LINEAR)
    description(_("Shape of the gradient pattern"))

property_double(angle, _("Gradient Angle"), 0.0)
    description(_("Angle of the gradient in degrees"))
    value_range(0.0, 360.0)
    ui_meta("unit", "degree")
    ui_meta("direction", "ccw")
    ui_meta("visible", "!gradient_shape{radial,square}")

property_double(frequency, _("Frequency"), 1.0)
    description(_("Number of gradient cycles across the image"))
    value_range(0.1, 10.0)
    ui_range(0.1, 5.0)
    ui_meta("visible", "!gradient_shape{spiral,spiral_ccw}")

property_int(frequency_2, _("Spiral Frequency"), 1)
    description(_("Number of spiral gradient cycles across the image"))
    value_range(1, 10)
    ui_range(1, 10)
    ui_meta("visible", "gradient_shape{spiral,spiral_ccw}")

property_double(saturation, _("Saturation"), 1.0)
    description(_("Color intensity (0.0 = grayscale, 1.0 = full color)"))
    value_range(0.0, 1.0)
    ui_range(0.5, 1.0)

property_double(brightness, _("Brightness"), 1.0)
    description(_("Color brightness (0.0 = dark, 1.0 = bright)"))
    value_range(0.0, 1.0)
    ui_range(0.5, 1.0)

property_double(offset_x, _("X Offset"), 0.0)
    description(_("Horizontal offset of the gradient center (as a percentage of image width)"))
    value_range(-100.0, 100.0)
    ui_range(-100.0, 100.0)
    ui_meta("unit", "percent")

property_double(offset_y, _("Y Offset"), 0.0)
    description(_("Vertical offset of the gradient center (as a percentage of image height)"))
    value_range(-100.0, 100.0)
    ui_range(-100.0, 100.0)
    ui_meta("unit", "percent")



#else

#define GEGL_OP_META
#define GEGL_OP_NAME     mygradientoutline
#define GEGL_OP_C_SOURCE gradientfx.c



#include "gegl-op.h"

typedef struct
{
 GeglNode *input;
 GeglNode *multiply;
 GeglNode *outline;
 GeglNode *outlinebevel;
 GeglNode *innerglow;
 GeglNode *gradient;
 GeglNode *idref;
 GeglNode *output;
}State;

static void attach (GeglOperation *operation)
{
  GeglNode *gegl = operation->node;


  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data = g_malloc0 (sizeof (State));



  GeglColor *white1 = gegl_color_new ("#ffffff");
  GeglColor *white2 = gegl_color_new ("#ffffff");
  GeglColor *white3 = gegl_color_new ("#ffffff");

state->input    = gegl_node_get_input_proxy (gegl, "input");

state->multiply = gegl_node_new_child (gegl, "operation", "gegl:nop", NULL);
state->multiply = gegl_node_new_child (gegl, "operation", "gegl:multiply", NULL);
state->gradient = gegl_node_new_child (gegl, "operation", "ai/lb:gradient", NULL);
state->innerglow = gegl_node_new_child (gegl, "operation", "gegl:inner-glow", "value", white1, NULL);
state->outlinebevel = gegl_node_new_child (gegl, "operation", "lb:outlinebevel", "mode", 1, "color", white2, NULL);
state->outline = gegl_node_new_child (gegl, "operation", "lb:outlinebevel", "mode", 0, "color", white3, NULL);

state->output   = gegl_node_get_output_proxy (gegl, "output");


 gegl_operation_meta_redirect (operation, "radius", state->outline,  "blurstroke");
 gegl_operation_meta_redirect (operation, "radius", state->outlinebevel,  "blurstroke");
 gegl_operation_meta_redirect (operation, "radius", state->innerglow,  "radius");
 gegl_operation_meta_redirect (operation, "grow_radius", state->outline,  "stroke");
 gegl_operation_meta_redirect (operation, "grow_radius", state->outlinebevel,  "stroke");
 gegl_operation_meta_redirect (operation, "grow_radius", state->innerglow,  "grow_radius");
 gegl_operation_meta_redirect (operation, "opacity", state->outline,  "opacity");
 gegl_operation_meta_redirect (operation, "opacity", state->outlinebevel,  "opacity");
 gegl_operation_meta_redirect (operation, "opacity", state->innerglow,  "opacity");
 gegl_operation_meta_redirect (operation, "x", state->outline,  "x");
 gegl_operation_meta_redirect (operation, "x", state->outlinebevel,  "x");
 gegl_operation_meta_redirect (operation, "x", state->innerglow,  "x");
 gegl_operation_meta_redirect (operation, "y", state->outline,  "y");
 gegl_operation_meta_redirect (operation, "y", state->outlinebevel,  "y");
 gegl_operation_meta_redirect (operation, "y", state->innerglow,  "y");

 gegl_operation_meta_redirect (operation, "gradient_type", state->gradient,  "gradient_type");
 gegl_operation_meta_redirect (operation, "gradient_shape", state->gradient,  "gradient_shape");
 gegl_operation_meta_redirect (operation, "angle", state->gradient,  "angle");
 gegl_operation_meta_redirect (operation, "frequency", state->gradient,  "frequency");
 gegl_operation_meta_redirect (operation, "frequency_2", state->gradient,  "frequency_2");
 gegl_operation_meta_redirect (operation, "saturation", state->gradient,  "saturation");
 gegl_operation_meta_redirect (operation, "brightness", state->gradient,  "brightness");
 gegl_operation_meta_redirect (operation, "offset_x", state->gradient,  "offset_x");
 gegl_operation_meta_redirect (operation, "offset_y", state->gradient,  "offset_y");


}
static void
update_graph (GeglOperation *operation)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  State *state = o->user_data;
  if (!state) return;

  GeglNode *outlinetype = state->outline; 
  switch (o->mode) {
    case OUTLINE_TIME: outlinetype = state->outline; break;
    case OUTLINE_BEVEL_TIME: outlinetype = state->outlinebevel; break;
    case INNERGLOW_TIME: outlinetype = state->innerglow; break;
}



  gegl_node_link_many (state->input, outlinetype,  state->multiply,  state->output,  NULL);
  gegl_node_link_many (state->input, state->gradient,  NULL);
  gegl_node_connect (state->multiply, "aux", state->gradient, "output"); 
}



static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class;
GeglOperationMetaClass *operation_meta_class = GEGL_OPERATION_META_CLASS (klass);
  operation_class = GEGL_OPERATION_CLASS (klass);

  operation_class->attach = attach;
  operation_meta_class->update = update_graph;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:gradient-fx",
    "title",       _("Gradient Overlayed fx"),
    "reference-hash", "bemybadboybemyman",
    "description", _("Gradient overlayed Inner Glow, Outline, and Glow. All in one plugin"),
/*<Image>/Colors <Image>/Filters are top level menus in GIMP*/
    "gimp:menu-path", "<Image>/Filters/AI GEGL/",
    "gimp:menu-label", _("Gradient fx..."),
    NULL);
}

#endif
