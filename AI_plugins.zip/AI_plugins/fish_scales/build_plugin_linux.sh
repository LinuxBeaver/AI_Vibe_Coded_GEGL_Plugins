#!/bin/bash

mkdir LinuxBinaries

TOP=$(pwd)  

chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'fishscales.so') $TOP/LinuxBinaries

cd .. 

cd fish_scales_core && chmod +x build_linux.sh

./build_linux.sh

cp $(find . -name 'fishscalescore.so') $TOP/LinuxBinaries

cd .. 

