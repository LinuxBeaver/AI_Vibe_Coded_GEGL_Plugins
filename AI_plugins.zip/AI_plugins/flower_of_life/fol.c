/*
 * Pippin (2006) for making GEGL
 * Beaver for vibe coding
 * Grok 3 for making the GEGL plugin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

enum_start(fill_mode_type2222)
  enum_value(OUTLINES, "outlines", "Outlines")
  enum_value(FILLED, "filled", "Filled Circles")
enum_end(fill_mode_type2222)

enum_start(variation_type2222)
  enum_value(CLASSIC, "classic", "Classic")
  enum_value(SPARSE_GRID, "sparse_grid", "Sparse Grid")
  enum_value(ROTATED_CENTERS, "rotated_centers", "Rotated Centers")
  enum_value(SCALED_CIRCLES, "scaled_circles", "Scaled Circles")
  enum_value(VESICA_HIGHLIGHT, "vesica_highlight", "Vesica Highlight")
  enum_value(INNER_CIRCLES, "inner_circles", "Inner Circles")
  enum_value(OUTER_RINGS, "outer_rings", "Outer Rings")
  enum_value(SKEWED_GRID, "skewed_grid", "Skewed Grid")
  enum_value(WAVY_CIRCLES, "wavy_circles", "Wavy Circles")
  enum_value(RANDOM_OFFSET, "random_offset", "Random Offset")
enum_end(variation_type2222)

property_enum(fill_mode, _("Fill Mode"),
              fill_mode_type2222, fill_mode_type2222,
              OUTLINES)
    description(_("Select the rendering style for the Flower of Life"))

property_enum(variation, _("Variation"),
              variation_type2222, variation_type2222,
              CLASSIC)
    description(_("Select a variation of the Flower of Life pattern"))

property_double(tile_size, _("Tile Size"), 500.0)
    description(_("Size of the repeating tile in pixels"))
    value_range(50.0, 2000.0)
    ui_range(50.0, 2000.0)

property_double(circle_radius, _("Circle Radius"), 0.5)
    description(_("Radius of each circle relative to grid spacing (0.1 to 2.0)"))
    value_range(0.1, 2.0)
    ui_range(0.1, 2.0)

property_double(outline_width, _("Outline Width"), 0.05)
    description(_("Thickness of circle outlines in 'Outlines' mode (0.01 to 0.5)"))
    value_range(0.00, 1.0)
    ui_range(0.00, 0.4)
    ui_meta ("visible", "fill_mode {outlines}")

property_double(rotation, _("Rotation"), 0.0)
    description(_("Rotate the pattern (degrees)"))
    value_range(0.0, 360.0)
    ui_range(0.0, 360.0)

property_double(offset_x, _("X Offset"), 0.0)
    description(_("Horizontal shift of the pattern (0.0 to 1.0)"))
    value_range(0.0, 1.0)
    ui_range(0.0, 1.0)

property_double(offset_y, _("Y Offset"), 0.0)
    description(_("Vertical shift of the pattern (0.0 to 1.0)"))
    value_range(0.0, 1.0)
    ui_range(0.0, 1.0)

property_color(foreground_color, _("Foreground Color"), "#5BA9EA")
    description(_("Color of the circles or outlines"))

property_color(background_color, _("Background Color"), "#70D0FF")
    description(_("Color of the background"))

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     fol
#define GEGL_OP_C_SOURCE fol.c

#include "gegl-op.h"

// Simple pseudo-random number generator for Random Offset variation
static gdouble random_value(gint seed)
{
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return (gdouble)(seed % 1000) / 1000.0;
}

static void prepare (GeglOperation *operation)
{
  gegl_operation_set_format (operation, "output", babl_format ("RGBA float"));
}

static GeglRectangle get_bounding_box (GeglOperation *operation)
{
  return gegl_rectangle_infinite_plane ();
}

static gboolean
process (GeglOperation        *operation,
         GeglOperationContext *context,
         const gchar          *output_prop,
         const GeglRectangle  *result,
         gint                 level)
{
  GeglProperties *o = GEGL_PROPERTIES (operation);
  GeglBuffer *output = gegl_operation_context_get_target (context, output_prop);
  gdouble fg_color[4], bg_color[4];
  gdouble tile_size = o->tile_size;
  GeglRectangle rect = *result;
  gint x, y;

  // Get color values
  gegl_color_get_rgba (o->foreground_color, &fg_color[0], &fg_color[1], &fg_color[2], &fg_color[3]);
  gegl_color_get_rgba (o->background_color, &bg_color[0], &bg_color[1], &bg_color[2], &bg_color[3]);

  // Convert rotation to radians
  gdouble rotation_rad = o->rotation * G_PI / 180.0;
  gdouble cos_rot = cos(rotation_rad);
  gdouble sin_rot = sin(rotation_rad);

  // Base hexagonal grid spacing
  gdouble grid_spacing = tile_size / 6.0; // Default: ~6 circles across tile

  // Adjust grid spacing based on variation
  switch (o->variation)
  {
    case SPARSE_GRID:
      grid_spacing *= 1.5; // Larger spacing, fewer circles
      break;
    default:
      break;
  }

  gdouble radius = grid_spacing * o->circle_radius; // Circle radius
  gdouble outline = o->fill_mode == OUTLINES ? o->outline_width * grid_spacing : 0.0; // Outline thickness

  // Adjust tile_size to be a multiple of grid_spacing for perfect tiling
  gdouble tile_width = tile_size;
  gdouble tile_height = tile_size * sqrt(3.0) / 2.0; // Hexagonal grid height
  gdouble num_cells_x = ceil(tile_width / grid_spacing);
  gdouble num_cells_y = ceil(tile_height / (grid_spacing * sqrt(3.0)));
  tile_width = num_cells_x * grid_spacing;
  tile_height = num_cells_y * grid_spacing * sqrt(3.0);

  for (y = rect.y; y < rect.y + rect.height; y++)
  {
    for (x = rect.x; x < rect.x + rect.width; x++)
    {
      gdouble px = (gdouble)x;
      gdouble py = (gdouble)y;

      // Apply global rotation to the original pixel coordinates around (0, 0)
      gdouble px_rot = px * cos_rot - py * sin_rot;
      gdouble py_rot = px * sin_rot + py * cos_rot;

      // Apply x and y offsets
      gdouble offset_x = o->offset_x * tile_width;
      gdouble offset_y = o->offset_y * tile_height;

      // Map rotated and offset coordinates to tile space
      gdouble tx = fmod(px_rot + offset_x + tile_width, tile_width);
      gdouble ty = fmod(py_rot + offset_y + tile_height, tile_height);
      if (tx < 0) tx += tile_width;
      if (ty < 0) ty += tile_height;

      gfloat out[4] = {bg_color[0], bg_color[1], bg_color[2], 1.0};
      gboolean in_shape = FALSE;

      // Hexagonal grid coordinates
      gdouble s = grid_spacing;
      gdouble s_sqrt3 = s * sqrt(3.0);
      gdouble min_dist = tile_width;
      gdouble second_min_dist = tile_width; // For Vesica Highlight

      // Check nearby grid points
      gdouble max_radius = radius + outline;
      switch (o->variation)
      {
        case INNER_CIRCLES:
        case OUTER_RINGS:
          max_radius *= 1.5; // Account for larger outer rings
          break;
        default:
          break;
      }
      gint range = ceil(max_radius / s) + 1;

      for (gint i = -range; i <= range; i++)
      {
        for (gint j = -range; j <= range; j++)
        {
          // Base grid points
          gdouble cx = i * s;
          gdouble cy = j * s_sqrt3;
          gdouble cx_offset = (i + 0.5) * s;
          gdouble cy_offset = (j + 0.5) * s_sqrt3;

          // Apply variations to grid points
          switch (o->variation)
          {
            case SKEWED_GRID:
            {
              gdouble skew = 0.3 * s * sin((i + j) * 0.5);
              cx += skew;
              cx_offset += skew;
              break;
            }
            case ROTATED_CENTERS:
            {
              gdouble angle = (i + j) * 0.3;
              gdouble dx = 0.2 * s * cos(angle);
              gdouble dy = 0.2 * s * sin(angle);
              cx += dx; cy += dy;
              cx_offset += dx; cy_offset += dy;
              break;
            }
            case RANDOM_OFFSET:
            {
              gint seed = i * 1000 + j;
              gdouble dx = (random_value(seed) - 0.5) * 0.2 * s;
              gdouble dy = (random_value(seed + 1) - 0.5) * 0.2 * s;
              cx += dx; cy += dy;
              cx_offset += dx; cy_offset += dy;
              break;
            }
            default:
              break;
          }

          // Wrap grid points within tile
          cx = fmod(cx + tile_width, tile_width);
          cy = fmod(cy + tile_height, tile_height);
          cx_offset = fmod(cx_offset + tile_width, tile_width);
          cy_offset = fmod(cy_offset + tile_height, tile_height);
          if (cx < 0) cx += tile_width;
          if (cy < 0) cy += tile_height;
          if (cx_offset < 0) cx_offset += tile_width;
          if (cy_offset < 0) cy_offset += tile_height;

          // Distance to first grid point
          gdouble dx1 = tx - cx;
          gdouble dy1 = ty - cy;
          dx1 -= tile_width * round(dx1 / tile_width);
          dy1 -= tile_height * round(dy1 / tile_height);
          gdouble dist1 = sqrt(dx1 * dx1 + dy1 * dy1);

          // Distance to second grid point
          gdouble dx2 = tx - cx_offset;
          gdouble dy2 = ty - cy_offset;
          dx2 -= tile_width * round(dx2 / tile_width);
          dy2 -= tile_height * round(dy2 / tile_height);
          gdouble dist2 = sqrt(dx2 * dx2 + dy2 * dy2);

          // Update minimum and second-minimum distances
          if (dist1 < min_dist)
          {
            second_min_dist = min_dist;
            min_dist = dist1;
          }
          else if (dist1 < second_min_dist)
          {
            second_min_dist = dist1;
          }

          if (dist2 < min_dist)
          {
            second_min_dist = min_dist;
            min_dist = dist2;
          }
          else if (dist2 < second_min_dist)
          {
            second_min_dist = dist2;
          }

          // Apply variations
          gdouble local_radius = radius;

          switch (o->variation)
          {
            case SCALED_CIRCLES:
            {
              if ((i + j) % 2 == 0)
                local_radius *= 0.7;
              break;
            }
            case WAVY_CIRCLES:
            {
              local_radius *= (1.0 + 0.3 * sin((i + j) * 0.5));
              break;
            }
            default:
              break;
          }

          // Base rendering logic
          switch (o->variation)
          {
            case VESICA_HIGHLIGHT:
            {
              if (min_dist <= local_radius && second_min_dist <= local_radius)
              {
                in_shape = TRUE;
              }
              break;
            }
            case INNER_CIRCLES:
            {
              if (min_dist <= local_radius * 0.5) // Inner circle
              {
                in_shape = TRUE;
              }
              else if (o->fill_mode == OUTLINES && fabs(min_dist - local_radius * 0.5) < outline)
              {
                in_shape = TRUE;
              }
              else if (min_dist <= local_radius) // Outer circle
              {
                if (o->fill_mode == OUTLINES)
                {
                  if (fabs(min_dist - local_radius) < outline)
                  {
                    in_shape = TRUE;
                  }
                }
                else
                {
                  in_shape = TRUE;
                }
              }
              break;
            }
            case OUTER_RINGS:
            {
              if (min_dist <= local_radius * 1.5) // Outer ring
              {
                if (o->fill_mode == OUTLINES)
                {
                  if (fabs(min_dist - local_radius * 1.5) < outline)
                  {
                    in_shape = TRUE;
                  }
                }
                else
                {
                  in_shape = TRUE;
                }
              }
              else if (min_dist <= local_radius) // Main circle
              {
                if (o->fill_mode == OUTLINES)
                {
                  if (fabs(min_dist - local_radius) < outline)
                  {
                    in_shape = TRUE;
                  }
                }
                else
                {
                  in_shape = TRUE;
                }
              }
              break;
            }
            default:
            {
              if (o->fill_mode == OUTLINES)
              {
                if (fabs(min_dist - local_radius) < outline)
                {
                  in_shape = TRUE;
                }
              }
              else if (min_dist <= local_radius)
              {
                in_shape = TRUE;
              }
              break;
            }
          }
        }
      }

      if (in_shape)
      {
        out[0] = fg_color[0];
        out[1] = fg_color[1];
        out[2] = fg_color[2];
        out[3] = 1.0;
      }

      gegl_buffer_set (output, GEGL_RECTANGLE (x, y, 1, 1), 0, babl_format ("RGBA float"), out, GEGL_AUTO_ROWSTRIDE);
    }
  }

  return TRUE;
}

static void
gegl_op_class_init (GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS (klass);
  operation_class->prepare = prepare;
  operation_class->get_bounding_box = get_bounding_box;
  operation_class->process = process;

  gegl_operation_class_set_keys (operation_class,
    "name",        "ai/lb:flower-of-life",
    "title",       _("Flower of Life"),
    "reference-hash", "floweroflifegegl2025",
    "description", _("Renders a seamless Flower of Life pattern with adjustable variations, tile size, circle radius, outline width, rotation, offsets, and colors"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL/",
    "gimp:menu-label", _("Flower of Life..."),
    NULL);
}

#endif
