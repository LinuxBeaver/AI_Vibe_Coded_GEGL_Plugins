/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright 2006 Øyvind Kolås <pippin@gimp.org>
 * 2025 Beaver modifying mostly Grok's work. Deep Seek helped a little oto
* 
*
*/
#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

enum_start(gegl_pattern_seed5283)
  enum_value(GEGL_GROK2_PATTERN_DIAMOND, "diamond", N_("Original Diamond"))
  enum_value(GEGL_GROK2_PATTERN_HALFWAY_TRIANGLES, "halfway_triangles", N_("Halfway Triangles"))
  enum_value(GEGL_GROK2_PATTERN_NESTED, "nested", N_("Nested Triangles"))
  enum_value(GEGL_GROK2_PATTERN_CHECKERBOARD, "checkerboard", N_("Checkerboard Triangles"))
  enum_value(GEGL_GROK2_PATTERN_SCALED_DIAMONDS, "scaled_diamonds", N_("Scaled Diamonds"))
  enum_value(GEGL_GROK2_PATTERN_UPSIDE_DOWN_NESTED, "upside_down_nested", N_("Upside-Down Nested Triangles"))
enum_end(GeglPatternSeed5283)

property_enum(pattern, _("Pattern"),
              GeglPatternSeed5283, gegl_pattern_seed5283,
              GEGL_GROK2_PATTERN_DIAMOND)
    description(_("Select the triangle or diamond pattern to render"))

property_double(size, _("Triangle Size"), 50.0)
    description(_("Size of each triangle in pixels"))
    value_range(10.0, 200.0)
    ui_range(10.0, 100.0)

property_color(fg_color, _("Triangle Color"), "#ffffff")
    description(_("Color of the triangles (default is white)"))

property_color(bg_color, _("Background Color"), "#a8d5ff")
    description(_("Color of the background (default is light blue)"))

property_boolean(apply_noise_reduction, _("Apply Noise Reduction"), FALSE)
    description(_("Enable noise reduction to smooth triangle edges"))

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     triangle_diamond
#define GEGL_OP_C_SOURCE triangle_diamond.c

#include "gegl-op.h"

static void
prepare(GeglOperation *operation)
{
  const Babl *space = gegl_operation_get_source_space(operation, "input");
  gegl_operation_set_format(operation, "input", babl_format_with_space("RGBA float", space));
  gegl_operation_set_format(operation, "output", babl_format_with_space("RGBA float", space));
}

static gboolean
point_inside_triangle(gfloat x, gfloat y, gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat x3, gfloat y3)
{
  gfloat denom = ((y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3));
  if (fabs(denom) < 1e-6) return FALSE;
  gfloat a = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / denom;
  gfloat b = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / denom;
  gfloat c = 1.0f - a - b;
  return a >= 0 && b >= 0 && c >= 0;
}

static GeglBuffer *
apply_noise_reduction(GeglBuffer *input_buffer, const GeglRectangle *result)
{
  GeglNode *gegl, *source, *noise_reduction, *sink;
  GeglBuffer *output_buffer;

  gegl = gegl_node_new();

  source = gegl_node_new_child(gegl,
                               "operation", "gegl:buffer-source",
                               "buffer", input_buffer,
                               NULL);

  noise_reduction = gegl_node_new_child(gegl,
                                        "operation", "gegl:noise-reduction",
                                        "iterations", 2,  // Reduced from 15 to 2
                                        NULL);

  sink = gegl_node_new_child(gegl,
                             "operation", "gegl:buffer-sink",
                             "buffer", &output_buffer,
                             NULL);

  gegl_node_link_many(source, noise_reduction, sink, NULL);

  gegl_node_process(sink);

  g_object_unref(gegl);

  return output_buffer;
}

static gboolean
process(GeglOperation *operation, void *in_buf, void *out_buf, glong n_pixels, const GeglRectangle *roi, gint level)
{
  GeglProperties *o = GEGL_PROPERTIES(operation);
  gfloat fg_rgb[3], bg_rgb[3];

  gegl_color_get_pixel(o->fg_color, babl_format("RGB float"), fg_rgb);
  gegl_color_get_pixel(o->bg_color, babl_format("RGB float"), bg_rgb);

  gfloat size = o->size;
  gfloat half_size = size / 2.0f;
  gfloat height = size * sin(G_PI / 3.0f);

  const Babl *format = babl_format("RGBA float");
  GeglRectangle padded_roi = *roi;
  padded_roi.x -= 16;
  padded_roi.y -= 16;
  padded_roi.width += 32;
  padded_roi.height += 32;
  GeglBuffer *temp_buffer = gegl_buffer_new(&padded_roi, format);
  gfloat *temp_data = (gfloat *) g_malloc((padded_roi.width * padded_roi.height) * 4 * sizeof(gfloat));

  for (gint y = padded_roi.y; y < padded_roi.y + padded_roi.height; y++)
  {
    for (gint x = padded_roi.x; x < padded_roi.x + padded_roi.width; x++)
    {
      gint idx = ((y - padded_roi.y) * padded_roi.width + (x - padded_roi.x)) * 4;
      gboolean inside = FALSE;

      switch (o->pattern)
      {
        case GEGL_GROK2_PATTERN_DIAMOND: // Original Diamond
        {
          gfloat grid_x = floor(x / (size * 1.5f)) * size * 1.5f;
          gfloat grid_y = floor(y / (height * 2.0f)) * height * 2.0f;
          gfloat x1 = grid_x + half_size;
          gfloat y1 = grid_y;
          gfloat x2 = grid_x;
          gfloat y2 = grid_y + height;
          gfloat x3 = grid_x + size;
          gfloat y3 = grid_y + height;
          gfloat x4 = grid_x + half_size;
          gfloat y4 = grid_y + height * 2.0f;
          gfloat x5 = grid_x;
          gfloat y5 = grid_y + height;
          gfloat x6 = grid_x + size;
          gfloat y6 = grid_y + height;
          inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3) ||
                   point_inside_triangle(x, y, x4, y4, x5, y5, x6, y6);
          break;
        }
        case GEGL_GROK2_PATTERN_HALFWAY_TRIANGLES: // Halfway Triangles
        {
          gfloat row_height = height * 1.5f;
          gfloat row = y / row_height;
          gfloat col = x / size;
          gfloat grid_y = floor(row) * row_height;
          gfloat grid_x = floor(col) * size;
          if ((gint)floor(row) % 2 == 1) grid_x += half_size;
          gboolean upward = ((gint)floor(row) + (gint)floor(col)) % 2 == 0;
          gfloat x1, y1, x2, y2, x3, y3;
          if (upward)
          {
            x1 = grid_x + half_size;
            y1 = grid_y;
            x2 = grid_x;
            y2 = grid_y + height;
            x3 = grid_x + size;
            y3 = grid_y + height;
          }
          else
          {
            x1 = grid_x;
            y1 = grid_y + height;
            x2 = grid_x + size;
            y2 = grid_y + height;
            x3 = grid_x + half_size;
            y3 = grid_y;
          }
          inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          break;
        }
        case GEGL_GROK2_PATTERN_NESTED: // Nested Triangles
        {
          gfloat grid_x = floor(x / size) * size;
          gfloat grid_y = floor(y / height) * height;
          gfloat x1 = grid_x + half_size;
          gfloat y1 = grid_y;
          gfloat x2 = grid_x;
          gfloat y2 = grid_y + height;
          gfloat x3 = grid_x + size;
          gfloat y3 = grid_y + height;
          inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          if (!inside)
          {
            x1 += size / 4.0f;
            y1 += height / 2.0f;
            x2 += size / 4.0f;
            y2 -= height / 2.0f;
            x3 -= size / 4.0f;
            y3 -= height / 2.0f;
            inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          }
          break;
        }
        case GEGL_GROK2_PATTERN_CHECKERBOARD: // Checkerboard Triangles
        {
          gfloat grid_x = floor(x / size) * size;
          gfloat grid_y = floor(y / height) * height;
          if (((gint)floor(x / size) + (gint)floor(y / height)) % 2 == 0)
          {
            gfloat x1 = grid_x + half_size;
            gfloat y1 = grid_y;
            gfloat x2 = grid_x;
            gfloat y2 = grid_y + height;
            gfloat x3 = grid_x + size;
            gfloat y3 = grid_y + height;
            inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          }
          break;
        }
        case GEGL_GROK2_PATTERN_SCALED_DIAMONDS: // Scaled Diamonds
        {
          gfloat grid_x = floor(x / (size * 3.0f)) * size * 3.0f;
          gfloat grid_y = floor(y / (height * 4.0f)) * height * 4.0f;
          if ((gint)floor(y / (height * 4.0f)) % 2 == 1)
            grid_x += half_size * 1.5f;
          gfloat x1 = grid_x + size;
          gfloat y1 = grid_y;
          gfloat x2 = grid_x;
          gfloat y2 = grid_y + height * 2.0f;
          gfloat x3 = grid_x + size * 2.0f;
          gfloat y3 = grid_y + height * 2.0f;
          gfloat x4 = grid_x + size;
          gfloat y4 = grid_y + height * 4.0f;
          gfloat x5 = grid_x;
          gfloat y5 = grid_y + height * 2.0f;
          gfloat x6 = grid_x + size * 2.0f;
          gfloat y6 = grid_y + height * 2.0f;
          inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3) ||
                   point_inside_triangle(x, y, x4, y4, x5, y5, x6, y6);
          break;
        }
        case GEGL_GROK2_PATTERN_UPSIDE_DOWN_NESTED: // Upside-Down Nested Triangles
        {
          gfloat grid_x = floor(x / size) * size;
          gfloat grid_y = floor(y / height) * height;
          gfloat x1 = grid_x + half_size;
          gfloat y1 = grid_y + height;
          gfloat x2 = grid_x;
          gfloat y2 = grid_y;
          gfloat x3 = grid_x + size;
          gfloat y3 = grid_y;
          
          inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          if (!inside)
          {
            x1 -= size / 4.0f;
            y1 -= height / 2.0f;
            x2 += size / 4.0f;
            y2 += height / 2.0f;
            x3 -= size / 4.0f;
            y3 += height / 2.0f;
            inside = point_inside_triangle(x, y, x1, y1, x2, y2, x3, y3);
          }
          break;
        }
      }

      if (inside)
      {
        temp_data[idx + 0] = fg_rgb[0];
        temp_data[idx + 1] = fg_rgb[1];
        temp_data[idx + 2] = fg_rgb[2];
        temp_data[idx + 3] = 1.0f;
      }
      else
      {
        temp_data[idx + 0] = bg_rgb[0];
        temp_data[idx + 1] = bg_rgb[1];
        temp_data[idx + 2] = bg_rgb[2];
        temp_data[idx + 3] = 1.0f;
      }
    }
  }

  gegl_buffer_set(temp_buffer, &padded_roi, 0, format, temp_data, GEGL_AUTO_ROWSTRIDE);
  g_free(temp_data);

  if (o->apply_noise_reduction)
  {
    GeglBuffer *smoothed_buffer = apply_noise_reduction(temp_buffer, &padded_roi);
    gegl_buffer_get(smoothed_buffer, roi, 1.0, format, out_buf, GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_CLAMP);
    g_object_unref(smoothed_buffer);
  }
  else
  {
    gegl_buffer_get(temp_buffer, roi, 1.0, format, out_buf, GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_CLAMP);
  }

  g_object_unref(temp_buffer);

  return TRUE;
}

static void
gegl_op_class_init(GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS(klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS(klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;

  gegl_operation_class_set_keys(operation_class,
      "name",        "ai/lb:triangle-diamond",
      "title",       _("Triangle and Diamond Patterns"),
      "reference-hash", "trianglepatterngegl2025",
      "description", _("Renders various triangle and diamond patterns"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Triangle Diamond Patterns..."),
      NULL);
}

#endif
