/* This file is an image processing operation for GEGL
 *
 * GEGL is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * GEGL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GEGL; if not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright 2006 Øyvind Kolås <pippin@gimp.org>
 * 2025 Beaver modifying mostly Grok's work. Deep Seek helped a little oto
* 
* */
#include "config.h"
#include <glib/gi18n-lib.h>
#include <gegl.h>
#include <gegl-plugin.h>
#include <math.h>

#ifdef GEGL_PROPERTIES

enum_start(gegl_circle_patternx)
  enum_value(GEGL_CIRCLE_PATTERN_BASIC_GRID, "basic_grid", N_("Basic Grid"))
  enum_value(GEGL_CIRCLE_PATTERN_OFFSET_GRID, "offset_grid", N_("Offset Grid"))
  enum_value(GEGL_CIRCLE_PATTERN_HEXAGONAL_GRID, "hexagonal_grid", N_("Hexagonal Grid"))
  enum_value(GEGL_CIRCLE_PATTERN_RANDOM_SCATTER, "random_scatter", N_("Random Scatter"))
  enum_value(GEGL_CIRCLE_PATTERN_RIPPLE, "ripple", N_("Ripple Circles"))
enum_end(GeglCirclePatternx)

property_enum(pattern, _("Circle Pattern"),
              GeglCirclePatternx, gegl_circle_patternx,
              GEGL_CIRCLE_PATTERN_BASIC_GRID)
    description(_("Select the circle pattern style"))

property_double(radius, _("Circle Radius"), 50.0)
    description(_("Radius of the circle in pixels"))
    value_range(10.0, 200.0)
    ui_range(10.0, 100.0)

property_color(circle_color, _("Circle Color"), "#ffffff")
    description(_("Color of the circle (default is white)"))

property_color(bg_color, _("Background Color"), "#a8d5ff")
    description(_("Color of the background (default is light blue)"))

property_boolean(draw_outline, _("Draw Outline"), FALSE)
    description(_("Enable to draw an outline around the circle"))

property_double(outline_thickness, _("Outline Thickness"), 2.0)
    description(_("Thickness of the circle outline in pixels"))
    value_range(1.0, 20.0)
    ui_range(1.0, 10.0)
    ui_meta("visible", "draw_outline")

property_color(outline_color, _("Outline Color"), "#000000")
    description(_("Color of the circle outline (default is black)"))
    ui_meta("visible", "draw_outline")

property_boolean(smooth, _("Apply Noise Reduction"), FALSE)
    description(_("Enable noise reduction to smooth circle edges"))

#else

#define GEGL_OP_POINT_FILTER
#define GEGL_OP_NAME     circlepatterns
#define GEGL_OP_C_SOURCE circlepatterns.c

#include "gegl-op.h"

static void
prepare(GeglOperation *operation)
{
  const Babl *space = gegl_operation_get_source_space(operation, "input");
  gegl_operation_set_format(operation, "input", babl_format_with_space("RGBA float", space));
  gegl_operation_set_format(operation, "output", babl_format_with_space("RGBA float", space));
}

// Simple hash function for pseudo-random numbers
static guint32
hash_position(gint x, gint y)
{
  return (x * 131 + y * 151) ^ (x + y);
}

// Pseudo-random float between 0 and 1 based on position
static gfloat
random_float(gint x, gint y)
{
  return (hash_position(x, y) % 1000) / 1000.0f;
}

// Function to apply noise reduction, similar to triangle_diamond.c
static GeglBuffer *
apply_noise_reduction(GeglBuffer *input_buffer, const GeglRectangle *result)
{
  GeglNode *gegl, *source, *noise_reduction, *sink;
  GeglBuffer *output_buffer;

  gegl = gegl_node_new();

  source = gegl_node_new_child(gegl,
                               "operation", "gegl:buffer-source",
                               "buffer", input_buffer,
                               NULL);

  noise_reduction = gegl_node_new_child(gegl,
                                        "operation", "gegl:noise-reduction",
                                        "iterations", 2,  // Set to 3 as specified
                                        NULL);

  sink = gegl_node_new_child(gegl,
                             "operation", "gegl:buffer-sink",
                             "buffer", &output_buffer,
                             NULL);

  gegl_node_link_many(source, noise_reduction, sink, NULL);

  gegl_node_process(sink);

  g_object_unref(gegl);

  return output_buffer;
}

static gboolean
process(GeglOperation *operation, void *in_buf, void *out_buf, glong n_pixels, const GeglRectangle *roi, gint level)
{
  GeglProperties *o = GEGL_PROPERTIES(operation);
  gfloat circle_rgb[3], bg_rgb[3], outline_rgb[3];

  gegl_color_get_pixel(o->circle_color, babl_format("RGB float"), circle_rgb);
  gegl_color_get_pixel(o->bg_color, babl_format("RGB float"), bg_rgb);
  gegl_color_get_pixel(o->outline_color, babl_format("RGB float"), outline_rgb);

  gfloat radius = o->radius;
  gfloat diameter = 2.0f * radius;
  gfloat outline_thickness = o->outline_thickness;

  // Create a padded ROI to handle edge effects, similar to triangle_diamond.c
  const Babl *format = babl_format("RGBA float");
  GeglRectangle padded_roi = *roi;
  padded_roi.x -= 16;
  padded_roi.y -= 16;
  padded_roi.width += 32;
  padded_roi.height += 32;
  GeglBuffer *temp_buffer = gegl_buffer_new(&padded_roi, format);
  gfloat *temp_data = (gfloat *) g_malloc((padded_roi.width * padded_roi.height) * 4 * sizeof(gfloat));

  for (gint y = padded_roi.y; y < padded_roi.y + padded_roi.height; y++)
  {
    for (gint x = padded_roi.x; x < padded_roi.x + padded_roi.width; x++)
    {
      gint idx = ((y - padded_roi.y) * padded_roi.width + (x - padded_roi.x)) * 4;
      gfloat min_distance = G_MAXFLOAT;
      gfloat current_radius = radius;
      gboolean is_inside = FALSE;
      gboolean is_outline = FALSE;

      switch (o->pattern)
      {
        case GEGL_CIRCLE_PATTERN_BASIC_GRID:
        {
          gfloat grid_x = floor(x / diameter) * diameter + radius;
          gfloat grid_y = floor(y / diameter) * diameter + radius;
          gfloat dx = x - grid_x;
          gfloat dy = y - grid_y;
          gfloat distance = sqrt(dx * dx + dy * dy);
          min_distance = distance;
          current_radius = radius;
          break;
        }
        case GEGL_CIRCLE_PATTERN_OFFSET_GRID:
        {
          gfloat row_height = diameter;
          gfloat row = floor(y / row_height);
          gfloat col = floor(x / diameter);
          for (gint r = -1; r <= 1; r++)
          {
            for (gint c = -1; c <= 1; c++)
            {
              gfloat grid_y = (row + r) * row_height + radius;
              gfloat grid_x = (col + c) * diameter + radius;
              if ((gint)(row + r) % 2 == 1) grid_x += radius;
              gfloat dx = x - grid_x;
              gfloat dy = y - grid_y;
              gfloat distance = sqrt(dx * dx + dy * dy);
              if (distance < min_distance)
              {
                min_distance = distance;
                current_radius = radius;
              }
            }
          }
          break;
        }
        case GEGL_CIRCLE_PATTERN_HEXAGONAL_GRID:
        {
          gfloat row_height = diameter * sqrt(3.0f) / 2.0f;
          gfloat row = floor(y / row_height);
          gfloat col = floor(x / diameter);
          for (gint r = -1; r <= 1; r++)
          {
            for (gint c = -1; c <= 1; c++)
            {
              gfloat grid_y = (row + r) * row_height + radius;
              gfloat grid_x = (col + c) * diameter + radius;
              if ((gint)(row + r) % 2 == 1) grid_x += radius;
              gfloat dx = x - grid_x;
              gfloat dy = y - grid_y;
              gfloat distance = sqrt(dx * dx + dy * dy);
              if (distance < min_distance)
              {
                min_distance = distance;
                current_radius = radius;
              }
            }
          }
          break;
        }
        case GEGL_CIRCLE_PATTERN_RANDOM_SCATTER:
        {
          gfloat grid_x_base = floor(x / diameter) * diameter;
          gfloat grid_y_base = floor(y / diameter) * diameter;
          for (gint r = -1; r <= 1; r++)
          {
            for (gint c = -1; c <= 1; c++)
            {
              gfloat base_x = grid_x_base + c * diameter;
              gfloat base_y = grid_y_base + r * diameter;
              gfloat offset_x = (random_float(base_x, base_y) - 0.5f) * radius;
              gfloat offset_y = (random_float(base_y, base_x) - 0.5f) * radius;
              gfloat grid_x = base_x + radius + offset_x;
              gfloat grid_y = base_y + radius + offset_y;
              gfloat dx = x - grid_x;
              gfloat dy = y - grid_y;
              gfloat distance = sqrt(dx * dx + dy * dy);
              if (distance < min_distance)
              {
                min_distance = distance;
                current_radius = radius;
              }
            }
          }
          break;
        }
        case GEGL_CIRCLE_PATTERN_RIPPLE:
        {
          gfloat row_height = diameter;
          gfloat col = floor(x / diameter);
          gfloat row = floor(y / row_height);
          for (gint r = -1; r <= 1; r++)
          {
            for (gint c = -1; c <= 1; c++)
            {
              gfloat grid_x = (col + c) * diameter + radius;
              gfloat grid_y = (row + r) * row_height + radius;
              gfloat dx = x - grid_x;
              gfloat dy = y - grid_y;
              gfloat distance = sqrt(dx * dx + dy * dy);
              gfloat wave = sin((col + c) * 0.1f + (row + r) * 0.1f) * 0.3f + 1.0f;
              gfloat modulated_radius = radius * wave;
              if (distance < min_distance)
              {
                min_distance = distance;
                current_radius = modulated_radius;
              }
            }
          }
          break;
        }
      }

      if (min_distance <= current_radius)
      {
        is_inside = TRUE;
        if (o->draw_outline && min_distance >= (current_radius - outline_thickness))
        {
          is_outline = TRUE;
        }
      }

      if (is_inside)
      {
        if (is_outline)
        {
          temp_data[idx + 0] = outline_rgb[0];
          temp_data[idx + 1] = outline_rgb[1];
          temp_data[idx + 2] = outline_rgb[2];
          temp_data[idx + 3] = 1.0f;
        }
        else
        {
          temp_data[idx + 0] = circle_rgb[0];
          temp_data[idx + 1] = circle_rgb[1];
          temp_data[idx + 2] = circle_rgb[2];
          temp_data[idx + 3] = 1.0f;
        }
      }
      else
      {
        temp_data[idx + 0] = bg_rgb[0];
        temp_data[idx + 1] = bg_rgb[1];
        temp_data[idx + 2] = bg_rgb[2];
        temp_data[idx + 3] = 1.0f;
      }
    }
  }

  gegl_buffer_set(temp_buffer, &padded_roi, 0, format, temp_data, GEGL_AUTO_ROWSTRIDE);
  g_free(temp_data);

  if (o->smooth)
  {
    GeglBuffer *smoothed_buffer = apply_noise_reduction(temp_buffer, &padded_roi);
    gegl_buffer_get(smoothed_buffer, roi, 1.0, format, out_buf, GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_CLAMP);
    g_object_unref(smoothed_buffer);
  }
  else
  {
    gegl_buffer_get(temp_buffer, roi, 1.0, format, out_buf, GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_CLAMP);
  }

  g_object_unref(temp_buffer);

  return TRUE;
}

static void
gegl_op_class_init(GeglOpClass *klass)
{
  GeglOperationClass *operation_class = GEGL_OPERATION_CLASS(klass);
  GeglOperationPointFilterClass *point_filter_class = GEGL_OPERATION_POINT_FILTER_CLASS(klass);

  operation_class->prepare = prepare;
  point_filter_class->process = process;

  gegl_operation_class_set_keys(operation_class,
      "name",        "ai/lb:circle-patterns",
      "title",       _("Circle Patterns"),
      "reference-hash", "circlepatterngegl2025",
      "description", _("Renders various tiled circle patterns"),
    "gimp:menu-path", "<Image>/Filters/AI GEGL",
    "gimp:menu-label", _("Circle Patterns..."),
      NULL);
}

#endif
